# training

Training environments, scenes and assets built on top of MuJoCo Playground,
kept **outside** the `mujoco_playground/` submodule so that submodule stays
pinned to its clean upstream commit (see [REPO_LAYOUT.md](../REPO_LAYOUT.md)).

Environments defined here are registered with Playground's own registries at
import time, so they are trained with Playground's `learning/train_jax_ppo.py` —
no fork of the trainer, and no patch to the submodule.

## Layout

```
training/
├── registry.py            registration of envs, configs, randomizers, PPO recipes
├── train_jax_ppo.py       training entry point (wraps Playground's trainer)
├── export_policy_to_onnx.py  checkpoint -> the ONNX + metadata the robot runs
├── logs/                  runs land here (gitignored, created on the first run)
├── utils/                 tools for looking at a trained policy (README there)
│   ├── debug_rollout.py         checkpoint loading + rollout rendering helpers
│   └── debug_rollout_render.py  render rollout videos from a checkpoint
└── manipulation/
    └── ufactory_xarm6/
        ├── pick.py            the deployed task (dynamics, reward, DR, config)
        ├── ppo_params.py      its PPO hyperparameters
        ├── xarm6.py           shared xArm6 base env + asset loading
        ├── xarm6_kinematics.py
        ├── xmls/              scenes (MJCF)
        └── meshes/            assets (STL) referenced by the scenes,
                               gitignored -- scripts/fetch-xarm6-assets.sh
```

## Environments

`manipulation/ufactory_xarm6/pick.py` defines **`XArm6Pick`**: grasp a cube and
hold it 0.25 m above where it spawned. It is the environment to train — one
self-contained class with the observation, reward and sim2real randomization
the deployed policy uses.

It is the only environment this package registers. See the
[directory README](manipulation/ufactory_xarm6/README.md) for how the files in
it divide up.

## Training

The entry point takes every flag Playground's `train_jax_ppo.py` takes; it only
registers these environments first. Run it from the repo root with
`dockertrainingrun.sh`, which works inside this directory and runs against the
Playground project's environment:

```bash
docker/dockertrainingrun.sh uv run python train_jax_ppo.py \
  --env_name XArm6Pick \
  --impl warp \
  --domain_randomization \
  --use_tb --log_training_metrics
```

Paths given to the trainer are relative to this directory, so a checkpoint to
resume from is `logs/<run>/checkpoints`. The same entry point is reachable from
`mujoco_playground/` instead, which is what the batch script in `sbatch/` does —
the run directory is then `../training/logs/<run>`:

```bash
docker/dockerplaygroundrun.sh uv run python ../training/train_jax_ppo.py ...
```

Useful flags:

- `--domain_randomization` uses the env's registered randomizer.
- `--playground_config_overrides '{"box_init.x_high":0.03}'` overrides env config
  fields without touching the code (keep the JSON space-free so it survives
  shell word-splitting).
- Any PPO field can be overridden on the command line (`--num_timesteps`,
  `--num_envs`, `--learning_rate`, ...); flags that are *present* win over the
  registered recipe.
- `--logdir DIR` chooses where runs land. The default is this directory's
  `logs/`, resolved from the entry point's own location rather than from the
  working directory — so runs collect in the same place wherever they are
  launched from, instead of following Playground's default of `logs/` under the
  working directory (which would put them inside the submodule).

Upstream environments still work through this entry point
(`--env_name PandaPickCubeCartesian`), so it can replace `uv run train-jax-ppo`
everywhere.

## Rendering a trained policy

`utils/debug_rollout_render.py` replays a checkpoint and writes MP4s of the
rollouts, with the environment's `render_debug_fields` drawn on every frame — the
reward terms and diagnostics that explain *why* a policy does what it does. It
runs in the same container as training, which already has OSMesa and ffmpeg for
headless rendering:

```bash
docker/dockertrainingrun.sh uv run python utils/debug_rollout_render.py \
  --impl warp --num_videos 4
```

With no `--checkpoint_path` that renders the latest step of the most recent run
under `logs/`, reading the environment name back out of the run directory name,
and saves the videos next to the checkpoints. The environment is rebuilt from the
`config.json` the trainer saved with the checkpoint, so the rollout uses the
physics and control the policy was trained under rather than the current defaults
(nested sub-configs like `reward_config` excepted — those only affect the
overlaid numbers, and taking them from an old checkpoint breaks envs whose reward
has gained a term since).

Useful flags:

- `--checkpoint_path` takes a step directory, a `checkpoints` root or a run
  directory; the last two restore the highest step. `--all_checkpoints` renders
  every step of the run instead, which shows the policy as it learned.
- `--panel N` tiles rollouts into an N×N grid in one file, the quickest way to
  see the spread across cube spawns; `--num_videos` then counts panels.
- `--render_camera` defaults to the free camera; the xArm6 scenes also define
  `front`, `birdseye` and `top`. An unknown name is rejected up front, with the
  list the model has, rather than after the rollout has been simulated.
- `--nodeterministic` samples actions from the policy distribution instead of
  playing its mean, reproducing the exploration noise it had during training.
- `--show_collision_meshes` overlays the convex hulls used for contact, and
  `--frame site` draws the site axes (`link_tcp`, finger pads, sensor sites) —
  both for debugging the model rather than the policy.
- `--playback_speed` and `--render_fps` set the video's speed and frame rate
  (which together decide how many sim steps are skipped per frame).

Rendering is CPU-bound: OSMesa rasterizes on the CPU, so wall time scales with
`--num_videos`, the episode length and the frame size, not with the GPU.

## Exporting a policy for the robot

`export_policy_to_onnx.py` writes the two files the deployed controller reads,
and only those two: `<name>.onnx`, the deterministic policy with the checkpoint's
observation normalization baked into the graph, and `<name>.yaml`, the
runtime contract (control rate, action decode and limits, observation layout,
home pose, task geometry). Everything in the metadata is read back out of the
checkpoint, the env config saved beside it and the scene MJCF, so a retrained
policy re-derives the numbers the robot decodes its actions with instead of
letting them drift from what it was trained on.

```bash
docker/dockertrainingrun.sh \
  uv run --with onnx --with onnxruntime python export_policy_to_onnx.py \
  --output_dir ../deployment \
  --name xarm6_pick
```

`onnx` and `onnxruntime` are added for the run rather than to the pinned project;
the graph is built with ONNX's own builder, so no second deep-learning framework
is involved. This exports the latest step of the most recent run under `logs/`,
and the two flags put it where the deployment bundle's run script looks for it.

Useful flags:

- `--output_dir` and `--name` choose where the pair lands and what it is called.
  The defaults are the run's own `export/` directory and the run's name, which
  keeps several candidate policies apart; `../deployment` with a fixed name
  overwrites the one deployable slot instead.
- `--checkpoint_path` takes a step directory, a `checkpoints` root or a run
  directory, exactly as `utils/debug_rollout_render.py` does.
- `--atol` (2e-5) is how closely the exported graph must match Brax's own policy,
  compared over `--num_validation_samples` observations. A failure here means the
  export is wrong, not that the tolerance is tight.
- `--skip_validation` writes the file without that check, for machines without
  onnxruntime. An unvalidated export should not be put on a robot.

Only state-only policies export: a vision policy's observation carries `pixels/*`
entries and is rejected up front.

See [`deployment/README.md`](../deployment/README.md) for what consumes the two
files.

## Adding to this package

**A new environment.** Write it as an `mjx_env.MjxEnv` subclass (subclassing
`xarm6.XArm6Base` gets the xArm6 model loading for free), then add it to the
table in `manipulation/ufactory_xarm6/__init__.py`, or register it directly:

```python
from training import registry

registry.register_environment(
    "MyEnv",
    my_module.MyEnv,
    my_module.default_config,
    ppo_params_fn=my_module.my_ppo_config,   # optional
    randomizer=my_module.domain_randomize,   # optional
)
```

New robots go in their own directory next to `ufactory_xarm6/`, exposing a
`register()` that the parent `manipulation/__init__.py` calls. Other suites are
selected with `suite="locomotion"` / `suite="dm_control_suite"`.

**RL parameters.** A PPO recipe is a function `(env_name, impl) -> ConfigDict`.
Start from `registry.default_ppo_config(env_name)` — Playground's defaults, with
`episode_length` and `action_repeat` taken from the env's own config — and set
only the fields you tune (see `manipulation/ufactory_xarm6/ppo_params.py`). One
recipe can serve a family of envs. Registering the recipe is what lets
`train_jax_ppo.py` find hyperparameters for an env it does not ship.

**Scenes and assets.** Put MJCF under the robot's `xmls/` and meshes under its
`meshes/`. Assets are loaded from paths relative to this package (see
`xarm6.get_assets`), never from `mjx_env.ROOT_PATH`, which is what keeps the
submodule untouched. The keys of the asset dict must match the `file="..."`
attributes in the MJCF exactly (e.g. `xarm6/visual/link1.stl`), because the
model is compiled from an in-memory asset dict rather than from disk. Keeping
`xmls/` and `meshes/` siblings, as the loader assumes, is what makes those
relative paths line up.

## Notes

- Environment names must not collide with the ones Playground already ships;
  registration raises if they do, rather than shadowing an upstream env.
- Importing `training` is what performs registration. The training entry
  point loads this package straight from its directory, so nothing has to be
  installed; to use the envs from your own script, either import that entry
  point or put the repo root on `PYTHONPATH`. Note that the repo root on
  `PYTHONPATH` also makes the `warp/` and `mujoco/` submodule checkouts shadow
  the installed packages of those names, so prefer the entry point.
- These environments were developed against a Playground fork with a Warp RGBD
  vision wrapper; nothing here depends on it, so pixel-based observations are
  not available with the pinned upstream submodule.
