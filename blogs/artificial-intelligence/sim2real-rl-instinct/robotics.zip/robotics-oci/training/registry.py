# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Registration of this package's environments with MuJoCo Playground.

Environments defined here are added to the *upstream* Playground registries
(``mujoco_playground._src.manipulation`` and friends) at import time, so
``registry.load`` / ``registry.get_default_config`` /
``registry.get_domain_randomizer`` -- and therefore
``learning/train_jax_ppo.py`` -- resolve them by name without any edit to the
mujoco_playground submodule.

Playground's public ``register_environment`` covers the env class and its
default config only. Two more things a trainable env needs are looked up
elsewhere, so this module supplies them as well:

* the **domain randomizer**, which lives in the suite's private ``_randomizer``
  dict (there is no public setter for it);
* the **PPO hyperparameters**, which ``train_jax_ppo.get_rl_config`` fetches
  from ``mujoco_playground.config.<suite>_params.brax_ppo_config``. That
  function only knows the envs upstream ships, so ``install_rl_config_hooks``
  wraps it with a lookup in this package's table, falling back to the original
  for every upstream env.
"""

from typing import Callable, Dict, List, Optional, Type

from ml_collections import config_dict
from mujoco_playground._src import dm_control_suite
from mujoco_playground._src import locomotion
from mujoco_playground._src import manipulation
from mujoco_playground._src import mjx_env
from mujoco_playground._src import registry as playground_registry
from mujoco_playground.config import dm_control_suite_params
from mujoco_playground.config import locomotion_params
from mujoco_playground.config import manipulation_params

# A PPO-params function takes the env name and the MJX implementation
# ("jax"/"warp") that training was launched with, exactly like Playground's
# ``brax_ppo_config``, so one recipe can serve a family of envs.
PpoParamsFn = Callable[[str, Optional[str]], config_dict.ConfigDict]
ConfigFn = Callable[[], config_dict.ConfigDict]

# Suite name -> (registry module, RL-params module).
_SUITES = {
    "manipulation": (manipulation, manipulation_params),
    "locomotion": (locomotion, locomotion_params),
    "dm_control_suite": (dm_control_suite, dm_control_suite_params),
}

_ppo_params: Dict[str, PpoParamsFn] = {}
_vision_ppo_params: Dict[str, PpoParamsFn] = {}
_registered: List[str] = []


def register_environment(
    env_name: str,
    env_class: Type[mjx_env.MjxEnv],
    config_fn: ConfigFn,
    *,
    ppo_params_fn: Optional[PpoParamsFn] = None,
    vision_ppo_params_fn: Optional[PpoParamsFn] = None,
    randomizer: Optional[Callable[..., object]] = None,
    suite: str = "manipulation",
) -> None:
  """Registers one environment with Playground under ``env_name``.

  Args:
    env_name: Name to train with (``--env_name``). Must not shadow an env the
      installed Playground already ships.
    env_class: The ``MjxEnv`` subclass.
    config_fn: Returns the env's default config (``registry.get_default_config``).
    ppo_params_fn: Returns the Brax PPO hyperparameters for this env. Without
      it, training the env needs every hyperparameter passed on the command
      line.
    vision_ppo_params_fn: PPO hyperparameters used when training with
      ``--vision``.
    randomizer: Domain randomizer used when training with
      ``--domain_randomization``.
    suite: Which Playground suite to register under.
  """
  if suite not in _SUITES:
    raise ValueError(
        f"Unknown suite {suite!r}; expected one of {sorted(_SUITES)}."
    )
  suite_module, params_module = _SUITES[suite]

  # Validate everything before touching a registry, so a rejected call cannot
  # leave the env half-registered.
  if env_name in suite_module._envs and env_name not in _registered:  # pylint: disable=protected-access
    raise ValueError(
        f"Env {env_name!r} is already registered by mujoco_playground; pick a"
        " different name so the upstream env stays reachable."
    )
  if randomizer is not None and not hasattr(suite_module, "_randomizer"):
    raise ValueError(f"Suite {suite!r} does not support domain randomizers.")
  if vision_ppo_params_fn is not None and not hasattr(
      params_module, "brax_vision_ppo_config"
  ):
    raise ValueError(f"Suite {suite!r} has no vision PPO config hook.")

  suite_module.register_environment(env_name, env_class, config_fn)
  if randomizer is not None:
    suite_module._randomizer[env_name] = randomizer  # pylint: disable=protected-access
  if ppo_params_fn is not None:
    _ppo_params[env_name] = ppo_params_fn
  if vision_ppo_params_fn is not None:
    _vision_ppo_params[env_name] = vision_ppo_params_fn

  if env_name not in _registered:
    _registered.append(env_name)

  # Playground snapshots the union of the suites into ALL_ENVS at import time,
  # which is what the --env_name flag help and the "env not found" messages
  # read, so refresh it here.
  playground_registry.ALL_ENVS = (
      dm_control_suite.ALL_ENVS + locomotion.ALL_ENVS + manipulation.ALL_ENVS
  )


def all_envs() -> tuple:
  """Names of every environment this package has registered."""
  return tuple(_registered)


def get_env_class(
    env_name: str, suite: str = "manipulation"
) -> Type[mjx_env.MjxEnv]:
  """Returns the environment class registered under ``env_name``.

  Playground exposes ``registry.load``, which *instantiates* an env (compiling
  the scene and putting the model to MJX), but no way to reach the class
  itself -- so anything that only needs a class attribute, such as an env's
  declared observation layout, has to read the suite's registry directly.
  """
  if suite not in _SUITES:
    raise ValueError(
        f"Unknown suite {suite!r}; expected one of {sorted(_SUITES)}."
    )
  envs = _SUITES[suite][0]._envs  # pylint: disable=protected-access
  if env_name not in envs:
    raise ValueError(
        f"Env {env_name!r} is not registered under suite {suite!r}."
    )
  return envs[env_name]


def default_ppo_config(env_name: str) -> config_dict.ConfigDict:
  """Returns the Playground PPO defaults that per-env recipes start from.

  Mirrors the base config at the top of
  ``mujoco_playground.config.manipulation_params.brax_ppo_config``, so a recipe
  written here only has to state what it changes.
  """
  env_config = manipulation.get_default_config(env_name)
  return config_dict.create(
      episode_length=env_config.episode_length,
      normalize_observations=True,
      action_repeat=env_config.action_repeat,
      reward_scaling=1.0,
      network_factory=config_dict.create(
          policy_hidden_layer_sizes=(32, 32, 32, 32),
          value_hidden_layer_sizes=(256, 256, 256, 256, 256),
          policy_obs_key="state",
          value_obs_key="state",
      ),
      num_resets_per_eval=10,
  )


def _wrap(original: PpoParamsFn, table: Dict[str, PpoParamsFn]) -> PpoParamsFn:
  def lookup(
      env_name: str, impl: Optional[str] = None
  ) -> config_dict.ConfigDict:
    if env_name in table:
      return table[env_name](env_name, impl)
    return original(env_name, impl)

  lookup.__wrapped__ = original  # marks the module attribute as already hooked
  return lookup


def install_rl_config_hooks() -> None:
  """Routes PPO-config lookups for this package's envs through its own table.

  Idempotent: re-importing the package (or importing it after something else
  already hooked the params modules) does not stack wrappers.
  """
  for params_module in {m for _, m in _SUITES.values()}:
    for attr, table in (
        ("brax_ppo_config", _ppo_params),
        ("brax_vision_ppo_config", _vision_ppo_params),
    ):
      original = getattr(params_module, attr, None)
      if original is None or hasattr(original, "__wrapped__"):
        continue
      setattr(params_module, attr, _wrap(original, table))
