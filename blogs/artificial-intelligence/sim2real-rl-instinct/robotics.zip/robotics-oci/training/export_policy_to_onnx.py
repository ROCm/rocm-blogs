# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Export a trained policy checkpoint to the two files the robot needs.

Turns a Brax PPO checkpoint under ``logs/<run>/checkpoints`` into a pair of files
in ``logs/<run>/export/``:

* ``<name>.onnx`` -- the deterministic policy, with observation normalization
  baked into the graph, so the robot feeds it raw observations and reads actions
  straight out;
* ``<name>.yaml`` -- the runtime contract: control rate, action decode and
  limits, observation layout, home pose and task geometry, all read back out of
  the checkpoint rather than written by hand.

Those two files are the whole hand-off to ``deployment/``; nothing else from
this repository is needed to run the policy on the robot. See
``deployment/README.md`` for how they are consumed.

The exported graph is

    action = tanh( MLP( (state - mean) / std )[:, :action_size] )

which is what Brax's inference function computes for a deterministic
``tanh_normal`` policy: the MLP's last layer is ``2 * action_size`` wide (an
action mean and a log-std in one vector), a deterministic action is the
distribution's mode, and the mode of a tanh-squashed normal is the tanh of its
location. ``mean``/``std`` are the observation running statistics the checkpoint
carries. All of that is checked numerically against Brax's own policy before the
export is accepted -- see ``--atol`` and ``--skip_validation``.

The graph is built with ONNX's own builder rather than by tracing a TensorFlow
or PyTorch copy of the network, so exporting needs no second deep-learning
framework: only ``onnx`` to write the file and ``onnxruntime`` to check it,
neither of which the training environment has. Run it from ``training/`` like
the other entry points, adding those two:

    docker/dockertrainingrun.sh \
      uv run --with onnx --with onnxruntime python export_policy_to_onnx.py

With no arguments that exports the latest step of the most recent run under
``logs/``, writing both files into that run's ``export/`` (created if needed;
``--output_dir`` puts them elsewhere). ``--checkpoint_path`` takes a step
directory, a ``checkpoints`` root or a run directory (the last two export the
highest step), exactly as ``utils/debug_rollout_render.py`` does.
"""

import importlib.util
import json
import pathlib
import sys
from typing import Any, Mapping, Sequence

from absl import app
from absl import flags

_PACKAGE_ROOT = pathlib.Path(__file__).resolve().parent


def _import_training() -> None:
  """Imports the ``training`` package this file lives in, registering its envs.

  The package is loaded from its location rather than by putting the repo root
  on ``sys.path``, because the submodule checkouts there (``warp/``,
  ``mujoco/``) would shadow the installed packages of the same name --
  ``train_jax_ppo.py`` next to this file explains that failure in full.
  """
  if "training" in sys.modules:
    return
  spec = importlib.util.spec_from_file_location(
      "training",
      _PACKAGE_ROOT / "__init__.py",
      submodule_search_locations=[str(_PACKAGE_ROOT)],
  )
  module = importlib.util.module_from_spec(spec)
  # Published before it is executed, so the package's own ``from training import
  # ...`` statements bind to the module being created here.
  sys.modules["training"] = module
  spec.loader.exec_module(module)


_import_training()

# pylint: disable=g-import-not-at-top,wrong-import-position
from brax.training.agents.ppo import checkpoint as ppo_checkpoint
from etils import epath
import jax
import jax.numpy as jp
import mujoco
import numpy as np

from training import registry
from training.manipulation.ufactory_xarm6 import xarm6
from training.utils import debug_rollout

try:
  import onnx
  from onnx import helper as onnx_helper
  from onnx import numpy_helper
except ImportError as exc:  # pragma: no cover
  raise ImportError(
      "Exporting needs the onnx package, which the training environment does"
      " not have. Add it for the run rather than to the pinned project:\n"
      "  docker/dockertrainingrun.sh uv run --with onnx --with onnxruntime"
      " python export_policy_to_onnx.py"
  ) from exc
# pylint: enable=g-import-not-at-top,wrong-import-position

# The ONNX opset the graph targets: old enough for any onnxruntime in current
# use, new enough for everything here (Gemm, Sigmoid, Mul, Slice taking its
# bounds as inputs).
_OPSET = 13

# Names of the graph's input and output. The deployed controller reads these off
# the session rather than assuming them, but they are what it will report.
_INPUT_NAME = "state"
_OUTPUT_NAME = "action"

# Observation key of a state-only policy. Vision policies carry "pixels/..."
# entries as well and are not exportable here.
_STATE_KEY = "state"

# Where the pair lands inside the run directory, keeping the deployable artifacts
# in one place to copy to the robot rather than loose among the run's own output.
_EXPORT_SUBDIR = "export"

_CHECKPOINT_PATH = flags.DEFINE_string(
    "checkpoint_path",
    None,
    "Checkpoint to export: a step directory, a checkpoints root or a run "
    "directory (the last two export the highest step). Defaults to the most "
    "recent run under logs/.",
)
_OUTPUT_DIR = flags.DEFINE_string(
    "output_dir",
    None,
    "Where to write the two files. Defaults to export/ inside the run "
    "directory the checkpoint belongs to.",
)
_NAME = flags.DEFINE_string(
    "name",
    None,
    "Base name of the two files, giving <name>.onnx and <name>.yaml. "
    "Defaults to the run directory's name.",
)
_NUM_VALIDATION_SAMPLES = flags.DEFINE_integer(
    "num_validation_samples",
    256,
    "Observations to compare the exported graph against the Brax policy on.",
)
_ATOL = flags.DEFINE_float(
    "atol", 2e-5, "Largest action difference accepted during validation."
)
_SEED = flags.DEFINE_integer("seed", 0, "Validation RNG seed.")
_SKIP_VALIDATION = flags.DEFINE_bool(
    "skip_validation",
    False,
    "Write the ONNX file without checking it against the Brax policy. For "
    "exporting where onnxruntime is unavailable; an unchecked export should "
    "not be deployed.",
)


# ---------------------------------------------------------------------------
# Checkpoint inspection
# ---------------------------------------------------------------------------


def _load_network_config(step_dir: epath.Path) -> dict[str, Any]:
  """The PPO network config Brax saved with the checkpoint step."""
  return json.loads((step_dir / "ppo_network_config.json").read_text())


def _load_env_config(step_dir: epath.Path) -> dict[str, Any]:
  """The environment config the trainer saved next to the checkpoints."""
  config_path = debug_rollout.training_config_path(step_dir)
  if not config_path.exists():
    raise ValueError(
        "The environment config that the exported metadata is built from is"
        f" missing: {config_path}. The trainer writes it at the start of a run."
    )
  return json.loads(config_path.read_text())


def _observation_size(network_config: Mapping[str, Any]) -> int:
  """Width of the state observation the policy was trained on."""
  obs_size = network_config.get("observation_size")
  if not isinstance(obs_size, Mapping) or _STATE_KEY not in obs_size:
    raise ValueError(
        "Only state-only policies can be exported here; observation_size is"
        f" {obs_size!r}, which has no {_STATE_KEY!r} entry."
    )
  spec = obs_size[_STATE_KEY]
  shape = tuple(spec["shape"]) if isinstance(spec, Mapping) else tuple(spec)
  if len(shape) != 1:
    raise ValueError(f"Expected a flat state observation, got shape {shape}.")
  return int(shape[0])


def _running_statistics(
    normalizer_state: Any, observation_size: int
) -> tuple[np.ndarray, np.ndarray]:
  """The observation mean and std the policy normalizes with.

  Brax keeps these in the first element of the saved parameter tuple, per
  observation key. Returned as float32 vectors ready to fold into the graph.
  """
  mean_by_key = getattr(normalizer_state, "mean", None)
  std_by_key = getattr(normalizer_state, "std", None)
  if mean_by_key is None or std_by_key is None:
    raise ValueError(
        "This checkpoint carries no observation running statistics, so it was"
        " trained with normalize_observations=False. The deployed controller"
        " feeds raw observations and expects the normalization to be part of"
        " the graph, so such a policy cannot be exported here."
    )
  mean = np.asarray(mean_by_key[_STATE_KEY], dtype=np.float32).reshape(-1)
  std = np.asarray(std_by_key[_STATE_KEY], dtype=np.float32).reshape(-1)
  if mean.shape != (observation_size,) or std.shape != (observation_size,):
    raise ValueError(
        f"Running statistics are {mean.shape} / {std.shape}, expected"
        f" ({observation_size},) to match the observation."
    )
  if not np.all(std > 0.0):
    raise ValueError("Running statistics contain a non-positive std.")
  return mean, std


def _policy_layers(policy_params: Any) -> list[tuple[np.ndarray, np.ndarray]]:
  """The policy MLP's (kernel, bias) pairs, input layer first.

  Read out of the checkpoint rather than rebuilt from the configured hidden
  sizes, so what gets exported is the network that was actually trained.
  """
  params = policy_params.get("params", policy_params)
  layers = []
  while f"hidden_{len(layers)}" in params:
    layer = params[f"hidden_{len(layers)}"]
    layers.append((
        np.asarray(layer["kernel"], dtype=np.float32),
        np.asarray(layer["bias"], dtype=np.float32),
    ))
  if not layers:
    raise ValueError(
        f"No hidden_0 layer in the policy parameters (keys: {sorted(params)})."
    )
  return layers


def _check_layer_shapes(
    layers: Sequence[tuple[np.ndarray, np.ndarray]],
    observation_size: int,
    action_size: int,
) -> None:
  """Fails before anything is written if the network is not what we assume."""
  expected_in = observation_size
  for i, (kernel, bias) in enumerate(layers):
    if kernel.shape[0] != expected_in or kernel.shape[1] != bias.shape[0]:
      raise ValueError(
          f"Layer hidden_{i} has kernel {kernel.shape} and bias {bias.shape},"
          f" which does not follow a {expected_in}-wide input."
      )
    expected_in = kernel.shape[1]
  head_width = layers[-1][1].shape[0]
  if head_width != 2 * action_size:
    raise ValueError(
        f"The policy head is {head_width} wide but the action is"
        f" {action_size}-D. This exporter assumes a tanh_normal policy, whose"
        " head holds an action mean and a log-std (2 * action_size)."
    )


# ---------------------------------------------------------------------------
# ONNX graph
# ---------------------------------------------------------------------------


def _activation_nodes(name: str, x: str, out: str, prefix: str) -> list:
  """ONNX nodes for one activation, keyed by the name Brax records."""
  if name in ("silu", "swish"):
    # x * sigmoid(x); this opset has no fused SiLU.
    return [
        onnx_helper.make_node("Sigmoid", [x], [f"{prefix}_sig"]),
        onnx_helper.make_node("Mul", [x, f"{prefix}_sig"], [out]),
    ]
  direct = {"relu": "Relu", "tanh": "Tanh", "elu": "Elu"}
  if name in direct:
    return [onnx_helper.make_node(direct[name], [x], [out])]
  raise ValueError(
      f"Activation {name!r} has no ONNX equivalent here; add one to"
      " _activation_nodes if a policy is trained with it."
  )


def build_onnx_policy(
    mean: np.ndarray,
    std: np.ndarray,
    layers: Sequence[tuple[np.ndarray, np.ndarray]],
    action_size: int,
    activation: str,
) -> "onnx.ModelProto":
  """Builds the deterministic policy as an ONNX model.

  The graph normalizes the observation with the checkpoint's running
  statistics, runs the policy MLP, and returns the tanh of the action-mean half
  of its output. The batch dimension is symbolic, so one file serves both the
  controller (a single observation per tick) and batched offline comparisons.
  """
  observation_size = int(mean.shape[0])
  initializers = [
      numpy_helper.from_array(mean.reshape(1, -1), "obs_mean"),
      numpy_helper.from_array(std.reshape(1, -1), "obs_std"),
  ]
  nodes = [
      onnx_helper.make_node("Sub", [_INPUT_NAME, "obs_mean"], ["centered"]),
      onnx_helper.make_node("Div", ["centered", "obs_std"], ["normalized"]),
  ]

  current = "normalized"
  for i, (kernel, bias) in enumerate(layers):
    initializers += [
        numpy_helper.from_array(kernel, f"hidden_{i}_kernel"),
        numpy_helper.from_array(bias, f"hidden_{i}_bias"),
    ]
    linear_out = f"hidden_{i}_out"
    # Gemm rather than MatMul + Add: one node, and Flax already stores the
    # kernel in the (in, out) orientation Gemm wants at transB=0.
    nodes.append(
        onnx_helper.make_node(
            "Gemm",
            [current, f"hidden_{i}_kernel", f"hidden_{i}_bias"],
            [linear_out],
            name=f"hidden_{i}",
        )
    )
    current = linear_out
    if i < len(layers) - 1:
      activated = f"hidden_{i}_act"
      nodes += _activation_nodes(
          activation, linear_out, activated, f"hidden_{i}"
      )
      current = activated

  # Keep the action-mean half of the head and squash it. The Slice bounds are
  # initializers rather than attributes, which is what this opset expects.
  initializers += [
      numpy_helper.from_array(np.array([0], dtype=np.int64), "loc_start"),
      numpy_helper.from_array(
          np.array([action_size], dtype=np.int64), "loc_end"
      ),
      numpy_helper.from_array(np.array([1], dtype=np.int64), "loc_axis"),
  ]
  nodes += [
      onnx_helper.make_node(
          "Slice",
          [current, "loc_start", "loc_end", "loc_axis"],
          ["action_mean"],
          name="action_mean",
      ),
      onnx_helper.make_node(
          "Tanh", ["action_mean"], [_OUTPUT_NAME], name="squash"
      ),
  ]

  graph = onnx_helper.make_graph(
      nodes,
      "policy",
      inputs=[
          onnx_helper.make_tensor_value_info(
              _INPUT_NAME, onnx.TensorProto.FLOAT, ["batch", observation_size]
          )
      ],
      outputs=[
          onnx_helper.make_tensor_value_info(
              _OUTPUT_NAME, onnx.TensorProto.FLOAT, ["batch", action_size]
          )
      ],
      initializer=initializers,
  )
  model = onnx_helper.make_model(
      graph, opset_imports=[onnx_helper.make_operatorsetid("", _OPSET)]
  )
  model.doc_string = (
      "Deterministic Brax PPO policy: the tanh of the action mean, with"
      " observation normalization folded in."
  )
  return model


def validate_onnx_policy(
    onnx_path: pathlib.Path,
    step_dir: epath.Path,
    mean: np.ndarray,
    std: np.ndarray,
    num_samples: int,
    seed: int,
    atol: float,
) -> float:
  """Checks the exported graph against Brax's own policy.

  Observations are drawn from the running statistics the policy normalizes
  with, so the comparison covers the part of the input space the policy
  actually sees rather than an arbitrary unit ball. Returns the largest
  absolute action difference found.
  """
  try:
    import onnxruntime as ort  # pylint: disable=import-outside-toplevel
  except ImportError as exc:
    raise ImportError(
        "Validating the export needs onnxruntime (add --with onnxruntime, or"
        " pass --skip_validation to write an unchecked file)."
    ) from exc

  rng = np.random.default_rng(seed)
  observations = (
      mean + std * rng.standard_normal((num_samples, mean.shape[0]))
  ).astype(np.float32)
  # Prepend the mean observation itself: the one input where an error in the
  # folded normalization would cancel out of every random sample but not here.
  observations = np.concatenate([mean.reshape(1, -1), observations], axis=0)

  session = ort.InferenceSession(
      str(onnx_path), providers=["CPUExecutionProvider"]
  )
  onnx_actions = session.run(
      [session.get_outputs()[0].name],
      {session.get_inputs()[0].name: observations},
  )[0]

  # Brax's inference function, called once on the whole batch. Not jitted: this
  # runs once per export, and compiling it costs more than it saves.
  policy_fn = debug_rollout.load_inference_fn(step_dir, deterministic=True)
  jax_actions = np.asarray(
      policy_fn(
          {_STATE_KEY: jp.asarray(observations)}, jax.random.PRNGKey(seed)
      )[0]
  )

  max_diff = float(np.max(np.abs(onnx_actions - jax_actions)))
  print(
      f"Validated on {observations.shape[0]} observations: max |ONNX - JAX| ="
      f" {max_diff:.3e} (tolerance {atol:g})"
  )
  if max_diff > atol:
    raise AssertionError(
        f"The exported ONNX policy disagrees with the Brax policy by"
        f" {max_diff:.3e}, more than the {atol:g} tolerance. It is not a"
        " faithful copy of the checkpoint; do not deploy it."
    )
  return max_diff


# ---------------------------------------------------------------------------
# Runtime metadata
# ---------------------------------------------------------------------------


def _scene_facts() -> dict[str, Any]:
  """Joint limits, home pose, gripper range and cube geometry from the MJCF.

  Compiling the scene with plain MuJoCo (no MJX, no Warp) is enough for these,
  and reading them off the model rather than out of a table is what keeps the
  exported metadata honest when the scene changes.
  """
  scene = xarm6.XMLS_PATH / "mjx_cage_cube.xml"
  model = mujoco.MjModel.from_xml_string(scene.read_text(), xarm6.get_assets())
  arm_joints = [f"joint{i}" for i in range(1, 7)]
  arm_ranges = np.array([model.joint(name).range for name in arm_joints])
  home = model.keyframe("colorado_home")
  cube = model.body("cube")
  cube_geoms = range(cube.geomadr[0], cube.geomadr[0] + cube.geomnum[0])
  cube_half_extents = max(
      (model.geom(i).size for i in cube_geoms),
      key=lambda size: float(np.prod(size)),
  )
  cube_qposadr = int(model.jnt_qposadr[model.joint("cube_freejoint").id])
  return {
      "scene": scene.name,
      "arm_joint_names": arm_joints,
      "joint_limits_lower_rad": [float(x) for x in arm_ranges[:, 0]],
      "joint_limits_upper_rad": [float(x) for x in arm_ranges[:, 1]],
      # The last actuator is the gripper; its ctrlrange is the range the policy
      # integrates its gripper command inside.
      "gripper_ctrl_range": [
          float(x) for x in model.actuator("gripper_act").ctrlrange
      ],
      "home_joint_angles_rad": [float(x) for x in home.qpos[:6]],
      "home_gripper_ctrl": float(home.ctrl[6]),
      "cube_size_full_m": [float(2.0 * x) for x in cube_half_extents],
      "cube_mass_kg": float(cube.mass[0]),
      "cube_spawn_z_m": float(home.qpos[cube_qposadr + 2]),
  }


def _observation_layout(
    env_name: str, env_config: Mapping[str, Any]
) -> dict[str, Any]:
  """The observation's field-by-field layout, from the environment class.

  The controller has to rebuild this vector from sensors, so the metadata
  spells out what each slice of it holds instead of leaving the deployment code
  to track the environment by hand.
  """
  fields = getattr(registry.get_env_class(env_name), "observation_fields", ())
  per_frame = [{"name": name, "dim": int(dim)} for name, dim in fields]
  return {
      "history_len": int(env_config.get("obs_history_len", 1)),
      "frame_order": "oldest frame first, newest last",
      "per_frame_dim": sum(field["dim"] for field in per_frame),
      "per_frame_fields": per_frame,
  }


def build_metadata(
    *,
    env_name: str,
    step_dir: epath.Path,
    onnx_name: str,
    network_config: Mapping[str, Any],
    env_config: Mapping[str, Any],
    observation_size: int,
    action_size: int,
    activation: str,
    hidden_sizes: Sequence[int],
) -> dict[str, Any]:
  """The runtime contract written next to the ONNX file.

  Everything here comes from the checkpoint, the environment config the trainer
  saved with it, or the scene MJCF -- so re-exporting a retrained policy
  re-derives the numbers the robot decodes actions with, instead of letting
  them drift from what the policy was trained on.
  """
  scene = _scene_facts()
  ctrl_dt = float(env_config["ctrl_dt"])
  episode_length = int(env_config["episode_length"])
  target = env_config.get("target_init", {})
  box_init = env_config.get("box_init", {})
  hold_offset = [
      float(target.get("offset_x", 0.0)),
      float(target.get("offset_y", 0.0)),
      float(target.get("offset_z", 0.0)),
  ]
  gripper_range = scene["gripper_ctrl_range"]

  return {
      "policy": {
          "env_name": env_name,
          "checkpoint_step": step_dir.name,
          "checkpoint_path": str(step_dir),
          "onnx_file": onnx_name,
          "input_name": _INPUT_NAME,
          "output_name": _OUTPUT_NAME,
          "observation_shape": [1, observation_size],
          "action_shape": [1, action_size],
          "net_arch": [int(x) for x in hidden_sizes],
          "activation": activation,
          "framework": "brax PPO (MLP, tanh-squashed normal)",
          "deterministic_action": "tanh(action_mean)",
          # The controller feeds raw observations: normalization is part of the
          # graph and must not be applied a second time outside it.
          "observation_normalization": "baked_into_onnx_graph",
      },
      "control": {
          "control_rate_hz": 1.0 / ctrl_dt,
          "ctrl_dt_sec": ctrl_dt,
          "sim_timestep_sec": float(env_config["sim_dt"]),
          "frame_skip": int(round(ctrl_dt / float(env_config["sim_dt"]))),
          "action_repeat": int(env_config.get("action_repeat", 1)),
          "episode_length_steps": episode_length,
          "episode_duration_sec": episode_length * ctrl_dt,
      },
      "action": {
          "dim": action_size,
          "range": [-1.0, 1.0],
          "clip_before_decode": True,
          "arm": {
              "dims": list(range(6)),
              "joint_names": scene["arm_joint_names"],
              "joint_action_scale_rad": float(env_config["joint_action_scale"]),
              "joint_limits_lower_rad": scene["joint_limits_lower_rad"],
              "joint_limits_upper_rad": scene["joint_limits_upper_rad"],
              "gravity_compensation": True,
              "decode": (
                  "per tick: setpoint[i] += action[i] *"
                  " joint_action_scale_rad, clipped to the joint limits, then"
                  " commanded as a joint position setpoint. The setpoint"
                  " persists across ticks and starts at"
                  " initial_arm_setpoint_rad. Training adds a gravity"
                  " feedforward on top of it; the robot's own position servo"
                  " does that itself, so on hardware the setpoint is commanded"
                  " as is."
              ),
          },
          "gripper": {
              "action_index": action_size - 1,
              "driver_joint": "left_driver_joint",
              "action_scale": float(env_config["gripper_action_scale"]),
              "ctrl_range": gripper_range,
              "semantics": (
                  f"{gripper_range[0]:g} = open, {gripper_range[1]:g} = fully"
                  " closed; a positive action closes"
              ),
              "decode": (
                  "per tick: ctrl += action[-1] * action_scale, clipped to"
                  " ctrl_range. The command persists across ticks and starts"
                  " at initial_gripper_ctrl."
              ),
          },
      },
      "observation": {
          "dim": observation_size,
          "dtype": "float32",
          "normalize_observations": bool(
              network_config.get("normalize_observations", True)
          ),
          **_observation_layout(env_name, env_config),
      },
      "robot_setup": {
          "base_frame": (
              "xArm link_base at the origin, +z up; the cube is at negative x."
          ),
          "scene": scene["scene"],
          "home_joint_angles_rad": scene["home_joint_angles_rad"],
          "home_joint_angles_deg": [
              round(float(np.degrees(x)), 2)
              for x in scene["home_joint_angles_rad"]
          ],
          "home_gripper_ctrl": scene["home_gripper_ctrl"],
          "gripper_starts": "open",
          # The integrated setpoint has to start where the arm actually is, or
          # the policy's first delta steps from the wrong pose.
          "initial_arm_setpoint_rad": scene["home_joint_angles_rad"],
          "initial_gripper_ctrl": scene["home_gripper_ctrl"],
      },
      "objects": {
          "cube": {
              "spawn_xy_m": [
                  float(box_init["center_x"]),
                  float(box_init["center_y"]),
              ],
              "spawn_x_range_m": [
                  float(box_init["center_x"] + box_init["x_low"]),
                  float(box_init["center_x"] + box_init["x_high"]),
              ],
              "spawn_y_range_m": [
                  float(box_init["center_y"] + box_init["y_low"]),
                  float(box_init["center_y"] + box_init["y_high"]),
              ],
              "spawn_z_m": scene["cube_spawn_z_m"],
              "size_full_m": scene["cube_size_full_m"],
              "mass_kg": scene["cube_mass_kg"],
          },
          "target": {
              "type": "virtual (a hold pose relative to the cube spawn)",
              "offset_from_cube_m": hold_offset,
          },
      },
      "task": {
          "name": "xarm6-pick-hold",
          "description": (
              f"Grasp the cube and hold it {hold_offset[2]:g} m above where it"
              " spawned."
          ),
          "perception": (
              "The observation contains the cube position, so a cube pose in"
              " the base frame is needed at run time."
          ),
      },
  }


# ---------------------------------------------------------------------------
# YAML output
# ---------------------------------------------------------------------------


def _yaml_scalar(value: Any) -> str:
  if isinstance(value, bool):
    return "true" if value else "false"
  if value is None:
    return "null"
  if isinstance(value, str):
    return json.dumps(value)
  if isinstance(value, float):
    # Round-trippable, but without float noise like 39.99999999999999.
    return repr(round(value, 10))
  return str(value)


def _yaml_lines(value: Any, indent: int) -> list[str]:
  """Emits readable YAML: mappings nest, lists of scalars stay inline.

  Hand-rolled rather than PyYAML, which is not a dependency of the training
  environment and which would quote every key and break these short numeric
  lists across a line each.
  """
  pad = " " * indent
  if isinstance(value, Mapping):
    lines = []
    for key, item in value.items():
      if isinstance(item, Mapping) and item:
        lines.append(f"{pad}{key}:")
        lines += _yaml_lines(item, indent + 2)
      elif isinstance(item, (list, tuple)) and any(
          isinstance(x, (Mapping, list, tuple)) for x in item
      ):
        lines.append(f"{pad}{key}:")
        lines += _yaml_lines(item, indent)
      elif isinstance(item, (list, tuple)):
        inline = ", ".join(_yaml_scalar(x) for x in item)
        lines.append(f"{pad}{key}: [{inline}]")
      else:
        lines.append(f"{pad}{key}: {_yaml_scalar(item)}")
    return lines
  if isinstance(value, (list, tuple)):
    lines = []
    for item in value:
      if isinstance(item, Mapping):
        nested = _yaml_lines(item, indent + 2)
        lines.append(f"{pad}- {nested[0].lstrip()}")
        lines += nested[1:]
      else:
        lines.append(f"{pad}- {_yaml_scalar(item)}")
    return lines
  return [f"{pad}{_yaml_scalar(value)}"]


def write_metadata_yaml(
    path: pathlib.Path, metadata: Mapping[str, Any], header: Sequence[str]
) -> None:
  lines = [f"# {line}" if line else "#" for line in header]
  lines += _yaml_lines(metadata, 0)
  path.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: Sequence[str]) -> None:
  if len(argv) > 1:
    raise app.UsageError(f"Unexpected arguments: {argv[1:]}")

  step_dir = debug_rollout.resolve_checkpoint_path(_CHECKPOINT_PATH.value)
  run_dir = debug_rollout.run_dir_for(step_dir)
  env_name = debug_rollout.infer_env_name_from_run_dir(run_dir)
  if env_name is None:
    raise ValueError(
        f"Cannot tell which environment {run_dir.name} was trained on. The"
        " exported metadata is built from it, so the run directory has to keep"
        " the <env_name>-<timestamp> name the trainer gives it."
    )
  if debug_rollout.checkpoint_uses_vision(step_dir):
    raise ValueError(
        "This checkpoint was trained on pixel observations; only state-only"
        " policies can be exported here."
    )

  network_config = _load_network_config(step_dir)
  env_config = _load_env_config(step_dir)
  observation_size = _observation_size(network_config)
  action_size = int(network_config["action_size"])
  activation = str(
      network_config.get("network_factory_kwargs", {}).get("activation", "silu")
  )

  normalizer_state, policy_params = ppo_checkpoint.load(step_dir)[:2]
  mean, std = _running_statistics(normalizer_state, observation_size)
  layers = _policy_layers(policy_params)
  _check_layer_shapes(layers, observation_size, action_size)
  hidden_sizes = [int(bias.shape[0]) for _, bias in layers[:-1]]

  print(f"Environment: {env_name}")
  print(f"Checkpoint:  {step_dir}")
  print(
      f"Policy:      {observation_size} -> {hidden_sizes} ->"
      f" {2 * action_size} ({activation}), action {action_size}-D"
  )

  name = _NAME.value or run_dir.name
  output_dir = pathlib.Path(
      _OUTPUT_DIR.value if _OUTPUT_DIR.value else str(run_dir / _EXPORT_SUBDIR)
  ).expanduser().resolve()
  output_dir.mkdir(parents=True, exist_ok=True)
  onnx_path = output_dir / f"{name}.onnx"
  metadata_path = output_dir / f"{name}.yaml"

  model = build_onnx_policy(mean, std, layers, action_size, activation)
  onnx.checker.check_model(model)
  onnx.save(model, str(onnx_path))
  print(f"Wrote {onnx_path}")

  if _SKIP_VALIDATION.value:
    print(
        "Skipped the check against the Brax policy (--skip_validation): this"
        " export is unverified and should not be deployed."
    )
  else:
    validate_onnx_policy(
        onnx_path,
        step_dir,
        mean,
        std,
        num_samples=_NUM_VALIDATION_SAMPLES.value,
        seed=_SEED.value,
        atol=_ATOL.value,
    )

  write_metadata_yaml(
      metadata_path,
      build_metadata(
          env_name=env_name,
          step_dir=step_dir,
          onnx_name=onnx_path.name,
          network_config=network_config,
          env_config=env_config,
          observation_size=observation_size,
          action_size=action_size,
          activation=activation,
          hidden_sizes=hidden_sizes,
      ),
      header=[
          f"Runtime contract for {onnx_path.name}, written by",
          "training/export_policy_to_onnx.py.",
          "",
          "Derived from the checkpoint, the environment config saved with it,",
          "and the scene MJCF: change the environment and re-export rather",
          "than editing this file.",
      ],
  )
  print(f"Wrote {metadata_path}")


if __name__ == "__main__":
  app.run(main)
