# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Training environments, scenes and assets built on MuJoCo Playground.

Importing this package registers everything it defines with the Playground
registries and teaches ``learning/train_jax_ppo.py`` where to find the matching
PPO hyperparameters, so the upstream trainer can run these environments by name:

    import training
    from mujoco_playground import registry

    env = registry.load("XArm6Pick")

See ``train_jax_ppo.py`` in this directory for the training entry point and
``README.md`` for how to add an environment, a scene or an asset.
"""

from training import registry
from training.registry import all_envs
from training.registry import register_environment

# Import order matters: the suite packages register their envs into the tables
# that the RL-config hooks below read.
from training import manipulation

manipulation.register()
registry.install_rl_config_hooks()

__all__ = ["all_envs", "manipulation", "register_environment", "registry"]
