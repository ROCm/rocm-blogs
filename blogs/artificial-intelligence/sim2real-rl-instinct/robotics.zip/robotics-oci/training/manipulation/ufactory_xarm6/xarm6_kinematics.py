# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Compute forward and inverse kinematics for the UFactory xArm6.

Pattern adapted from:
https://github.com/google-deepmind/mujoco_playground/blob/main/mujoco_playground/_src/manipulation/franka_emika_panda/panda_kinematics.py
"""

import jax
import jax.numpy as jp


def _wrap_to_pi(x: jax.Array) -> jax.Array:
  return jp.atan2(jp.sin(x), jp.cos(x))


def _rot_x(a: jax.Array) -> jax.Array:
  ca, sa = jp.cos(a), jp.sin(a)
  return jp.array([
      [1.0, 0.0, 0.0],
      [0.0, ca, -sa],
      [0.0, sa, ca],
  ])


def _rot_z(t: jax.Array) -> jax.Array:
  ct, st = jp.cos(t), jp.sin(t)
  return jp.array([
      [ct, -st, 0.0],
      [st, ct, 0.0],
      [0.0, 0.0, 1.0],
  ])


def _dh_matrix(
    theta: jax.Array,
    d: float,
    a: float,
    alpha: jax.Array,
) -> jax.Array:
  """Standard DH homogeneous transform."""
  ct, st = jp.cos(theta), jp.sin(theta)
  ca, sa = jp.cos(alpha), jp.sin(alpha)
  return jp.array([
      [ct, -st * ca, st * sa, a * ct],
      [st, ct * ca, -ct * sa, a * st],
      [0.0, sa, ca, d],
      [0.0, 0.0, 0.0, 1.0],
  ])


def _fk_xarm6(
    q: jax.Array,
    t2_offset: float,
    d1: float,
    d4: float,
    d6: float,
    tcp_offset: float,
    a2: float,
    a3: float,
    a5: float,
    base_offset: jax.Array,
) -> tuple[jax.Array, jax.Array]:
  """Forward kinematics to the MuJoCo `link_tcp` site."""
  t01 = _dh_matrix(q[0], d1, 0.0, -jp.pi / 2)
  t12 = _dh_matrix(q[1] + t2_offset, 0.0, a2, 0.0)
  t23 = _dh_matrix(q[2] - t2_offset, 0.0, a3, -jp.pi / 2)
  t34 = _dh_matrix(q[3], d4, 0.0, jp.pi / 2)
  t45 = _dh_matrix(q[4], 0.0, a5, -jp.pi / 2)
  t56 = _dh_matrix(q[5], d6 + tcp_offset, 0.0, 0.0)
  t06 = t01 @ t12 @ t23 @ t34 @ t45 @ t56
  pos = t06[:3, 3] + base_offset
  rot = t06[:3, :3]
  return pos, rot


def _compute_r03(q123: jax.Array, t2_offset: float) -> jax.Array:
  """Rotation from base to frame 3 (standard DH chain)."""
  q1, q2, q3 = q123
  return (
      _rot_z(q1)
      @ _rot_x(-jp.pi / 2)
      @ _rot_z(q2 + t2_offset)
      @ _rot_z(q3 - t2_offset)
      @ _rot_x(-jp.pi / 2)
  )


def _compute_r04(q1234: jax.Array, t2_offset: float) -> jax.Array:
  """Rotation from base to frame 4."""
  return _compute_r03(q1234[:3], t2_offset) @ _rot_z(q1234[3]) @ _rot_x(jp.pi / 2)


def _shift_to_limits(
    theta: jax.Array,
    theta_cur: jax.Array,
    lo: jax.Array,
    hi: jax.Array,
) -> jax.Array:
  """Shift by ±2π to satisfy limits, closest to current angle."""
  cands = jp.array([theta - 2 * jp.pi, theta, theta + 2 * jp.pi], dtype=jp.float32)
  in_range = (cands >= lo) & (cands <= hi)
  dist = jp.where(in_range, jp.abs(cands - theta_cur), jp.inf)
  idx = jp.argmin(dist)
  best = cands[idx]
  all_bad = jp.all(jp.isinf(dist))
  return jp.where(all_bad, jp.nan, best)


def compute_xarm6_ik(
    t_ee: jax.Array, R_desired: jax.Array, q_current: jax.Array
) -> jax.Array:
  """Compute inverse kinematics for xArm6 at MuJoCo `link_tcp` target.

  This implementation keeps the datasheet parameters but fixes two issues:
  1) J1-3 are solved from frame-4 geometry (not frame-5 "wrist center"),
  2) all branches are scored by FK pose error + proximity to current state.

  Args:
    t_ee: End-effector target position in the base link frame.
    R_desired: Desired end-effector rotation matrix in world frame.
    q_current: Current robot joint angles.
  """
  # xArm6 constants (m / rad).
  d1 = 0.267
  d4 = 0.3425
  d6 = 0.097
  tcp_offset = 0.172
  base_offset = jp.array([0.0, 0.0, 0.0], dtype=jp.float32)
  a2 = 0.28948866
  a3 = 0.0775
  a5 = 0.076
  t2_offset = -1.3849179

  q_min = jp.array(
      [-6.2832, -2.059, -3.927, -6.2832, -1.69297, -6.2832], dtype=jp.float32
  )
  q_max = jp.array(
      [6.2832, 2.0944, 0.19198, 6.2832, 3.14159, 6.2832], dtype=jp.float32
  )

  z_tool = R_desired[:, 2]
  p5 = t_ee - z_tool * (d6 + tcp_offset)

  best_q = jp.full((6,), jp.nan, dtype=jp.float32)
  best_cost = jp.inf
  q_guess = q_current

  # Small fixed-point loop: estimate frame-4 position from q5-dependent offset,
  # solve closed-form branches, then pick best valid candidate.
  for _ in range(4):
    r04_guess = _compute_r04(q_guess[:4], t2_offset)
    offset45 = r04_guess @ jp.array([
        a5 * jp.cos(q_guess[4]),
        a5 * jp.sin(q_guess[4]),
        0.0,
    ], dtype=jp.float32)
    p4 = p5 - offset45

    p4_rel = p4 - base_offset
    rho = jp.sqrt(p4_rel[0] ** 2 + p4_rel[1] ** 2)
    zp = p4_rel[2] - d1
    l34 = jp.sqrt(a3**2 + d4**2)
    beta = jp.atan2(d4, a3)
    base_ang = jp.atan2(p4_rel[1], p4_rel[0])

    q123_candidates = []
    q123_valid = []
    for radial_sign in (1.0, -1.0):
      x_plane = radial_sign * rho
      y_plane = -zp
      rr2 = x_plane**2 + y_plane**2
      c = (rr2 - a2**2 - l34**2) / (2 * a2 * l34)
      reachable = (c >= -1.0) & (c <= 1.0)
      c = jp.clip(c, -1.0, 1.0)
      gamma = jp.atan2(y_plane, x_plane)
      q1 = _wrap_to_pi(base_ang + (jp.pi if radial_sign < 0 else 0.0))

      for elbow_sign in (1.0, -1.0):
        w = elbow_sign * jp.arccos(c)
        u = gamma - jp.atan2(l34 * jp.sin(w), a2 + l34 * jp.cos(w))
        q2 = _wrap_to_pi(u - t2_offset)
        q3 = _wrap_to_pi(w + t2_offset - beta)
        q123_candidates.append(jp.array([q1, q2, q3], dtype=jp.float32))
        q123_valid.append(reachable)

    q123_candidates = jp.stack(q123_candidates)  # (4, 3)
    q123_valid = jp.stack(q123_valid)  # (4,)

    all_q = []
    all_cost = []
    for i in range(4):
      q123 = q123_candidates[i]
      r03 = _compute_r03(q123, t2_offset)
      r36 = r03.T @ R_desired

      c5 = jp.clip(r36[2, 2], -1.0, 1.0)
      q5 = jp.atan2(jp.sqrt(r36[0, 2] ** 2 + r36[1, 2] ** 2), c5)
      s5 = jp.sin(q5)
      wrist_singular = jp.abs(s5) < 1e-6

      q4 = jp.atan2(-r36[1, 2], -r36[0, 2])
      q6 = jp.atan2(-r36[2, 1], r36[2, 0])
      phi = jp.atan2(r36[1, 0], r36[0, 0])  # q4 + q6 when q5 ~= 0
      q4 = jp.where(wrist_singular, q_current[3], q4)
      q6 = jp.where(wrist_singular, phi - q_current[3], q6)

      q456_up = jp.array([_wrap_to_pi(q4), _wrap_to_pi(q5), _wrap_to_pi(q6)])
      q456_down = jp.array([
          _wrap_to_pi(q4 + jp.pi),
          _wrap_to_pi(-q5),
          _wrap_to_pi(q6 + jp.pi),
      ])

      for q456 in (q456_up, q456_down):
        q_raw = jp.concatenate([q123, q456], axis=0)
        q_limited = jp.array([
            _shift_to_limits(q_raw[0], q_current[0], q_min[0], q_max[0]),
            _shift_to_limits(q_raw[1], q_current[1], q_min[1], q_max[1]),
            _shift_to_limits(q_raw[2], q_current[2], q_min[2], q_max[2]),
            _shift_to_limits(q_raw[3], q_current[3], q_min[3], q_max[3]),
            _shift_to_limits(q_raw[4], q_current[4], q_min[4], q_max[4]),
            _shift_to_limits(q_raw[5], q_current[5], q_min[5], q_max[5]),
        ], dtype=jp.float32)

        pos_fk, rot_fk = _fk_xarm6(
            q_limited,
            t2_offset=t2_offset,
            d1=d1,
            d4=d4,
            d6=d6,
            tcp_offset=tcp_offset,
            a2=a2,
            a3=a3,
            a5=a5,
            base_offset=base_offset,
        )

        pos_err = jp.linalg.norm(pos_fk - t_ee)
        rot_err = jp.linalg.norm(rot_fk - R_desired)
        cur_err = jp.linalg.norm(_wrap_to_pi(q_limited - q_current))
        cost = pos_err + 0.25 * rot_err + 0.02 * cur_err

        valid = q123_valid[i] & jp.all(jp.isfinite(q_limited))
        cost = jp.where(valid, cost, jp.inf)

        all_q.append(q_limited)
        all_cost.append(cost)

    cand_q = jp.stack(all_q)  # (8, 6)
    cand_cost = jp.stack(all_cost)  # (8,)
    iter_idx = jp.argmin(cand_cost)
    iter_q = cand_q[iter_idx]
    iter_cost = cand_cost[iter_idx]

    has_valid = jp.isfinite(iter_cost)
    q_guess = jp.where(has_valid, iter_q, q_guess)

    is_better = iter_cost < best_cost
    best_cost = jp.where(is_better, iter_cost, best_cost)
    best_q = jp.where(is_better, iter_q, best_q)

  return jp.where(
      jp.isfinite(best_cost),
      best_q,
      jp.full((6,), jp.nan, dtype=jp.float32),
  )