# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""xArm6 pick-and-hold: grasp the cube and hold it 0.25 m above its spawn.

What defines the task:

* Observation (188-D): four stacked frames of a 47-D proprioceptive frame --
  arm+gripper qpos (7), arm qvel (6), TCP position (3), two rows of the TCP
  rotation (6), commanded-minus-measured setpoint lead (7), cube position and
  orientation relative to the TCP (9), target relative to the cube (6), and
  finger contact + gripper force (3). The frame stack gives the memoryless MLP
  the temporal window it needs to infer contact and lift phase.
* Reward: dense approach -> grasp -> lift -> hold, plus a potential-based
  ``engage`` term that pulls the cube deeper between the finger pads and the
  anti-release terms that keep the gripper shut once it has grasped.
* Sim2real: the gripper is slow (per-episode command lag of 2-6 s), the arm is
  velocity-limited (~0.6-1.0 rad/s, the measured hardware ceiling), cube
  perception is biased, noisy and stale (refreshed every 16-24 control steps,
  matching the ~2 Hz real segmentation), and finger contact drops out 10% of
  steps. All of it perturbs observations or in-graph state only -- the batched
  physics stays deterministic apart from the arm servo gains randomized by
  ``domain_randomize``.
"""

import inspect
from typing import Any, Dict, Optional, Tuple, Union

import jax
import jax.numpy as jp
from ml_collections import config_dict
import mujoco
from mujoco import mjx
from mujoco.mjx._src import math
from mujoco_playground._src import mjx_env
from mujoco_playground._src.mjx_env import State
import numpy as np

from training.manipulation.ufactory_xarm6 import xarm6

_ARM_JOINTS = [
    "joint1",
    "joint2",
    "joint3",
    "joint4",
    "joint5",
    "joint6",
]
_GRIPPER_JOINTS = ["left_driver_joint", "right_driver_joint"]
# Only the driver joint is observable; the second finger follows it via tendon.
_OBS_JOINTS = _ARM_JOINTS + _GRIPPER_JOINTS[0:1]


def _tolerance_long_tail(
    x: jax.Array,
    lo: float,
    hi: float,
    margin: jax.Array,
    value_at_margin: float,
    margin_eps: float,
) -> jax.Array:
  """Port of Metaworld's ``reward_utils.tolerance`` (long_tail sigmoid).

  Returns 1 inside ``[lo, hi]`` and decays sigmoidally outside, reaching
  ``value_at_margin`` at ``margin`` distance from the nearest bound. ``margin``
  is floored at ``margin_eps`` so it never divides by ~0
  """
  margin = jp.maximum(margin, margin_eps)
  in_bounds = (lo <= x) & (x <= hi)
  d = jp.where(x < lo, lo - x, x - hi) / margin
  scale = jp.sqrt(1.0 / value_at_margin - 1.0)
  sigmoid = 1.0 / ((d * scale) ** 2 + 1.0)
  return jp.where(in_bounds, 1.0, sigmoid)


def _hamacher_product(a: jax.Array, b: jax.Array) -> jax.Array:
  """Port of ``reward_utils.hamacher_product``: (a*b) / (a + b - a*b)."""
  denom = a + b - a * b
  return jp.where(denom > 0.0, a * b / denom, 0.0)


def default_config() -> config_dict.ConfigDict:
  """Returns the default config for the xArm6 pick-and-hold task."""
  config = config_dict.create(
      impl="warp",
      ctrl_dt=0.025,
      sim_dt=0.0025,
      episode_length=400,
      action_repeat=1,
      # Per-step joint-angle delta (rad) for the 6 arm actions, and per-step
      # ctrl delta for the proportional gripper action (positive closes,
      # negative opens, near-zero holds). Both integrate onto the previous
      # setpoint and are clipped to the actuator range in step().
      joint_action_scale=0.02,
      gripper_action_scale=0.085,
      # Gripper position-actuator gains / force limit, written onto the
      # ``gripper_act`` actuator in __init__ (overriding the MJCF defaults).
      gripper_kp=400.0,
      gripper_kv=5.0,
      gripper_forcerange=(-30.0, 30.0),
      # --- Actuation lag ---------------------------------------------------
      # Arm command latency (s), applied as the dyntype=filterexact time
      # constant on the 6 arm actuators. 0.02 s models the real controller's
      # mode-1 servo streaming (tight tracking); ~0.12 s would model mode-6
      # online trajectory planning (smoother, more lag).
      arm_ctrl_tau=0.02,
      # Gripper command latency (s), sampled per-episode and applied IN-GRAPH
      # (a pure-JAX first-order filter in step(), tau carried in info) rather
      # than through the model's actuator_dynprm. The model's own gripper
      # filter is neutralized to a passthrough in __init__, so this range is
      # the only gripper lag. In-graph because batching actuator_dynprm makes
      # the filterexact activation integration per-env inside the Warp kernel,
      # which stalls the JAX<->Warp FFI on warp-lang 1.13.
      # The real gripper's policy-level close lag is seconds, not the ideal
      # servo's ~0.25 s, and it is poorly known -- hence the wide 2-6 s span.
      grip_ctrl_tau_range=(2.0, 6.0),
      # Per-episode arm joint-velocity ceiling (rad/s), applied in step() as a
      # clamp on the per-step setpoint advance. The real xArm6 saturates at a
      # hard ~0.82 rad/s regardless of the commanded speed; without the cap the
      # sim arm tracks its setpoint almost exactly, so the setpoint-lead term
      # of the observation (which the policy leans on heavily) is an order of
      # magnitude smaller in sim than on hardware.
      arm_vmax_range=(0.6, 1.0),
      # Arm servo gain randomization multipliers, used by ``domain_randomize``:
      # kp *= U(1-mult, 1+mult) and kv *= U(1-mult, 1+mult). kv matters because
      # it shapes how the arm lags under the velocity limiter above.
      arm_kp_rand_mult=0.3,
      arm_kv_rand_mult=0.2,
      # Number of stacked observation frames. The task is a POMDP (contact and
      # grasp phase are not in a single frame) and frame stacking buys a
      # memoryless MLP most of what recurrence would.
      obs_history_len=4,
      # --- Observation-space domain randomization --------------------------
      # Everything here perturbs the policy observation; physics is untouched.
      # (Batched physics randomization was tried and prevented convergence.)
      # Perceived cube position: per-episode correlated bias U(+-cube_bias_*)
      # plus per-step gaussian noise, sized from the measured hardware error.
      cube_bias_xy=0.03,
      cube_bias_z=0.02,
      cube_obs_noise=0.005,
      # Perception staleness: the perceived cube position is latched and
      # refreshed only every ~U(lo, hi) control steps (real segmentation runs
      # at ~2 Hz against a 40 Hz control loop), with a fresh independent jump
      # at each refresh since each detection is its own noisy estimate. Between
      # refreshes the cube-relative observation drifts from arm motion alone.
      perception_stale_ticks=(16, 24),
      perception_jump_std=0.008,
      # Finger contact: per-step probability of a false-negative dropout, plus
      # gaussian noise on the gripper force. Training through dropped contact
      # is what stops the policy releasing the instant its contact signal
      # flickers, which is how it failed on hardware.
      contact_dropout_prob=0.10,
      contact_force_noise=0.5,
      # Gripper-position readback: per-episode correlated bias + per-step
      # gaussian, modelling the measured gripper readback lag/noise.
      grip_obs_noise=0.02,
      # --- Reward ----------------------------------------------------------
      reward_config=config_dict.create(
          scales=config_dict.create(
              # Dense distance potential: pays the reduction in the closest-ever
              # TCP->cube distance. Gives a gradient toward the cube from far
              # away, but its total is bounded by the initial distance, so it
              # cannot be farmed by hovering.
              approach=40.0,
              # ONE-TIME bonus on the first grasp, credited only if the grasp
              # happened while the TCP was aligned over the cube (align_xy_tol).
              grasp=40.0,
              # PER-STEP height-while-grasped, ramping 0->1 as the cube rises to
              # hold_height. The only way to keep earning after a grasp is to
              # raise the cube, so there is no plateau at z=0 to camp.
              lift=10.0,
              # PER-STEP bonus while the grasped cube is above hold_height --
              # the task itself, and the dominant ongoing term.
              hold=16.0,
              # Seating depth potential: pays the increase in best-ever
              # (held * depth quality), pulling the cube deeper between the pads
              # instead of a fingertip pinch. Being a running max it is bounded
              # by the scale and cannot be re-earned by dropping and regrasping.
              engage=40.0,
              # Anti-release terms. Their magnitudes live in hold_commit_scale /
              # release_penalty below (the values are scaled inline), so these
              # pass-through scales stay at 1.0.
              hold_commit=1.0,
              release_pen=1.0,
          ),
      ),
      # TCP-to-cube horizontal distance (m) under which the gripper counts as
      # aligned over the cube. Gating the grasp bonus on alignment teaches
      # "hover first, then close" instead of snapping shut on a lucky contact.
      align_xy_tol=0.02,
      # Per-step reward for staying grasped, and penalty for commanding the
      # gripper open while holding the cube. Sized so that keeping the grasp is
      # unambiguously the policy's own behaviour -- on hardware a weaker
      # version of this needed a controller-side grasp lock to compensate.
      hold_commit_scale=5.0,
      release_penalty=15.0,
      # Cube height above its spawn (m) at which lift is complete and the hold
      # bonus engages, plus a small floor so the dense lift term is defined
      # near zero height.
      hold_height=0.20,
      lift_height_eps=0.002,
      # Insertion depth (m) past the finger-pad centers at which the ``engage``
      # seating quality decays to 0. Set to the measured shallow-grasp depth so
      # a fingertip pinch earns ~0 and a fully seated grasp earns 1.
      engage_depth_scale=0.04,
      # Metaworld caging geometry (SawyerPickPlaceEnvV3), ported for this cube.
      # Used for the ``grasped`` condition every reward term gates on, and for
      # the caging diagnostics.
      caging=config_dict.create(
          # Along-axis caging: the signed pad<->cube distance must fall in the
          # [obj_radius, pad_success_margin] band for full (=1) left/right
          # caging.
          obj_radius=0.015,
          pad_success_margin=0.05,
          # Perpendicular caging: TCP<->cube perpendicular distance within this
          # of 0 gives full (=1) perpendicular caging.
          perp_success_margin=0.005,
          # Value the long-tail sigmoid reaches at the margin distance.
          tol_value_at_margin=0.1,
          # Floor on computed margins so it never divides by 0.
          margin_eps=1e-6,
          # Spatial caging above which the cube counts as well-caged; combined
          # with both finger pads touching it, this is ``grasped``.
          gripping_caging_threshold=0.85,
      ),
      # Cube spawn: uniform per-axis offset (m) around the pick center, which is
      # the real cell's pick spot in the robot frame. The +-7 cm span is what
      # makes the grasp generalize across the reachable workspace.
      box_init=config_dict.create(
          center_x=-0.29,
          center_y=-0.02,
          x_low=-0.07,
          x_high=0.07,
          y_low=-0.07,
          y_high=0.07,
      ),
      # Hold target: a fixed point 0.25 m straight above the cube spawn.
      target_init=config_dict.create(
          offset_x=0.0,
          offset_y=0.0,
          offset_z=0.25,
      ),
      # Contact/constraint buffer sizes. The Warp collision pipeline pools
      # contacts across the whole vmapped batch. Too small silently truncates
      # contacts and corrupts the physics, too large runs the GPU out of memory.
      nconmax=16384,
      njmax=16384,
      naccdmax=2048,
  )
  return config


class XArm6Pick(xarm6.XArm6Base):
  """Grasp the cube and hold it 0.25 m above its spawn point.

  See the module docstring for the observation, reward and sim2real design.
  """

  render_debug_fields = (
      "reward/approach",
      "reward/grasp",
      "reward/lift",
      "reward/hold",
      "reward/engage",
      "reward/hold_commit",
      "reward/release_pen",
      "metric/caging",
      "metric/spatial_caging",
      "metric/gripping",
      "metric/grasped",
      "metric/cube_z_gain",
      "metric/box_pos_err",
      "metric/cube_dist_from_start",
      "metric/gripper_actuator_force",
      "out_of_bounds",
  )

  # Diagnostic (non-reward) metrics emitted each step, listed here so reset()
  # can initialize them and keep the metrics pytree consistent.
  extra_metric_fields = (
      "gripper_box_dist",
      "min_gripper_box_dist",
      "final_gripper_box_dist",
      "cube_dist_from_start",
      "final_cube_dist_from_start",
      # Caging value and its sub-components, each dense in [0, 1].
      "caging",
      "spatial_caging",
      "caging_and_gripping",
      "gripping",
      "axis_caging",
      "left_caging",
      "right_caging",
      "perp_caging",
      # 1 when well-caged AND both fingers contact the cube.
      "grasped",
      # Cube<->target error (0.9 position + 0.1 orientation) and its parts.
      "box_target_err",
      "box_pos_err",
      "box_rot_err",
      "gripper_actuator_force",
      # Cube height above its spawn, whether it is above hold_height, and the
      # sum of the grasp/lift/hold terms as a coarse progress signal.
      "cube_z_gain",
      "lifted",
      "stage",
  )

  # Named segments of one observation frame, in concatenation order. The policy
  # observation is ``obs_history_len`` of these frames concatenated.
  observation_fields = (
      (f"arm_grip_qpos_0:{len(_OBS_JOINTS)}", len(_OBS_JOINTS)),
      (f"arm_qvel_0:{len(_ARM_JOINTS)}", len(_ARM_JOINTS)),
      ("tcp_pos3", 3),
      ("gripper_mat_3:9", 6),
      (f"arm_grip_qpos_set_lead_0:{len(_OBS_JOINTS)}", len(_OBS_JOINTS)),
      ("box_from_tcp_vec3", 3),
      ("box_mat_3:9", 6),
      ("target_from_box_vec3", 3),
      ("target_box_rot_err_0:3", 3),
      ("finger_contact2_grip_force1", 3),
  )

  def __init__(
      self,
      config: config_dict.ConfigDict = default_config(),
      config_overrides: Optional[Dict[str, Union[str, int, list[Any]]]] = None,
  ):
    super().__init__(
        xarm6.XMLS_PATH / "mjx_cage_cube.xml",
        config,
        config_overrides,
    )
    self._apply_gripper_actuator_config()
    self._disable_arm_ctrl_clamp()
    self._post_init(obj_name="cube", keyframe="colorado_home")
    self._setup_gravity_comp()

    # Finger-pad / cube contact sensors, used by the ``grasped`` condition and
    # by the contact observation.
    self._finger_cube_sensors = [
        self._mj_model.sensor(name).id
        for name in ["left_finger_target_found", "right_finger_target_found"]
    ]
    self._percept_ticks = tuple(
        int(x) for x in self._config.perception_stale_ticks
    )

  def _apply_gripper_actuator_config(self) -> None:
    """Write the gripper position-actuator gains / force limit from config.

    Sets the ``gripper_act`` servo's kp (gainprm[0] / -biasprm[1]), kv
    (-biasprm[2]) and forcerange on ``self._mj_model``, so the gripper can be
    retuned without editing the MJCF. The mutated model is re-put to MJX by the
    subsequent ``_disable_arm_ctrl_clamp``.
    """
    aid = self._mj_model.actuator("gripper_act").id
    self._gripper_act_id = aid
    kp = float(self._config.gripper_kp)
    kv = float(self._config.gripper_kv)
    lo, hi = (float(x) for x in self._config.gripper_forcerange)
    self._mj_model.actuator_gainprm[aid, 0] = kp
    self._mj_model.actuator_biasprm[aid, 1] = -kp
    self._mj_model.actuator_biasprm[aid, 2] = -kv
    self._mj_model.actuator_forcelimited[aid] = 1
    self._mj_model.actuator_forcerange[aid, 0] = lo
    self._mj_model.actuator_forcerange[aid, 1] = hi
    self._apply_actuator_latency_config()

  def _apply_actuator_latency_config(self) -> None:
    """Write the command-latency filter time constants.

    The XML declares dyntype=filterexact on the arm and gripper actuators (so
    the activation state is allocated at compile time); here the base time
    constants (dynprm[0], seconds) are set from config. The gripper's model
    filter is neutralized to a near-instant passthrough because its lag is
    applied in-graph in step() with a per-episode tau instead.
    """
    m = self._mj_model
    arm_ids = [int(m.actuator(f"{j}_act").id) for j in _ARM_JOINTS]
    grip_id = int(m.actuator("gripper_act").id)
    arm_tau = float(self._config.arm_ctrl_tau)
    for aid in arm_ids:
      if int(m.actuator_dyntype[aid]) != int(mujoco.mjtDyn.mjDYN_NONE):
        m.actuator_dynprm[aid, 0] = arm_tau
    if int(m.actuator_dyntype[grip_id]) != int(mujoco.mjtDyn.mjDYN_NONE):
      m.actuator_dynprm[grip_id, 0] = float(self.sim_dt)

  def _disable_arm_ctrl_clamp(self) -> None:
    """Let the arm command exceed ctrlrange so gravity feedforward can reach
    the joint limits.

    The position servos are pure PD springs, so holding a joint at its limit
    against gravity requires commanding ctrl = limit + bias/kp, which lies
    outside ctrlrange. MuJoCo's internal ctrl clamp is disabled for the arm
    actuators and the *setpoint* (the intended joint angle) is clipped to the
    joint limits explicitly in step() instead. The actuator forcerange still
    caps the realized torque and the joint range still caps qpos.
    """
    self._arm_act_ids = np.array(
        [self._mj_model.actuator(f"{j}_act").id for j in _ARM_JOINTS]
    )
    self._mj_model.actuator_ctrllimited[self._arm_act_ids] = 0
    self._mjx_model = mjx.put_model(self._mj_model, impl=self._config.impl)

  def _setup_gravity_comp(self) -> None:
    """Cache actuator/joint indices used by the gravity-compensated servo."""
    self._arm_qvel_ids = mjx_env.get_qvel_ids(self._mj_model, _ARM_JOINTS)
    # Combined arm + gripper-driver qpos addresses / qvel ids for the
    # observation (6 arm joints + 1 gripper driver joint).
    self._obs_qposadr = np.array([
        self._mj_model.jnt_qposadr[self._mj_model.joint(j).id]
        for j in _OBS_JOINTS
    ])
    self._obs_qvel_ids = mjx_env.get_qvel_ids(self._mj_model, _OBS_JOINTS)
    # Position-actuator proportional gain (gainprm[:, 0]) read from the model so
    # the gravity feedforward (bias/kp) matches the simulated servo exactly.
    self._arm_act_kps = jp.array(
        self._mj_model.actuator_gainprm[self._arm_act_ids, 0]
    )
    # Arm joint-angle setpoint limits (ctrlrange == joint range for the arm).
    self._arm_lowers = jp.array(self._lowers[:6])
    self._arm_uppers = jp.array(self._uppers[:6])

  def reset(self, rng: jax.Array) -> State:
    rng, k_box, k_gtau, k_cube_bias, k_grip_bias, k_vmax, k_ttl = (
        jax.random.split(rng, 7)
    )

    # Cube spawn: uniform xy offset around the pick center; z (the cube's
    # resting half-height) comes from the keyframe.
    box_init = self._config.box_init
    box_pos = jp.array([
        box_init.center_x, box_init.center_y, self._init_obj_pos[2]
    ]) + jax.random.uniform(
        k_box,
        (3,),
        minval=jp.array([box_init.x_low, box_init.y_low, 0.0]),
        maxval=jp.array([box_init.x_high, box_init.y_high, 0.0]),
    )
    target_init = self._config.target_init
    target_pos = box_pos + jp.array(
        [target_init.offset_x, target_init.offset_y, target_init.offset_z]
    )

    init_q = (
        jp.array(self._init_q)
        .at[self._obj_qposadr : self._obj_qposadr + 3]
        .set(box_pos)
    )
    # The constraint-buffer sizing kwarg was renamed nconmax -> naconmax in
    # mjx 3.10; pass whichever name the installed mjx_env.make_data accepts.
    con_kw = (
        "naconmax"
        if "naconmax" in inspect.signature(mjx_env.make_data).parameters
        else "nconmax"
    )
    data = mjx_env.make_data(
        self._mj_model,
        qpos=init_q,
        qvel=jp.zeros(self._mjx_model.nv, dtype=float),
        ctrl=self._init_ctrl,
        impl=self._mjx_model.impl.value,
        njmax=self._config.njmax,
        naccdmax=self._config.naccdmax,
        **{con_kw: self._config.nconmax},
    )
    data = data.replace(
        mocap_pos=data.mocap_pos.at[self._mocap_target, :].set(target_pos),
        mocap_quat=data.mocap_quat.at[self._mocap_target, :].set(
            jp.array([1.0, 0.0, 0.0, 0.0], dtype=float)
        ),
    )
    # make_data does not run forward kinematics, so derived fields (xpos,
    # site_xpos, xmat, ...) are still zero. Run forward once so the reset
    # observation and the caging baselines below reflect the init qpos/mocap.
    data = mjx.forward(self._mjx_model, data)

    # Reset-time geometry for the caging reward: the TCP, both finger pads and
    # the cube. The finger closing axis is measured from the pad separation
    # (the xArm6 fingers separate along a wrist-dependent direction, not a fixed
    # world axis) and stored in the TCP site's LOCAL frame, so each step it can
    # be rotated back out by the current wrist orientation and thus track the
    # wrist as it moves. See ``_gripper_caging_reward``.
    init_tcp = data.site_xpos[self._gripper_site]
    init_left_pad = data.geom_xpos[self._left_finger_geom]
    init_right_pad = data.geom_xpos[self._right_finger_geom]
    close_axis = init_left_pad - init_right_pad
    close_axis_norm = jp.linalg.norm(close_axis)
    close_axis = jp.where(
        close_axis_norm > 1e-8,
        close_axis / jp.where(close_axis_norm > 1e-8, close_axis_norm, 1.0),
        jp.array([1.0, 0.0, 0.0]),
    )
    init_site_mat = data.site_xmat[self._gripper_site].reshape(3, 3)

    reward_keys = list(self._config.reward_config.scales.keys())
    metrics = {
        **{f"raw/{k}": jp.array(0.0) for k in reward_keys},
        **{f"reward/{k}": jp.array(0.0) for k in reward_keys},
        **{f"metric/{k}": jp.array(0.0) for k in self.extra_metric_fields},
        "reward": jp.array(0.0),
        "out_of_bounds": jp.array(0.0, dtype=float),
    }

    tcp_box_dist = jp.linalg.norm(
        data.xpos[self._obj_body] - data.site_xpos[self._gripper_site]
    )
    gtau_lo, gtau_hi = (float(x) for x in self._config.grip_ctrl_tau_range)
    vmax_lo, vmax_hi = (float(x) for x in self._config.arm_vmax_range)
    bias_xy = float(self._config.cube_bias_xy)
    bias_z = float(self._config.cube_bias_z)
    k_cx, k_cy, k_cz = jax.random.split(k_cube_bias, 3)
    info = {
        "rng": rng,
        "target_pos": target_pos,
        # Reset-time caging geometry (see above).
        "caging_obj_init_pos": data.xpos[self._obj_body],
        "caging_init_tcp": init_tcp,
        "caging_init_left_pad": init_left_pad,
        "caging_init_right_pad": init_right_pad,
        "caging_close_axis_local": init_site_mat.T @ close_axis,
        # Diagnostics: closest the TCP ever got to the cube, the current
        # distance, and how far the cube has moved from its spawn.
        "min_gripper_box_dist": tcp_box_dist,
        "gripper_box_dist": tcp_box_dist,
        "cube_dist_from_start": jp.array(0.0),
        # Env-side step counter, used to detect the episode's final step so
        # summary metrics fire even when the episode ends by truncation.
        "step_count": jp.array(0, dtype=jp.int32),
        # Uncompensated arm joint-angle setpoint; actions integrate on this so
        # the gravity feedforward (bias/kp) is applied exactly once per step.
        "arm_qpos_set": jp.array(self._init_ctrl[:6]),
        # Reward state: closest-ever TCP->cube distance (the approach potential
        # baseline), a latch that is 1 once the cube has ever been grasped, and
        # the running-max seating potential behind the ``engage`` term.
        "best_tcp_box_dist": tcp_box_dist,
        "ever_grasped": jp.array(0.0),
        "seat_potential": jp.array(0.0),
        # Per-episode gripper command latency, plus the raw gripper command and
        # its lagged value (the in-graph first-order filter state).
        "grip_tau": jax.random.uniform(
            k_gtau, (), minval=gtau_lo, maxval=gtau_hi
        ),
        "grip_cmd": jp.array(self._init_ctrl[6]),
        "grip_filt": jp.array(self._init_ctrl[6]),
        # Per-episode correlated observation biases.
        "cube_bias": jp.array([
            jax.random.uniform(k_cx, (), minval=-bias_xy, maxval=bias_xy),
            jax.random.uniform(k_cy, (), minval=-bias_xy, maxval=bias_xy),
            jax.random.uniform(k_cz, (), minval=-bias_z, maxval=bias_z),
        ]),
        "grip_obs_bias": jax.random.normal(k_grip_bias, ())
        * float(self._config.grip_obs_noise),
        # Per-episode arm joint-velocity ceiling (rad/s).
        "arm_vmax": jax.random.uniform(
            k_vmax, (), minval=vmax_lo, maxval=vmax_hi
        ),
        # Latched perceived cube position and the countdown to its refresh.
        "cube_perceived": data.xpos[self._obj_body],
        "percept_ttl": jax.random.randint(
            k_ttl, (), self._percept_ticks[0], self._percept_ticks[1] + 1
        ),
    }

    obs = self._get_obs(data, info)
    # Frame stacking: seed the history with copies of the reset frame.
    if self._config.obs_history_len > 1:
      hist = jp.broadcast_to(
          obs["state"],
          (self._config.obs_history_len,) + obs["state"].shape,
      )
      info["obs_frame_hist"] = hist
      obs = {"state": hist.reshape(-1)}
    reward, done = jp.zeros(2)
    return State(data, obs, reward, done, metrics, info)

  def step(self, state: State, action: jax.Array) -> State:
    action = jp.clip(action, -1.0, 1.0)
    data_in = state.data
    info = state.info

    # Arm: integrate the action delta onto the setpoint, cap the per-step
    # advance at the episode's joint-velocity ceiling, then clip to the joint
    # limits.
    arm_prev_set = info["arm_qpos_set"]
    arm_qpos_set = arm_prev_set + action[:6] * self._config.joint_action_scale
    max_advance = info["arm_vmax"] * self.dt
    arm_qpos_set = arm_prev_set + jp.clip(
        arm_qpos_set - arm_prev_set, -max_advance, max_advance
    )
    arm_qpos_set = jp.clip(arm_qpos_set, self._arm_lowers, self._arm_uppers)
    # Gravity (+Coriolis) compensation: position servos are pure PD springs, so
    # they settle at q = ctrl - bias/kp. Pre-bias the command by +bias/kp so the
    # realized joint angle lands on the setpoint. The command may exceed
    # ctrlrange near joint limits; the arm's ctrl clamp is disabled (see
    # _disable_arm_ctrl_clamp) and forcerange still caps the torque.
    arm_ctrl = (
        arm_qpos_set
        + data_in.qfrc_bias[self._arm_qvel_ids] / self._arm_act_kps
    )

    # Gripper: integrate the action delta onto the previous RAW command, then
    # run it through the per-episode first-order lag so the actuator sees the
    # lagged command (exact discretization, alpha = 1 - exp(-dt/tau)).
    grip_cmd = jp.clip(
        info["grip_cmd"] + action[6] * self._config.gripper_action_scale,
        self._lowers[6],
        self._uppers[6],
    )
    alpha = 1.0 - jp.exp(-self.dt / info["grip_tau"])
    grip_filt = info["grip_filt"] + alpha * (grip_cmd - info["grip_filt"])
    info["grip_cmd"] = grip_cmd
    info["grip_filt"] = grip_filt

    ctrl = jp.array(data_in.ctrl).at[:6].set(arm_ctrl).at[6].set(grip_filt)
    data = mjx_env.step(self._mjx_model, data_in, ctrl, self.n_substeps)
    info["arm_qpos_set"] = arm_qpos_set

    has_nan = jp.isnan(data.qpos).any() | jp.isnan(data.qvel).any()

    raw_rewards, extra_metrics = self._get_reward_update_info(data, info)
    rewards = {
        k: v * self._config.reward_config.scales[k]
        for k, v in raw_rewards.items()
    }
    reward = sum(rewards.values())
    reward = jp.where(jp.isnan(reward), 0.0, reward)

    box_pos = data.xpos[self._obj_body]
    out_of_bounds = jp.any(jp.abs(box_pos) > 1.0)
    out_of_bounds |= box_pos[2] < 0.0
    done = (out_of_bounds | has_nan).astype(float)

    # Episode-summary metrics are emitted only on the final step -- either an
    # early termination or length truncation -- so an eval's per-episode sum
    # equals the value at that step rather than a running total.
    step_count = info["step_count"] + 1
    info["step_count"] = step_count
    is_final_step = (done > 0) | (step_count >= self._config.episode_length)
    extra_metrics["min_gripper_box_dist"] = jp.where(
        is_final_step, info["min_gripper_box_dist"], 0.0
    )
    extra_metrics["final_gripper_box_dist"] = jp.where(
        is_final_step, info["gripper_box_dist"], 0.0
    )
    extra_metrics["final_cube_dist_from_start"] = jp.where(
        is_final_step, info["cube_dist_from_start"], 0.0
    )

    state.metrics.update(
        **{f"raw/{k}": v for k, v in raw_rewards.items()},
        **{f"reward/{k}": v for k, v in rewards.items()},
        **{f"metric/{k}": v for k, v in extra_metrics.items()},
        reward=reward,
        out_of_bounds=out_of_bounds.astype(float),
    )

    obs = self._get_obs(data, info)
    if self._config.obs_history_len > 1:
      hist = jp.concatenate(
          [info["obs_frame_hist"][1:], obs["state"][None]], axis=0
      )
      info["obs_frame_hist"] = hist
      obs = {"state": hist.reshape(-1)}
    return State(data, obs, reward, done, state.metrics, info)

  def _gripper_caging_reward(
      self, data: mjx.Data, info: Dict[str, Any]
  ) -> Dict[str, jax.Array]:
    """Metaworld caging value along the gripper's closing axis, dense in [0, 1].

    Port of ``SawyerPickPlaceEnvV3._gripper_caging_reward``: the Sawyer's
    hard-coded world-y closing axis is replaced by the xArm6's measured finger
    closing axis ``u``, which is cached at reset in the TCP site's local frame
    and rotated into the world here by the CURRENT wrist orientation, so it
    tracks the wrist instead of being frozen at the reset pose.

    Returns the caging value plus its sub-components, each dense in [0, 1], so
    they can be logged for diagnosis. Only the ``spatial_caging`` component
    feeds the reward (through the ``grasped`` condition); the rest are metrics.
    """
    site_mat = data.site_xmat[self._gripper_site].reshape(3, 3)
    u = site_mat @ info["caging_close_axis_local"]
    obj_pos = data.xpos[self._obj_body]
    tcp = data.site_xpos[self._gripper_site]
    left_pad = data.geom_xpos[self._left_finger_geom]
    right_pad = data.geom_xpos[self._right_finger_geom]
    init_left_pad = info["caging_init_left_pad"]
    init_right_pad = info["caging_init_right_pad"]
    init_tcp = info["caging_init_tcp"]
    obj_init_pos = info["caging_obj_init_pos"]

    cfg = self._config.caging

    # Signed cube<->pad distances along the closing axis.
    delta_left = jp.dot(left_pad - obj_pos, u)
    delta_right = jp.dot(obj_pos - right_pad, u)
    right_caging_margin = jp.abs(
        jp.abs(jp.dot(obj_pos - init_right_pad, u)) - cfg.pad_success_margin
    )
    left_caging_margin = jp.abs(
        jp.abs(jp.dot(obj_pos - init_left_pad, u)) - cfg.pad_success_margin
    )
    right_caging = _tolerance_long_tail(
        delta_right, cfg.obj_radius, cfg.pad_success_margin,
        right_caging_margin, cfg.tol_value_at_margin, cfg.margin_eps,
    )
    left_caging = _tolerance_long_tail(
        delta_left, cfg.obj_radius, cfg.pad_success_margin,
        left_caging_margin, cfg.tol_value_at_margin, cfg.margin_eps,
    )
    axis_caging = _hamacher_product(left_caging, right_caging)

    # TCP<->cube distance in the plane perpendicular to the closing axis.
    def _perp(p: jax.Array) -> jax.Array:
      return p - jp.dot(p, u) * u

    tcp_obj_norm_perp = jp.linalg.norm(_perp(tcp) - _perp(obj_pos))
    init_perp_margin = (
        jp.linalg.norm(_perp(obj_init_pos) - _perp(init_tcp))
        - cfg.perp_success_margin
    )
    perp_caging = _tolerance_long_tail(
        tcp_obj_norm_perp, 0.0, cfg.perp_success_margin, init_perp_margin,
        cfg.tol_value_at_margin, cfg.margin_eps,
    )

    # Fingers straddling the cube AND the TCP centered on it.
    spatial_caging = _hamacher_product(axis_caging, perp_caging)

    # Gripper-closure factor: once the cube is well-caged, how closed the
    # commanded gripper is. ctrl[6] is the (lagged) position setpoint.
    gripper_closed = jp.clip(
        (data.ctrl[6] - self._lowers[6])
        / (self._uppers[6] - self._lowers[6]),
        0.0,
        1.0,
    )
    gripping = jp.where(
        spatial_caging > cfg.gripping_caging_threshold, gripper_closed, 0.0
    )
    caging_and_gripping = _hamacher_product(spatial_caging, gripping)

    return {
        "caging": (caging_and_gripping + spatial_caging) / 2.0,
        "spatial_caging": spatial_caging,
        "caging_and_gripping": caging_and_gripping,
        "gripping": gripping,
        "axis_caging": axis_caging,
        "left_caging": left_caging,
        "right_caging": right_caging,
        "perp_caging": perp_caging,
    }

  def _get_reward_update_info(
      self, data: mjx.Data, info: Dict[str, Any]
  ) -> Tuple[Dict[str, jax.Array], Dict[str, jax.Array]]:
    """Dense approach -> grasp -> lift -> hold reward, plus diagnostics.

    Returns ``(rewards, metrics)``: the unscaled reward terms (scaled by
    ``reward_config.scales`` in step()) and the diagnostic scalars merged into
    ``state.metrics`` (keys listed in ``extra_metric_fields``).

    The shaping is deliberately camp-proof: ``approach`` and ``engage`` are
    bounded potentials that only pay for progress, ``grasp`` is one-time, and
    the only per-step positives require the cube to actually be up in the air.
    """
    box_pos = data.xpos[self._obj_body]
    gripper_pos = data.site_xpos[self._gripper_site]

    gripper_box_dist = jp.linalg.norm(box_pos - gripper_pos)
    info["gripper_box_dist"] = gripper_box_dist
    info["min_gripper_box_dist"] = jp.minimum(
        info["min_gripper_box_dist"], gripper_box_dist
    )
    cube_dist_from_start = jp.linalg.norm(box_pos - info["caging_obj_init_pos"])
    info["cube_dist_from_start"] = cube_dist_from_start

    # ``grasped``: the cube is well-caged AND both finger pads touch it. Every
    # reward term below gates on it.
    caging_terms = self._gripper_caging_reward(data, info)
    both_fingers_touching = jp.all(
        jp.array([
            data.sensordata[self._mj_model.sensor_adr[sid]] > 0
            for sid in self._finger_cube_sensors
        ])
    )
    grasped = jp.where(
        (
            caging_terms["spatial_caging"]
            > self._config.caging.gripping_caging_threshold
        )
        & both_fingers_touching,
        1.0,
        0.0,
    )

    # approach: the reduction in the closest-ever TCP->cube distance. Dense
    # enough to guide exploration from far away, but bounded by the initial
    # distance, so standing still or oscillating pays nothing.
    prev_best = info["best_tcp_box_dist"]
    new_best = jp.minimum(prev_best, gripper_box_dist)
    info["best_tcp_box_dist"] = new_best
    approach = jp.maximum(prev_best - new_best, 0.0)

    # grasp: one-time on the first grasp, credited only if the TCP was aligned
    # over the cube, which teaches "hover first, then close".
    xy_dist = jp.linalg.norm((box_pos - gripper_pos)[:2])
    aligned = (xy_dist < self._config.align_xy_tol).astype(float)
    ever_grasped = info["ever_grasped"]
    grasp = grasped * (1.0 - ever_grasped) * aligned
    info["ever_grasped"] = jp.maximum(ever_grasped, grasped)

    # Anti-release: pay for staying grasped, and penalize commanding the
    # gripper open while holding the cube. ``data.ctrl[6]`` is the lagged
    # gripper command actually driving the actuator.
    hold_commit = grasped * self._config.hold_commit_scale
    opening_on_cube = grasped * (data.ctrl[6] < 0.4).astype(float)
    release_pen = -opening_on_cube * self._config.release_penalty

    # lift / hold: the per-step positives, both gated on the grasp. lift ramps
    # with height so there is no plateau; hold pays out at the goal height.
    init_z = info["caging_obj_init_pos"][2]
    cube_z_gain = box_pos[2] - init_z
    hold_height = self._config.hold_height
    lifted = (cube_z_gain > hold_height).astype(float)
    lift = grasped * jp.clip(
        cube_z_gain / (hold_height + self._config.lift_height_eps), 0.0, 1.0
    )
    hold = grasped * lifted

    # engage: seating depth is how far the cube sits PAST the finger-pad centers
    # along the gripper's local insertion axis; depth 0 means the cube is seated
    # up between the pad faces, large depth means it is pinched at the
    # fingertips. Spatial caging is blind to this (it saturates on a shallow
    # pinch), so it is measured here and paid as a running-max potential: only
    # an increase in the best-ever (held * depth quality) earns, which pulls
    # toward a deeper seat without creating a "deep OR held" trade-off and
    # without any way to farm it by dropping and regrasping.
    site_mat = data.site_xmat[self._gripper_site].reshape(3, 3)
    pad_center = 0.5 * (
        data.geom_xpos[self._left_finger_geom]
        + data.geom_xpos[self._right_finger_geom]
    )
    seat_depth = jp.abs(jp.dot(box_pos - pad_center, site_mat[:, 2]))
    depth_q = 1.0 - jp.clip(
        seat_depth / self._config.engage_depth_scale, 0.0, 1.0
    )
    prev_seat = info["seat_potential"]
    new_seat = jp.maximum(prev_seat, lifted * depth_q)
    info["seat_potential"] = new_seat
    engage = jp.maximum(new_seat - prev_seat, 0.0)

    rewards = {
        "approach": approach,
        "grasp": grasp,
        "lift": lift,
        "hold": hold,
        "engage": engage,
        "hold_commit": hold_commit,
        "release_pen": release_pen,
    }

    # Cube<->target error, diagnostic only (the reward pays for height, not for
    # closing on the target pose).
    pos_err = jp.linalg.norm(info["target_pos"] - box_pos)
    box_mat = data.xmat[self._obj_body]
    target_mat = math.quat_to_mat(data.mocap_quat[self._mocap_target])
    rot_err = jp.linalg.norm(target_mat.ravel()[:6] - box_mat.ravel()[:6])
    metrics = {
        "gripper_box_dist": gripper_box_dist,
        "cube_dist_from_start": cube_dist_from_start,
        **{
            k: caging_terms[k]
            for k in (
                "caging", "spatial_caging", "caging_and_gripping", "gripping",
                "axis_caging", "left_caging", "right_caging", "perp_caging",
            )
        },
        "grasped": grasped,
        "box_target_err": 0.9 * pos_err + 0.1 * rot_err,
        "box_pos_err": pos_err,
        "box_rot_err": rot_err,
        "gripper_actuator_force": data.actuator_force[self._gripper_act_id],
        "cube_z_gain": cube_z_gain,
        "lifted": lifted,
        "stage": grasp + lift + hold,
    }
    return rewards, metrics

  def _get_obs(self, data: mjx.Data, info: Dict[str, Any]) -> Dict[str, Any]:
    """One 47-D observation frame (see ``observation_fields``)."""
    gripper_pos = data.site_xpos[self._gripper_site]
    gripper_mat = data.site_xmat[self._gripper_site].ravel()
    obs_qpos = data.qpos[self._obs_qposadr]
    arm_qvel = data.qvel[self._obs_qvel_ids][: len(_ARM_JOINTS)]

    # Perturb the perceived gripper-driver position (the last of the 7 qpos)
    # with the per-episode bias + per-step noise.
    rng, k_grip = jax.random.split(info["rng"])
    info["rng"] = rng
    grip_noise = info["grip_obs_bias"] + jax.random.normal(k_grip, ()) * float(
        self._config.grip_obs_noise
    )
    obs_qpos = obs_qpos.at[len(_ARM_JOINTS)].add(grip_noise)

    # Setpoint lead: commanded minus realized position for the 6 arm joints and
    # the gripper driver. The gripper term reports the RAW command rather than
    # the internally lagged one, matching what the deployed controller can
    # build from its own command history.
    ctrl_lead = (
        jp.concatenate([info["arm_qpos_set"], info["grip_cmd"][None]])
        - obs_qpos
    )

    obs = jp.concatenate([
        obs_qpos,
        arm_qvel,
        gripper_pos,
        gripper_mat[3:],  # world-frame y/z basis vectors of the gripper frame
        ctrl_lead,
        *self._object_obs(data, gripper_pos, info),
        *self._contact_obs(data, info),
    ])
    return {"state": obs}

  def _object_obs(
      self, data: mjx.Data, gripper_pos: jax.Array, info: Dict[str, Any]
  ) -> list:
    """Perceived cube pose relative to the TCP, and the target (15 dims).

    The perceived cube position is latched and refreshed only every
    ``perception_stale_ticks`` control steps, so between refreshes the
    cube-relative terms drift purely from arm motion (the TCP is always fresh)
    and then snap, matching a slow segmentation pipeline feeding a fast control
    loop. Each refresh reads the true position plus an independent jump, on top
    of the per-episode bias and per-step noise.
    """
    box_pos = data.xpos[self._obj_body]
    box_mat = data.xmat[self._obj_body].ravel()
    target_mat = math.quat_to_mat(data.mocap_quat[self._mocap_target])

    rng, k_noise, k_jump, k_ttl = jax.random.split(info["rng"], 4)
    info["rng"] = rng
    ttl = info["percept_ttl"] - 1
    refresh = ttl <= 0
    jump = jax.random.normal(k_jump, (3,)) * float(
        self._config.perception_jump_std
    )
    perceived_box = jp.where(refresh, box_pos + jump, info["cube_perceived"])
    info["percept_ttl"] = jp.where(
        refresh,
        jax.random.randint(
            k_ttl, (), self._percept_ticks[0], self._percept_ticks[1] + 1
        ),
        ttl,
    )
    info["cube_perceived"] = perceived_box

    cube_bias = info["cube_bias"]
    cube_noise = jax.random.normal(k_noise, (3,)) * float(
        self._config.cube_obs_noise
    )
    return [
        (perceived_box - gripper_pos) + cube_bias + cube_noise,
        box_mat[3:],  # cube orientation (rows 2 and 3)
        (info["target_pos"] - perceived_box) - cube_bias,
        target_mat.ravel()[:3] - box_mat[:3],  # target-vs-cube rotation error
    ]

  def _contact_obs(self, data: mjx.Data, info: Dict[str, Any]) -> list:
    """Finger-cube contact and gripper force (3 dims).

    This is the 'am I holding it' signal proprioception alone cannot supply.
    The per-step false-negative dropout is what teaches the policy to hold
    through a contact signal that flickers, as the real one does.
    """
    left = data.sensordata[
        self._mj_model.sensor_adr[self._finger_cube_sensors[0]]
    ]
    right = data.sensordata[
        self._mj_model.sensor_adr[self._finger_cube_sensors[1]]
    ]
    force_mag = jp.abs(data.actuator_force[self._gripper_act_id])

    rng, k_left, k_right, k_force = jax.random.split(info["rng"], 4)
    info["rng"] = rng
    p = float(self._config.contact_dropout_prob)
    left = left * (jax.random.uniform(k_left, ()) > p).astype(left.dtype)
    right = right * (jax.random.uniform(k_right, ()) > p).astype(right.dtype)
    force_mag = jp.maximum(
        force_mag
        + jax.random.normal(k_force, ())
        * float(self._config.contact_force_noise),
        0.0,
    )
    return [jp.array([left, right, force_mag])]


def domain_randomize(model: mjx.Model, rng: jax.Array):
  """Per-env randomization of the arm servo gains.

  kp (gainprm[0], with biasprm[1] = -kp kept in sync) and kv (biasprm[2] = -kv)
  are the only model fields randomized: kv shapes how the arm lags under the
  in-graph velocity limiter, so it is randomized alongside kp. Everything else
  the environment randomizes -- gripper latency, perception, contact -- is
  per-episode and lives in the env's own state, either because it is an
  observation-space effect or because batching the model field it would need
  (the filterexact activation in ``actuator_dynprm``) stalls the JAX<->Warp FFI.
  """
  mj_model = XArm6Pick().mj_model
  arm_act_ids = np.array(
      [mj_model.actuator(f"{j}_act").id for j in _ARM_JOINTS]
  )
  config = default_config()
  kp_mult = float(config.arm_kp_rand_mult)
  kv_mult = float(config.arm_kv_rand_mult)

  @jax.vmap
  def rand(rng):
    rng, k_kp, k_kv = jax.random.split(rng, 3)
    kp_scale = jax.random.uniform(
        k_kp, (len(arm_act_ids),), minval=1.0 - kp_mult, maxval=1.0 + kp_mult
    )
    new_arm_kp = model.actuator_gainprm[arm_act_ids, 0] * kp_scale
    gainprm = model.actuator_gainprm.at[arm_act_ids, 0].set(new_arm_kp)
    biasprm = model.actuator_biasprm.at[arm_act_ids, 1].set(-new_arm_kp)
    kv_scale = jax.random.uniform(
        k_kv, (len(arm_act_ids),), minval=1.0 - kv_mult, maxval=1.0 + kv_mult
    )
    new_arm_kv = model.actuator_biasprm[arm_act_ids, 2] * kv_scale
    biasprm = biasprm.at[arm_act_ids, 2].set(new_arm_kv)
    return gainprm, biasprm

  gainprm, biasprm = rand(rng)
  in_axes = jax.tree_util.tree_map(lambda _: None, model)
  in_axes = in_axes.tree_replace({
      "actuator_gainprm": 0,
      "actuator_biasprm": 0,
  })
  model = model.tree_replace({
      "actuator_gainprm": gainprm,
      "actuator_biasprm": biasprm,
  })
  return model, in_axes
