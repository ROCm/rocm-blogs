# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Brax PPO recipes for the xArm6 environments in this package.

Each function has the same signature as
``mujoco_playground.config.manipulation_params.brax_ppo_config`` and starts from
the same defaults (``registry.default_ppo_config``), so only the tuned fields
appear below. ``episode_length`` and ``action_repeat`` come from the env's own
config, so one recipe can serve several envs that differ in control rate.
"""

from typing import Optional

from ml_collections import config_dict

from training import registry


def pick_hold_ppo_config(
    env_name: str, impl: Optional[str] = None
) -> config_dict.ConfigDict:
  """Recipe for ``XArm6Pick``.

  The nets are large (512x3 for both policy and value) because the pick-hold obs
  is proprioception-driven and the task is a harder POMDP.

  ``num_envs`` is 1024 rather than 2048: the Warp contact buffers scale with the
  env count, and at 2048 the narrowphase contact peak overflowed ``nconmax``
  (contacts silently truncated) while raising the buffers ran the GPU out of
  memory.
  """
  rl_config = registry.default_ppo_config(env_name)
  rl_config.update(
      num_timesteps=300_000_000,
      num_envs=1024,
      num_evals=30,
      num_resets_per_eval=10,
      batch_size=512,
      num_minibatches=8,
      num_eval_envs=128,
      unroll_length=32,
      num_updates_per_batch=6,
      discounting=0.97,
      learning_rate=3e-4,
      entropy_cost=1e-2,
      learning_rate_schedule_min_lr=5e-5,
      network_factory=dict(
          policy_hidden_layer_sizes=(512, 512, 512),
          value_hidden_layer_sizes=(512, 512, 512),
      ),
  )
  return rl_config
