# xArm6 environments

One file defines an environment here: `pick.py`, holding `XArm6Pick` — the task
as it is actually trained and deployed.

The remaining modules support it: `xarm6.py` (the `XArm6Base` class, asset
loading and the paths to `xmls/` and `meshes/`), `xarm6_kinematics.py` (inverse
kinematics), and `ppo_params.py` (the PPO recipe).

## `meshes/` — the visual assets

The STLs that `xmls/xarm6.xml` names in its `file="..."` attributes: the six arm
links, the xArm gripper and the RealSense D435 mount. They are vendored from the
`xarm_description` package of
[`xArm-Developer/xarm_ros2`](https://github.com/xArm-Developer/xarm_ros2)
(branch `jazzy`), keeping the relative paths that package uses, because the MJCF
`file` attributes are also the keys of the in-memory asset dict `get_assets()`
builds.

They are **not committed** — the directory is gitignored and downloaded by
`scripts/fetch-xarm6-assets.sh`, which is
[part of step 1 of first-time setup](../../../SETUP.md#1-dependencies-patches-and-meshes).
Until it has run, every environment here fails to build its model. The script
checks each file against a sha256 manifest and is idempotent; `--check` verifies
what is on disk without touching the network, and `--force` re-downloads.

## `pick.py` — the environment to train

`XArm6Pick` grasps a cube and holds it 0.25 m above where it spawned. It is a
self-contained subclass of `XArm6Base`: one class, one `default_config()`, one
`domain_randomize()`, and no branches on variants it does not use. Read this
file to understand what the policy is actually being trained on.

Every config knob it carries takes exactly one value: there is no switch
selecting between actuator backends, observation layouts or reward
formulations, and no reward term that is structurally zero. What the file
contains is what runs.

## Working on these

Try a variant as another config function plus a thin subclass, and register it
in `__init__.py` beside `XArm6Pick`. When one wins, distil it back down the way
this one was: resolve the config switches it takes, delete the paths it does
not, and leave `pick.py` holding exactly one environment.
