# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""UFactory xArm6 manipulation environments.

``pick.py`` holds the environment the deployed policy is trained in. See the
README in this directory for what belongs in which file.

Every environment is registered here with the name it is trained under, the
config function that supplies its defaults, its PPO recipe and (where it has
one) its domain randomizer.
"""

from training import registry
from training.manipulation.ufactory_xarm6 import pick
from training.manipulation.ufactory_xarm6 import ppo_params

# The task, distilled: the environment to train and deploy.
_PICK_ENVS = (
    ("XArm6Pick", pick.XArm6Pick, pick.default_config, pick.domain_randomize),
)


def register() -> None:
  """Registers the xArm6 environments with Playground."""
  for env_name, env_class, config_fn, randomizer in _PICK_ENVS:
    registry.register_environment(
        env_name,
        env_class,
        config_fn,
        ppo_params_fn=ppo_params.pick_hold_ppo_config,
        randomizer=randomizer,
    )
