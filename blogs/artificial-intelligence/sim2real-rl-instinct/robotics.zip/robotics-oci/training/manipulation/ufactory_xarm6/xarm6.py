# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""UFactory xArm6 base class."""

from typing import Any, Dict, Optional, Union

from etils import epath
import jax
import jax.numpy as jp
from ml_collections import config_dict
import mujoco
from mujoco import mjx
import numpy as np

from mujoco_playground._src import mjx_env

from training.manipulation.ufactory_xarm6 import xarm6_kinematics

_ARM_JOINTS = [
    "joint1",
    "joint2",
    "joint3",
    "joint4",
    "joint5",
    "joint6",
]
# The xArm6 gripper uses tendons to couple the driver joints
# We track the driver joints for position sensing
_GRIPPER_JOINTS = ["left_driver_joint", "right_driver_joint"]
_ROBOT_JOINTS = _ARM_JOINTS + _GRIPPER_JOINTS


# Scenes and assets live next to this module rather than under
# ``mjx_env.ROOT_PATH``, so the environments in this package are self-contained
# and the mujoco_playground submodule stays pristine.
ROOT_PATH = epath.Path(__file__).parent
XMLS_PATH = ROOT_PATH / "xmls"
_XARM_MESHES_PATH = ROOT_PATH / "meshes"


def get_assets() -> Dict[str, bytes]:
  """Load all assets needed for xArm6 environments."""
  assets = {}
  # Local XML files
  mjx_env.update_assets(assets, XMLS_PATH, "*.xml")

  # Load meshes with keys that match the MJCF `file="..."` paths.
  #
  # Note: MuJoCo's python viewer loads from the filesystem, but our MJX path
  # loads from an in-memory `assets` dict. The keys in this dict must match the
  # `file` attributes exactly (e.g. "xarm6/visual/link_base.stl").
  mesh_root = _XARM_MESHES_PATH
  for mesh_dir in [
      mesh_root / "xarm6" / "visual",
      mesh_root / "gripper" / "xarm",
      mesh_root / "camera" / "realsense" / "visual",
  ]:
    for mesh_file in mesh_dir.glob("*.stl"):
      rel = mesh_file.relative_to(mesh_root).as_posix()
      assets[rel] = mesh_file.read_bytes()

  return assets


def default_config() -> config_dict.ConfigDict:
  return config_dict.create(
      ctrl_dt=0.02,
      sim_dt=0.002,
      episode_length=150,
      action_repeat=1,
      impl="warp",
      nconmax=12 * 8192,
      njmax=44,
  )


class XArm6Base(mjx_env.MjxEnv):
  """Base environment for UFactory xArm6."""

  def __init__(
      self,
      xml_path: epath.Path,
      config: config_dict.ConfigDict = default_config(),
      config_overrides: Optional[Dict[str, Union[str, int, list[Any]]]] = None,
  ):
    super().__init__(config, config_overrides)

    self._xml_path = xml_path.as_posix()
    xml = xml_path.read_text()
    self._model_assets = get_assets()

    mj_model = mujoco.MjModel.from_xml_string(xml, assets=self._model_assets)
    mj_model.opt.timestep = self.sim_dt
    mj_model.opt.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    self._mj_model = mj_model
    self._mjx_model = mjx.put_model(mj_model, impl=self._config.impl)

  def _post_init(self, obj_name: str, keyframe: str):
    """Initialize robot-specific attributes after model is loaded."""
    self._robot_arm_qposadr = np.array([
        self._mj_model.jnt_qposadr[self._mj_model.joint(j).id]
        for j in _ARM_JOINTS
    ])
    self._robot_qposadr = np.array([
        self._mj_model.jnt_qposadr[self._mj_model.joint(j).id]
        for j in _ROBOT_JOINTS
    ])
    # xArm6 uses "link_tcp" site for the gripper/end-effector
    self._gripper_site = self._mj_model.site("link_tcp").id
    # Finger pad geoms for collision detection
    self._left_finger_geom = self._mj_model.geom("left_finger_pad").id
    self._right_finger_geom = self._mj_model.geom("right_finger_pad").id
    # Object and target
    self._obj_body = self._mj_model.body(obj_name).id
    self._obj_qposadr = self._mj_model.jnt_qposadr[
        self._mj_model.body(obj_name).jntadr[0]
    ]
    self._mocap_target = self._mj_model.body("mocap_target").mocapid
    self._floor_geom = self._mj_model.geom("floor").id
    # Initial state from keyframe
    self._init_q = self._mj_model.keyframe(keyframe).qpos
    self._init_obj_pos = jp.array(
        self._init_q[self._obj_qposadr : self._obj_qposadr + 3],
        dtype=jp.float32,
    )
    self._init_ctrl = self._mj_model.keyframe(keyframe).ctrl
    self._lowers, self._uppers = self._mj_model.actuator_ctrlrange.T

  @property
  def xml_path(self) -> str:
    return self._xml_path

  @property
  def action_size(self) -> int:
    return self.mjx_model.nu

  @property
  def mj_model(self) -> mujoco.MjModel:
    return self._mj_model

  @property
  def mjx_model(self) -> mjx.Model:
    return self._mjx_model

  # =========================================================================
  # Kinematics helper methods
  # =========================================================================

  def get_arm_joint_angles(self, data: mjx.Data) -> jax.Array:
    """Get the 6 arm joint angles from simulation data."""
    return data.qpos[self._robot_arm_qposadr]

  def compute_ik(
      self,
      target_pos: jax.Array,
      target_rot: jax.Array,
      q_current: jax.Array,
  ) -> jax.Array:
    """Compute inverse kinematics for a target TCP pose.

    Args:
      target_pos: Target position for the TCP (3,)
      target_rot: Target rotation matrix for the TCP (3, 3)
      q_current: Current joint configuration (6,)

    Returns:
      Joint angles (6,) that achieve the target pose
    """
    return xarm6_kinematics.compute_xarm6_ik(target_pos, target_rot, q_current)
