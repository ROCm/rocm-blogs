# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Manipulation environments defined by this package."""

from training.manipulation import ufactory_xarm6

_ROBOTS = (ufactory_xarm6,)


def register() -> None:
  """Registers every manipulation environment in this package."""
  for robot in _ROBOTS:
    robot.register()
