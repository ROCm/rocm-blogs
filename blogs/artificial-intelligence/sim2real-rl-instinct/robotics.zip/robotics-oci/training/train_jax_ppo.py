# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Train a PPO agent on the environments defined in this package.

This is a thin front end for MuJoCo Playground's own trainer: it registers the
environments here and then hands over to ``learning/train_jax_ppo.py``, so every
flag that script accepts works unchanged (``--env_name``, ``--impl``,
``--domain_randomization``, ``--num_timesteps``, ``--playground_config_overrides``,
``--load_checkpoint_path``, ...) and upstream envs stay trainable through it too.

Run it with the Playground project's interpreter, e.g. from the repo root:

    docker/dockertrainingrun.sh uv run python train_jax_ppo.py \
      --env_name XArm6Pick --impl warp --domain_randomization

The package directory does not have to be installed: it is imported from its
location below, so the script runs straight out of the checkout.

Runs land in this directory's ``logs/`` unless ``--logdir`` says otherwise.
"""

import importlib.util
import pathlib
import sys

_PACKAGE_ROOT = pathlib.Path(__file__).resolve().parent


def _import_training():
  """Import the ``training`` package this script lives in, to register its envs.

  The package is loaded from its location rather than by putting the repo root
  on ``sys.path``, because the repo root also holds the submodule checkouts
  (``warp/``, ``mujoco/``, ...). Those directories carry no ``__init__.py``, so a
  path entry pointing at the repo root makes them empty namespace packages that
  shadow the editable installs of the same name: setuptools' editable hook is
  *appended* to ``sys.meta_path``, so it is only consulted when the path finder
  came up empty -- and a namespace package counts as a find. ``import warp``
  would then succeed with a module that has nothing in it.
  """
  if "training" in sys.modules:
    return
  spec = importlib.util.spec_from_file_location(
      "training",
      _PACKAGE_ROOT / "__init__.py",
      submodule_search_locations=[str(_PACKAGE_ROOT)],
  )
  module = importlib.util.module_from_spec(spec)
  # Published before it is executed, so the package's own ``from training import
  # ...`` statements bind to the module being created here.
  sys.modules["training"] = module
  spec.loader.exec_module(module)


# pylint: disable=g-import-not-at-top,wrong-import-position
from absl import flags

_import_training()
from learning import train_jax_ppo

# pylint: enable=g-import-not-at-top,wrong-import-position


if __name__ == "__main__":
  # The trainer's own default is "logs" relative to the working directory, so
  # runs would collect wherever they happen to be launched from -- inside the
  # submodule, when that is the Playground checkout. Point them at this package's
  # own logs/ instead, next to the environments they train, wherever the run was
  # started. Overriding the default rather than the value leaves an explicit
  # --logdir winning.
  flags.FLAGS.set_default("logdir", str(_PACKAGE_ROOT / "logs"))
  train_jax_ppo.run()
