# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Checkpoint loading and rollout rendering helpers for trained policies.

Everything here works off a Brax PPO checkpoint written by
``learning/train_jax_ppo.py`` -- the ``logs/<run>/checkpoints/<step>/``
directories the training entry point in this package produces. The
``debug_rollout_render.py`` CLI next to this module is the front end;
the split keeps the flag plumbing separate from the rendering itself so a
notebook or another script can call ``render_debug_rollouts`` directly.

An environment opts into the video overlay by declaring ``render_debug_fields``
-- names of entries in its ``state.metrics`` -- as ``XArm6Pick`` does. Envs
without it still render, just without the text overlay.
"""

import json
import math
import os
import pathlib
from typing import Callable, Sequence

from brax.training import checkpoint as brax_checkpoint
from brax.training import networks as brax_networks
from brax.training.agents.ppo import checkpoint as ppo_checkpoint
from brax.training.agents.ppo import networks as ppo_networks
from etils import epath
import jax
import jax.numpy as jp
import mediapy as media
from ml_collections import config_dict
import mujoco
from mujoco_playground import registry
import numpy as np

# Where runs land by default, resolved from this file rather than from the
# working directory, so a checkpoint is found the same way wherever the script
# was launched from -- matching the --logdir default in train_jax_ppo.py.
DEFAULT_LOGS_ROOT = pathlib.Path(__file__).resolve().parent.parent / "logs"

# MuJoCo's free (orbit) camera, which mjx_env.render_array selects for a
# camera of None. Requesting it by name has to be translated here (see
# _resolve_render_camera).
_FREE_CAMERA = -1
_FREE_CAMERA_NAMES = frozenset({"free", "freecam", "free_camera"})

# Fixed cameras to fall back on, best first, when no camera was requested.
# These are the ones the scenes in this package define (see
# manipulation/ufactory_xarm6/xmls/); a missing name is skipped, so envs from
# elsewhere just end up on the free camera.
_PREFERRED_CAMERAS = ("front", "birdseye", "top")


# ---------------------------------------------------------------------------
# Checkpoint helpers
# ---------------------------------------------------------------------------


def _latest_run_dir(
    logs_root: epath.PathLike = DEFAULT_LOGS_ROOT,
) -> epath.Path:
  """Returns the newest run under ``logs_root`` that has usable checkpoints."""
  root = epath.Path(logs_root).resolve()
  if not root.is_dir():
    raise ValueError(
        f"No --checkpoint_path given and logs directory not found: {root}"
    )

  candidates = []
  for run_dir in root.glob("*"):
    if not run_dir.is_dir():
      continue
    checkpoints_root = run_dir / "checkpoints"
    if not checkpoints_root.is_dir():
      continue
    step_dirs = [
        p for p in checkpoints_root.glob("*") if p.is_dir() and p.name.isdigit()
    ]
    if step_dirs:
      candidates.append(run_dir)

  if not candidates:
    raise ValueError(
        f"No --checkpoint_path given and no run with checkpoints found under"
        f" {root}."
    )

  # os.path.getmtime rather than epath's own stat(): that fills in the file's
  # owner name, which means a pwd lookup of its uid, and inside the training
  # container the host uid has no passwd entry -- so stat() raises KeyError on
  # every run directory the container can otherwise read perfectly well.
  candidates.sort(key=lambda p: os.path.getmtime(p.as_posix()))
  return candidates[-1]


def resolve_checkpoint_path(
    load_checkpoint_path: str | None,
    logs_root: epath.PathLike = DEFAULT_LOGS_ROOT,
) -> epath.Path:
  """Resolves a checkpoint path to a specific Brax step directory.

  Accepts a step directory, a ``checkpoints`` root or a run directory, taking
  the highest step in the latter two cases. With ``None``, the most recently
  modified run under ``logs_root`` is used.
  """
  if load_checkpoint_path is None:
    run_dir = _latest_run_dir(logs_root)
    print(f"No --checkpoint_path given; using most recent run: {run_dir}")
    return resolve_checkpoint_path(run_dir.as_posix(), logs_root)

  ckpt_path = epath.Path(load_checkpoint_path).resolve()
  if not ckpt_path.exists():
    raise ValueError(f"Checkpoint path does not exist: {ckpt_path}")

  if ckpt_path.is_dir() and (
      (ckpt_path / "ppo_network_config.json").exists()
      or (ckpt_path / "_METADATA").exists()
      or (ckpt_path / "checkpoint").exists()
  ):
    return ckpt_path

  checkpoints_root = ckpt_path
  if ckpt_path.name != "checkpoints":
    candidate = ckpt_path / "checkpoints"
    if candidate.is_dir():
      checkpoints_root = candidate

  if checkpoints_root.is_dir():
    step_dirs = [
        p for p in checkpoints_root.glob("*") if p.is_dir() and p.name.isdigit()
    ]
    if step_dirs:
      step_dirs.sort(key=lambda p: int(p.name))
      return step_dirs[-1]
    raise ValueError(
        "No checkpoint step directories found under "
        f"{checkpoints_root} (expected subdirs like 000000010000)."
    )

  raise ValueError(
      f"Checkpoint path must be a directory, got: {ckpt_path.as_posix()}"
  )


def _checkpoints_root_for(step_dir: epath.Path) -> epath.Path:
  if step_dir.parent.name == "checkpoints":
    return step_dir.parent
  return step_dir


def all_checkpoint_step_dirs(step_dir: epath.Path) -> list[epath.Path]:
  """Returns every numbered checkpoint step dir in the run, sorted by step."""
  ckpt_root = _checkpoints_root_for(step_dir)
  step_dirs = [
      p for p in ckpt_root.glob("*") if p.is_dir() and p.name.isdigit()
  ]
  step_dirs.sort(key=lambda p: int(p.name))
  return step_dirs


def run_dir_for(step_dir: epath.Path) -> epath.Path:
  """The ``logs/<run>`` directory a checkpoint step belongs to."""
  return _checkpoints_root_for(step_dir).parent


def training_config_path(step_dir: epath.Path) -> epath.Path:
  """Path of the env config the trainer saved next to the checkpoints."""
  return _checkpoints_root_for(step_dir) / "config.json"


def infer_env_name_from_run_dir(run_dir: epath.Path) -> str | None:
  """Reads the env name back out of a run directory name.

  The trainer names runs ``<env_name>-<timestamp>...``
  """
  name = run_dir.name
  for env_name in sorted(registry.ALL_ENVS, key=len, reverse=True):
    if name == env_name or name.startswith(f"{env_name}-"):
      return env_name
  return None


def checkpoint_uses_vision(step_dir: epath.Path) -> bool:
  """True if the policy was trained on pixel observations."""
  train_cfg_path = training_config_path(step_dir)
  if train_cfg_path.exists():
    try:
      train_cfg = json.loads(train_cfg_path.read_text())
      if train_cfg.get("vision"):
        return True
    except (json.JSONDecodeError, OSError):
      pass

  ppo_cfg_path = step_dir / "ppo_network_config.json"
  if ppo_cfg_path.exists():
    try:
      ppo_cfg = json.loads(ppo_cfg_path.read_text())
      obs_size = ppo_cfg.get("observation_size", None)
      if isinstance(obs_size, dict):
        return any(k.startswith("pixels") for k in obs_size)
    except (json.JSONDecodeError, OSError):
      pass
  return False


def _load_ppo_config(step_dir: epath.Path) -> config_dict.ConfigDict:
  """Loads the PPO network config, tolerating null init fields in old ones."""
  cfg_path = step_dir / "ppo_network_config.json"
  raw = json.loads(cfg_path.read_text())
  nf_kw = dict(raw.get("network_factory_kwargs", {}))
  if "activation" in nf_kw:
    act_name = nf_kw["activation"]
    if act_name is None:
      del nf_kw["activation"]
    else:
      nf_kw["activation"] = brax_networks.ACTIVATION[act_name]
  for key in list(nf_kw):
    if not key.endswith("_init_fn"):
      continue
    init_name = nf_kw[key]
    if init_name is None:
      del nf_kw[key]
    else:
      nf_kw[key] = brax_networks.KERNEL_INITIALIZER[init_name]
  raw["network_factory_kwargs"] = nf_kw
  # Flat-obs envs (e.g. PandaPickCube) serialize observation_size as a single
  # spec dict {"shape": [...], "dtype": ...}. brax's _get_obs_state_size then
  # treats it as a Mapping and indexes [obs_key] -> KeyError. Collapse it back
  # to the plain shape so the non-Mapping branch is used. Dict-obs envs (e.g.
  # the xArm6 envs here) serialize as {"state": {"shape": ...}} and are left
  # untouched.
  obs_size = raw.get("observation_size")
  if isinstance(obs_size, dict) and "shape" in obs_size:
    raw["observation_size"] = tuple(obs_size["shape"])
  return config_dict.create(**raw)


def load_inference_fn(step_dir: epath.Path, deterministic: bool = True):
  """Returns a policy inference function from a checkpoint step.

  When ``deterministic=True`` (default) the policy plays its action mean. Set
  ``deterministic=False`` to sample stochastic actions from the policy's
  distribution (using the per-step RNG), reproducing the exploration noise the
  policy had during training.
  """
  config = _load_ppo_config(step_dir)
  params = ppo_checkpoint.load(step_dir)
  ppo_network = brax_checkpoint.get_network(
      config, ppo_networks.make_ppo_networks
  )
  make_inference_fn = ppo_networks.make_inference_fn(ppo_network)
  return make_inference_fn(params, deterministic=deterministic)


# ---------------------------------------------------------------------------
# Render / debug-field helpers
# ---------------------------------------------------------------------------


def _resolve_render_debug_fields(env) -> tuple[str, ...]:
  """Metrics names to overlay, from ``env.render_debug_fields``.

  Walks the wrapper chain, since the env handed to a rollout is usually wrapped
  and the attribute lives on the innermost env.
  """
  candidate = env
  while candidate is not None:
    fields = getattr(candidate, "render_debug_fields", None)
    if fields:
      return tuple(str(f) for f in fields)
    candidate = getattr(candidate, "env", None)
  return ()


def _format_debug_value(val) -> str:
  arr = np.asarray(val)
  if arr.shape == ():
    x = float(arr)
    if np.isnan(x):
      return "nan"
    return f"{x:.4f}"
  if arr.size <= 3:
    return np.array2string(arr, precision=4, separator=", ")
  return f"<shape {arr.shape}>"


def _camera_id(mj_model, name: str) -> int:
  return mujoco.mj_name2id(mj_model, mujoco.mjtObj.mjOBJ_CAMERA, name)


def _camera_names(mj_model) -> tuple[str, ...]:
  """Names of the model's cameras, skipping unnamed ones (id2name -> None)."""
  names = (
      mujoco.mj_id2name(mj_model, mujoco.mjtObj.mjOBJ_CAMERA, i)
      for i in range(mj_model.ncam)
  )
  return tuple(name for name in names if name)


def _resolve_render_camera(render_env, render_camera: str | None) -> str | int:
  """Turns a camera request into something ``mjx_env.render`` accepts.

  Upstream's ``render_array`` passes the camera straight to
  ``mujoco.Renderer.update_scene``, which only takes a name that exists in the
  model or the id ``-1`` for the free camera. So the free camera is spelled as
  an id here, and a bad name is rejected up front rather than after the whole
  rollout has been simulated.
  """
  mj_model = render_env.mj_model
  if render_camera is None:
    for preferred in _PREFERRED_CAMERAS:
      if _camera_id(mj_model, preferred) != -1:
        return preferred
    return _FREE_CAMERA

  if render_camera.lower() in _FREE_CAMERA_NAMES:
    return _FREE_CAMERA
  if _camera_id(mj_model, render_camera) == -1:
    available = ", ".join(_camera_names(mj_model)) or "(none)"
    raise ValueError(
        f"Unknown --render_camera={render_camera!r}. This model's cameras are:"
        f" {available}. Pass 'free' for the free/orbit camera."
    )
  return render_camera


# ---------------------------------------------------------------------------
# Rollout rendering
# ---------------------------------------------------------------------------


def _load_overlay_font(font_size: int):
  """Load a scalable TrueType font at ``font_size``, falling back gracefully."""
  from PIL import ImageFont

  # Try a few common DejaVu locations first (Pillow ships DejaVuSans).
  for name in ("DejaVuSans.ttf", "DejaVuSansMono.ttf"):
    try:
      return ImageFont.truetype(name, font_size)
    except OSError:
      continue
  # Newer Pillow (>=10) supports a size arg on the built-in bitmap font.
  try:
    return ImageFont.load_default(size=font_size)
  except TypeError:
    return ImageFont.load_default()


def _draw_debug_overlay(
    frame: np.ndarray,
    field_values: dict[str, object],
) -> np.ndarray:
  """Draws debug text for render_debug_fields on an RGB frame.

  Font size, line spacing, and margins scale with the frame height (relative
  to a 480px baseline) so the overlay stays readable at higher resolutions.
  """
  from PIL import Image, ImageDraw

  img = Image.fromarray(frame)
  draw = ImageDraw.Draw(img)

  scale = max(1.0, img.height / 480.0)
  font_size = max(12, round(14 * scale))
  line_gap = round(18 * scale)
  margin = round(10 * scale)
  shadow = max(1, round(scale))
  font = _load_overlay_font(font_size)

  y = round(8 * scale)
  for name, val in field_values.items():
    line = f"{name}: {_format_debug_value(val)}"
    draw.text((margin + shadow, y + shadow), line, fill=(0, 0, 0), font=font)
    draw.text((margin, y), line, fill=(255, 255, 255), font=font)
    y += line_gap
  return np.asarray(img)


def _overlay_debug_on_frames(
    frames: Sequence[np.ndarray],
    field_traces: dict[str, Sequence],
) -> list[np.ndarray]:
  if not field_traces:
    return list(frames)
  out = []
  for step_idx, frame in enumerate(frames):
    values = {name: trace[step_idx] for name, trace in field_traces.items()}
    out.append(_draw_debug_overlay(frame, values))
  return out


def _tile_frames(
    all_frames: list[list[np.ndarray]],
    cols: int,
) -> list[np.ndarray]:
  """Tile per-rollout frame sequences into a single grid video frame sequence.

  Args:
    all_frames: list of N frame sequences, each of length T.  All frames must
      share the same (H, W, 3) shape.
    cols: number of columns in the grid.

  Returns:
    List of T tiled frames, each of shape (rows*H, cols*W, 3).
  """
  n = len(all_frames)
  rows = math.ceil(n / cols)
  n_frames = len(all_frames[0])
  h, w = np.asarray(all_frames[0][0]).shape[:2]
  blank = np.zeros((h, w, 3), dtype=np.uint8)

  tiled = []
  for t in range(n_frames):
    grid_rows = []
    for r in range(rows):
      row_cells = []
      for c in range(cols):
        idx = r * cols + c
        row_cells.append(np.asarray(all_frames[idx][t]) if idx < n else blank)
      grid_rows.append(np.concatenate(row_cells, axis=1))
    tiled.append(np.concatenate(grid_rows, axis=0))
  return tiled


def render_debug_rollouts(
    *,
    eval_env,
    episode_length: int,
    num_videos: int = 1,
    seed: int = 1,
    output_dir: epath.PathLike,
    inference_fn: Callable,
    render_env=None,
    output_prefix: str = "rollout",
    playback_speed: float = 1.0,
    render_fps: float = 30.0,
    render_camera: str | None = None,
    video_height: int = 480,
    video_width: int = 640,
    debug_overlay: bool = True,
    panel: int = 0,
    show_collision_meshes: bool = False,
    visual_opacity: float = 0.3,
    frame: str = "none",
) -> None:
  """Run policy rollouts and save MuJoCo videos with optional debug overlays.

  When ``panel >= 1`` the rollouts are tiled into ``panel``×``panel`` grid
  videos: every ``panel*panel`` consecutive rollouts become one panel file.
  With ``N`` rollouts this writes ``ceil(N / panel**2)`` files, named
  ``{output_prefix}_panel.mp4`` for a single panel or
  ``{output_prefix}_panel{k}.mp4`` when there is more than one. ``panel <= 0``
  (the default) writes one file per rollout instead.

  When ``show_collision_meshes=True`` the convex-hull collision geometry is
  overlaid on the scene and all visual geoms are rendered at ``visual_opacity``
  (0 = fully transparent, 1 = fully opaque).
  """
  if playback_speed <= 0:
    raise ValueError("playback_speed must be > 0")
  if render_fps <= 0:
    raise ValueError("render_fps must be > 0")

  render_env = eval_env if render_env is None else render_env
  jit_inference_fn = jax.jit(inference_fn)
  render_debug_fields = _resolve_render_debug_fields(eval_env)

  # Resolved before the rollouts run so a bad camera name fails immediately.
  render_camera = _resolve_render_camera(render_env, render_camera)

  def do_rollout(rng, state):
    empty_data = state.data.__class__(
        **{k: None for k in state.data.__annotations__}
    )
    empty_traj = state.__class__(**{k: None for k in state.__annotations__})
    empty_traj = empty_traj.replace(data=empty_data)

    def step(carry, _):
      state, rng = carry
      rng, act_key = jax.random.split(rng)
      act = jit_inference_fn(state.obs, act_key)[0]
      state = eval_env.step(state, act)
      # Only the fields render_array reads are kept, so the trajectory that
      # comes out of the scan stays small enough to hold for a whole episode.
      traj_data = empty_traj.tree_replace({
          "data.qpos": state.data.qpos,
          "data.qvel": state.data.qvel,
          "data.time": state.data.time,
          "data.ctrl": state.data.ctrl,
          "data.mocap_pos": state.data.mocap_pos,
          "data.mocap_quat": state.data.mocap_quat,
          "data.xfrc_applied": state.data.xfrc_applied,
      })
      debug_vals = tuple(state.metrics[f] for f in render_debug_fields)
      return (state, rng), (traj_data, state.done, debug_vals)

    _, (traj, dones, debug_vals) = jax.lax.scan(
        step, (state, rng), None, length=episode_length
    )
    return traj, dones, debug_vals

  print(
      f"Running {num_videos} rollout(s): episode_length={episode_length}, "
      f"seed={seed}"
  )
  rng = jax.random.split(jax.random.PRNGKey(seed), num_videos)
  reset_states = jax.jit(jax.vmap(eval_env.reset))(rng)
  if render_debug_fields:
    print(f"Debug overlay fields: {', '.join(render_debug_fields)}")
  else:
    print("No env.render_debug_fields; skipping debug text overlay.")

  traj_stacked, dones_stacked, debug_stacked = jax.jit(jax.vmap(do_rollout))(
      rng, reset_states
  )

  trajectories = []
  debug_traces = []
  for i in range(num_videos):
    t = jax.tree.map(lambda x, i=i: x[i], traj_stacked)
    trajectories.append(
        [jax.tree.map(lambda x, j=j: x[j], t) for j in range(episode_length)]
    )
    if render_debug_fields:
      debug_traces.append({
          name: np.asarray(debug_stacked[j][i], dtype=np.float32)
          for j, name in enumerate(render_debug_fields)
      })
    else:
      debug_traces.append({})
    dones_i = dones_stacked[i]
    first_done = int(jp.argmax(dones_i))
    if dones_i[first_done] > 0:
      t_sec = float(first_done * eval_env.dt)
      print(f"Rollout {i}: episode done at step {first_done} (t={t_sec:.2f}s)")
    else:
      print(
          f"Rollout {i}: episode ran full {episode_length} steps "
          "(no early termination)"
      )

  output_dir = epath.Path(output_dir).resolve()
  output_dir.mkdir(parents=True, exist_ok=True)

  render_every = max(1, round(playback_speed / (render_fps * render_env.dt)))
  fps = playback_speed / (render_env.dt * render_every)
  print(
      f"Rendering at {fps:.1f} fps ({playback_speed}× real-time, "
      f"1 frame per {render_every} sim step(s))"
  )

  scene_option = mujoco.MjvOption()
  scene_option.flags[mujoco.mjtVisFlag.mjVIS_TRANSPARENT] = False
  scene_option.flags[mujoco.mjtVisFlag.mjVIS_PERTFORCE] = False
  scene_option.flags[mujoco.mjtVisFlag.mjVIS_CONTACTFORCE] = False

  if show_collision_meshes:
    scene_option.flags[mujoco.mjtVisFlag.mjVIS_CONVEXHULL] = True
    print(
        f"Collision mesh overlay enabled; visual geoms at {visual_opacity:.2f}"
        " opacity."
    )

  # Optional coordinate-frame axes (RGB = XYZ). MuJoCo draws frames for ALL
  # entities of the chosen type, e.g. frame="site" shows link_tcp plus every
  # other site (mocap_target, finger pads, sensor sites).
  frame_map = {
      "none": mujoco.mjtFrame.mjFRAME_NONE,
      "body": mujoco.mjtFrame.mjFRAME_BODY,
      "geom": mujoco.mjtFrame.mjFRAME_GEOM,
      "site": mujoco.mjtFrame.mjFRAME_SITE,
      "world": mujoco.mjtFrame.mjFRAME_WORLD,
  }
  if frame and frame != "none":
    scene_option.frame = frame_map[frame]
    print(f"Frame axes enabled: {frame} (RGB = XYZ)")

  # MuJoCo's offscreen framebuffer defaults to 640x480; requesting a larger
  # render size raises "Image size > framebuffer" unless we grow it here.
  if render_env.mj_model.vis.global_.offwidth < video_width:
    render_env.mj_model.vis.global_.offwidth = video_width
  if render_env.mj_model.vis.global_.offheight < video_height:
    render_env.mj_model.vis.global_.offheight = video_height

  if render_camera == _FREE_CAMERA:
    print("Rendering with the free camera")
  else:
    print(f"Rendering with camera: {render_camera!r}")

  # Temporarily reduce visual geom opacity so collision hulls stand out.
  original_geom_rgba: np.ndarray | None = None
  if show_collision_meshes:
    original_geom_rgba = render_env.mj_model.geom_rgba.copy()
    render_env.mj_model.geom_rgba[:, 3] = (
        render_env.mj_model.geom_rgba[:, 3] * visual_opacity
    )

  try:
    all_rendered: list[list[np.ndarray]] = []
    for i, rollout in enumerate(trajectories):
      traj = rollout[::render_every]
      field_traces = {
          name: trace[::render_every]
          for name, trace in debug_traces[i].items()
      }
      frames = render_env.render(
          traj,
          height=video_height,
          width=video_width,
          camera=render_camera,
          scene_option=scene_option,
      )
      if debug_overlay and field_traces:
        frames = _overlay_debug_on_frames(frames, field_traces)
      all_rendered.append(list(frames))
  finally:
    if original_geom_rgba is not None:
      render_env.mj_model.geom_rgba[:] = original_geom_rgba

  if panel and panel >= 1:
    per_panel = panel * panel
    n_panels = math.ceil(len(all_rendered) / per_panel)
    multi = n_panels > 1
    for p in range(n_panels):
      chunk = all_rendered[p * per_panel : (p + 1) * per_panel]
      print(
          f"Tiling {len(chunk)} rollouts into a {panel}×{panel} panel video "
          f"({p + 1}/{n_panels})"
      )
      tiled = _tile_frames(chunk, panel)
      suffix = f"_panel{p}" if multi else "_panel"
      out_path = output_dir / f"{output_prefix}{suffix}.mp4"
      media.write_video(out_path, tiled, fps=fps)
      print(f"Saved {out_path}")
  else:
    for i, frames in enumerate(all_rendered):
      out_path = output_dir / f"{output_prefix}{i}.mp4"
      media.write_video(out_path, frames, fps=fps)
      print(f"Saved {out_path}")
