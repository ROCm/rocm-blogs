# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Debug and inspection tools for the environments in this package.

Nothing here is imported by ``training/__init__.py``: these modules are for
looking at a trained policy, not for registering or training environments, and
they pull in heavier dependencies (mediapy, Pillow) than the envs need. Import
them explicitly, e.g. ``from training.utils import debug_rollout``.
"""
