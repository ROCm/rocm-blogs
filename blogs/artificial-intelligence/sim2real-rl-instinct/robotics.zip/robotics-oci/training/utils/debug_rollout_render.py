# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Render rollout videos from a trained PPO checkpoint under ``logs/``.

Loads a checkpoint written by the training entry point in this package, replays
the policy in the environment it was trained on, and writes MP4s with the
environment's ``render_debug_fields`` drawn on each frame.

Run it the same way as training -- from ``training/``, in the container, which
already has OSMesa and ffmpeg for headless rendering:

    docker/dockertrainingrun.sh uv run python utils/debug_rollout_render.py \
      --impl warp --num_videos 4

With no ``--checkpoint_path`` the latest step of the most recent run under
``logs/`` is used, and the env name is read back out of the run directory name,
so that command renders whatever was trained last. The videos land next to the
checkpoints in the run directory unless ``--output_dir`` says otherwise.

The environment is rebuilt from the ``config.json`` the trainer saved with the
checkpoint, so the rollout runs the physics and control the policy was trained
under rather than the current defaults.
"""

import importlib.util
import json
import pathlib
import sys
import warnings

from absl import app
from absl import flags

_PACKAGE_ROOT = pathlib.Path(__file__).resolve().parent.parent


def _import_training() -> None:
  """Imports the ``training`` package this file lives in, registering its envs.

  The package is loaded from its location rather than by putting the repo root
  on ``sys.path``, because the submodule checkouts there (``warp/``,
  ``mujoco/``) would shadow the installed packages of the same name --
  ``train_jax_ppo.py`` in the parent directory explains that failure in full.
  """
  if "training" in sys.modules:
    return
  spec = importlib.util.spec_from_file_location(
      "training",
      _PACKAGE_ROOT / "__init__.py",
      submodule_search_locations=[str(_PACKAGE_ROOT)],
  )
  module = importlib.util.module_from_spec(spec)
  # Published before it is executed, so the package's own ``from training import
  # ...`` statements bind to the module being created here.
  sys.modules["training"] = module
  spec.loader.exec_module(module)


_import_training()

# pylint: disable=g-import-not-at-top,wrong-import-position
from mujoco_playground import registry

from training.utils import debug_rollout as dr

# pylint: enable=g-import-not-at-top,wrong-import-position

_ENV_NAME = flags.DEFINE_string(
    "env_name",
    None,
    "Environment name. If omitted, inferred from the run directory "
    "(e.g. logs/XArm6Pick-20260805-053530-warp-2/...).",
)
_CHECKPOINT_PATH = flags.DEFINE_string(
    "checkpoint_path",
    None,
    "Path to a checkpoint step directory, a checkpoints root "
    "(logs/<run>/checkpoints), or a run directory. If omitted, the most recent "
    "run under --logdir is used.",
)
_LOGDIR = flags.DEFINE_string(
    "logdir",
    str(dr.DEFAULT_LOGS_ROOT),
    "Where to look for runs when --checkpoint_path is omitted. Defaults to "
    "this package's logs/, the same directory train_jax_ppo.py writes to.",
)
_ALL_CHECKPOINTS = flags.DEFINE_boolean(
    "all_checkpoints",
    False,
    "Render a video for every checkpoint step in the run, instead of just the "
    "latest. Each video is tagged with its step in the filename "
    "(e.g. rollout_step000010485760_0.mp4).",
)
_IMPL = flags.DEFINE_enum("impl", "jax", ["jax", "warp"], "MJX implementation")
_PLAYGROUND_CONFIG_OVERRIDES = flags.DEFINE_string(
    "playground_config_overrides",
    None,
    "JSON overrides for the playground env config, applied on top of the "
    "checkpoint's saved config (keep the JSON space-free).",
)
_EPISODE_LENGTH = flags.DEFINE_integer(
    "episode_length",
    None,
    "Rollout length in environment steps. Defaults to the saved config, or the "
    "env default.",
)
_SEED = flags.DEFINE_integer("seed", 1, "Random seed for rollouts.")
_DETERMINISTIC = flags.DEFINE_boolean(
    "deterministic",
    True,
    "Play the policy's action mean (default). Pass --nodeterministic to sample "
    "stochastic actions from the policy distribution, reproducing the "
    "exploration noise the policy had during training.",
)
_RENDER_CAMERA = flags.DEFINE_string(
    "render_camera",
    "free",
    "MuJoCo camera for rendering. Defaults to 'free' (the free/orbit camera). "
    "The xArm6 scenes here also define 'front', 'birdseye' and 'top'; an "
    "unknown name is rejected with the list the model has.",
)
_NUM_VIDEOS = flags.DEFINE_integer(
    "num_videos", 1, "Number of rollout videos to record."
)
_OUTPUT_DIR = flags.DEFINE_string(
    "output_dir",
    None,
    "Directory for output videos. Defaults to the run directory.",
)
_OUTPUT_PREFIX = flags.DEFINE_string(
    "output_prefix",
    "rollout",
    "Filename prefix for videos (e.g. rollout0.mp4).",
)
_PLAYBACK_SPEED = flags.DEFINE_float(
    "playback_speed",
    1.0,
    "Video playback speed multiplier relative to real time "
    "(e.g. 2.0 plays the video at 2× real-time speed, 0.5 for slow-motion).",
)
_RENDER_FPS = flags.DEFINE_float(
    "render_fps",
    30.0,
    "Target output frame rate of the video in frames per second. "
    "Combined with --playback_speed, this determines how many simulation "
    "steps are skipped between rendered frames.",
)
_DEBUG_OVERLAY = flags.DEFINE_boolean(
    "debug_overlay",
    True,
    "Draw the env's render_debug_fields on the video frames. Pass "
    "--nodebug_overlay to disable.",
)
_PANEL = flags.DEFINE_integer(
    "panel",
    0,
    "Panel grid size n. When n >= 1, render --num_videos panel videos, each an "
    "n×n grid of n² rollouts (so num_videos*n² rollouts total). A single panel "
    "is saved as {output_prefix}_panel.mp4; multiple as "
    "{output_prefix}_panel{k}.mp4. 0 (default) disables tiling (one file per "
    "rollout).",
)
_VIDEO_HEIGHT = flags.DEFINE_integer(
    "video_height", 720, "Output video height."
)
_VIDEO_WIDTH = flags.DEFINE_integer("video_width", 1280, "Output video width.")
_SHOW_COLLISION_MESHES = flags.DEFINE_boolean(
    "show_collision_meshes",
    False,
    "Overlay collision hull geometry on top of visual meshes. "
    "Visual meshes are rendered at reduced opacity (see --visual_opacity).",
)
_VISUAL_OPACITY = flags.DEFINE_float(
    "visual_opacity",
    0.3,
    "Alpha multiplier applied to visual geoms when --show_collision_meshes is "
    "enabled. 1.0 = fully opaque, 0.0 = fully transparent.",
)
_FRAME = flags.DEFINE_enum(
    "frame",
    "none",
    ["none", "body", "geom", "site", "world"],
    "Draw coordinate-frame axes (RGB=XYZ). 'site' shows the link_tcp site axes "
    "(and all other sites: mocap_target, finger pads, sensor sites).",
)

warnings.filterwarnings("ignore", category=RuntimeWarning, module="jax")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="jax")


def main(argv):
  del argv

  if _PLAYBACK_SPEED.value <= 0:
    raise ValueError("--playback_speed must be > 0")
  if _PANEL.value < 0:
    raise ValueError("--panel must be >= 0")

  # In panel mode each of the --num_videos outputs is an n×n grid, so run
  # num_videos * n² rollouts; render_debug_rollouts chunks them into n×n panels.
  panel = _PANEL.value
  num_videos = _NUM_VIDEOS.value
  if panel >= 1:
    num_videos = num_videos * panel * panel

  step_dir = dr.resolve_checkpoint_path(_CHECKPOINT_PATH.value, _LOGDIR.value)
  run_dir = dr.run_dir_for(step_dir)
  print(f"Using checkpoint: {step_dir}")
  print(f"Run directory: {run_dir}")

  if dr.checkpoint_uses_vision(step_dir):
    raise ValueError(
        "This checkpoint was trained on pixel observations, which this script "
        "cannot render: the environments here are proprioceptive, and the "
        "pinned mujoco_playground submodule has no vision wrapper (see the "
        "note at the end of training/README.md)."
    )

  env_name = _ENV_NAME.value
  if env_name is None:
    env_name = dr.infer_env_name_from_run_dir(run_dir)
  if env_name is None:
    raise ValueError(
        "Could not infer --env_name from the run directory. "
        f"Pass --env_name explicitly (run dir: {run_dir})."
    )
  if env_name not in registry.ALL_ENVS:
    raise ValueError(
        f"Unknown env_name={env_name!r}. "
        f"Choose one of: {', '.join(registry.ALL_ENVS)}"
    )

  train_cfg: dict = {}
  train_cfg_path = dr.training_config_path(step_dir)
  if train_cfg_path.exists():
    train_cfg = json.loads(train_cfg_path.read_text())
    print(f"Loaded training config from {train_cfg_path}")
  elif _ENV_NAME.value is None:
    print(
        "Warning: no config.json next to checkpoints; using env defaults only."
    )

  env_cfg = registry.get_default_config(env_name)
  # Apply the full saved training env config so the rollout uses the exact
  # physics/control the policy trained with (gravity_compensation, integrator,
  # solver, action scales, gripper gains, etc.), not just the env defaults.
  # JSON serializes tuples as lists, so coerce back to the default field's type;
  # unknown or type-incompatible keys are skipped.
  # impl is intentionally excluded -- it is controlled by the --impl flag below.
  for key, val in train_cfg.items():
    if key == "impl" or key not in env_cfg:
      continue
    # Skip nested config sub-dicts (e.g. reward_config). They don't affect the
    # rollout physics or the policy's actions -- rewards are only logged and
    # overlaid -- and wholesale-replacing them with the checkpoint's version
    # drops any field the current env code now expects (e.g. a reward scale
    # added after this checkpoint was trained), which then KeyErrors inside
    # env.step. Keeping the current defaults for nested configs is the safe
    # choice for rendering.
    if isinstance(val, dict):
      continue
    if isinstance(env_cfg[key], tuple) and isinstance(val, list):
      val = tuple(val)
    try:
      env_cfg[key] = val
    except (TypeError, ValueError):
      continue
  env_cfg["impl"] = _IMPL.value

  episode_length = _EPISODE_LENGTH.value
  if episode_length is None:
    episode_length = int(
        train_cfg.get("episode_length", env_cfg.episode_length)
    )
  env_cfg["episode_length"] = episode_length

  env_cfg_overrides: dict = {}
  if _PLAYGROUND_CONFIG_OVERRIDES.value is not None:
    env_cfg_overrides = json.loads(_PLAYGROUND_CONFIG_OVERRIDES.value)

  eval_env = registry.load(
      env_name, config=env_cfg, config_overrides=dict(env_cfg_overrides)
  )

  if _ALL_CHECKPOINTS.value:
    step_dirs = dr.all_checkpoint_step_dirs(step_dir)
    if not step_dirs:
      raise ValueError(f"No checkpoint step dirs found for run: {run_dir}")
    print(f"Rendering {len(step_dirs)} checkpoints from {run_dir}")
  else:
    step_dirs = [step_dir]

  for i, ckpt in enumerate(step_dirs):
    if _ALL_CHECKPOINTS.value:
      output_prefix = f"{_OUTPUT_PREFIX.value}_step{ckpt.name}"
      print(f"[{i + 1}/{len(step_dirs)}] Rendering checkpoint {ckpt.name} ...")
    else:
      output_prefix = _OUTPUT_PREFIX.value
      print(f"Loading policy from {ckpt} ...")

    inference_fn = dr.load_inference_fn(
        ckpt, deterministic=_DETERMINISTIC.value
    )

    dr.render_debug_rollouts(
        eval_env=eval_env,
        episode_length=episode_length,
        num_videos=num_videos,
        seed=_SEED.value,
        output_dir=_OUTPUT_DIR.value or run_dir,
        inference_fn=inference_fn,
        output_prefix=output_prefix,
        playback_speed=_PLAYBACK_SPEED.value,
        render_fps=_RENDER_FPS.value,
        render_camera=_RENDER_CAMERA.value,
        video_height=_VIDEO_HEIGHT.value,
        video_width=_VIDEO_WIDTH.value,
        debug_overlay=_DEBUG_OVERLAY.value,
        panel=panel,
        show_collision_meshes=_SHOW_COLLISION_MESHES.value,
        visual_opacity=_VISUAL_OPACITY.value,
        frame=_FRAME.value,
    )


if __name__ == "__main__":
  app.run(main)
