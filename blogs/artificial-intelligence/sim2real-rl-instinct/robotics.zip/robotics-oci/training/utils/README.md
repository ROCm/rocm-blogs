# utils

Tools for looking at a policy after it has trained. Nothing here is imported by
`training/__init__.py` — these modules pull in heavier dependencies (mediapy,
Pillow) than the environments need, and none of them are involved in
registration or training.

- `debug_rollout_render.py` — the CLI: replay a checkpoint and write MP4s.
- `debug_rollout.py` — the checkpoint loading and rendering it is built on. The
  split keeps the flag plumbing out of the rendering, so a notebook or another
  script can call `render_debug_rollouts()` directly.

## Rendering rollouts

Run it from `training/`, in the same container as training — it already has the
headless renderer (OSMesa) and ffmpeg:

```bash
docker/dockertrainingrun.sh uv run python utils/debug_rollout_render.py \
  --impl warp --num_videos 4
```

With no `--checkpoint_path` that takes the latest step of the most recent run
under `logs/`, reads the environment name back out of the run directory name,
and writes the videos next to the checkpoints. The environment is rebuilt from
the `config.json` the trainer saved with the checkpoint, so the rollout runs the
physics and control the policy was trained under rather than the current
defaults.

Each frame carries the environment's `render_debug_fields` — the reward terms
and diagnostics that explain *why* a policy does what it does. An env opts in by
declaring that attribute, as `XArm6Pick` does; one without it still renders,
just without the overlay.

The flags worth knowing:

- `--checkpoint_path` takes a step directory, a `checkpoints` root or a run
  directory; `--all_checkpoints` renders every step of the run instead, which
  shows the policy as it learned.
- `--panel N` tiles rollouts into an N×N grid in one file — the quickest way to
  see the spread across cube spawns.
- `--render_camera` picks a camera (`front`, `birdseye`, `top` in the xArm6
  scenes); an unknown name is rejected up front with the list the model has.
- `--show_collision_meshes` and `--frame site` debug the model rather than the
  policy.

`--help` lists the rest. See [`../README.md`](../README.md) for the flags in
context, and the note there on rendering being CPU-bound.
