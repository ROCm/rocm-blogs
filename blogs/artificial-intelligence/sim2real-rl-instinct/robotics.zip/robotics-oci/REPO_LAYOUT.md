# Repository layout

How this repository is organized: which directories exist and what they are for,
how the vendored dependencies are pinned, and how local changes to them are kept
as patches. See [README.md](README.md) for the step-by-step path from this
release to a trained policy.

Heavy dependencies are **checkouts of clean upstream commits**, cloned by
`scripts/fetch-submodules.sh` from the pins recorded in its manifest, and local
modifications to them live as **patch files** applied on top. The checkouts never
move off those pins — every local change lives in `patches/`, so what ends up in
those three directories is reproducible from this release alone.

Local work therefore takes one of two forms: *changes* to an upstream dependency
become patches, while *additions* of our own are ordinary code in `training/`.

## Top-level directories

| Path | Contents |
| --- | --- |
| `training/` | Everything this repo adds: environments, scenes, assets, the training entry point, the rollout-rendering tools and the policy export. Plain Python package, not a uv project. See [`training/README.md`](training/README.md). |
| `deployment/` | The robot side: the ROS 2 controller and perception nodes that run an exported policy on a real xArm6, plus the kinematics and camera calibration they need. Shares nothing with `training/` but the two exported files. See [`deployment/README.md`](deployment/README.md). |
| `docker/` | The `mjp-rocmwarp` image (ROCm + OSMesa) and the scripts that build it, build Warp for the local GPU, and run commands inside ephemeral containers. |
| `apptainer/` | The same image and the same four scripts for Apptainer, script for script, for clusters where that is the container runtime. See [SETUP.md](SETUP.md#2-build-the-container-image). |
| `scripts/` | `fetch-submodules.sh`, which clones the three dependencies at their pins, `apply-patches.sh`, the patch-stack manager, `fetch-xarm6-assets.sh`, which downloads and verifies the xArm6 meshes, and `make-release-zip.sh`, which packs this directory into a release archive. |
| `patches/` | Local changes to the dependencies, one directory per dependency. |
| `sbatch/` | SLURM job templates for running training as a batch job. |
| `warp/`, `mujoco/`, `mujoco_playground/` | Not part of the release. `scripts/fetch-submodules.sh` creates them at the pinned commits (see below). |

Runtime output is gitignored and created on first use: `training/logs/` holds
runs, `docker/.venv*/` the synced project venvs, and `docker/.dockerhome/` the
container's HOME (uv cache, Warp kernel cache). `apptainer/` grows the same pair
under its own names, plus `apptainer/mjp-rocmwarp.sif`, the built image — the two
runtimes keep separate homes and venvs because a virtualenv records the absolute
path of its interpreter, which lives in the home that built it.

`training/manipulation/ufactory_xarm6/meshes/` is gitignored because the xArm6
STLs are vendored from the `xarm_description` package of
[`xArm-Developer/xarm_ros2`](https://github.com/xArm-Developer/xarm_ros2).
 `scripts/fetch-xarm6-assets.sh` downloads them into
place and verifies them against a sha256 manifest; it is a required setup step,
since no xArm6 environment can build its model without them.

## Pinned dependencies

| Path                | Upstream (SSH)                                   | Pinned to           |
| ------------------- | ----------------------------------------------- | ------------------- |
| `warp/`             | `git@github.com:AMD-Ecosystem/warp.git`         | branch `amd-integration` |
| `mujoco/`           | `git@github.com:google-deepmind/mujoco.git`     | tag `3.10.0`        |
| `mujoco_playground/`| `git@github.com:google-deepmind/mujoco_playground.git` | `main` at one commit before the `warp-lang>=1.15.0` bump (keeps `warp-lang>=1.11`, so warp 1.13 is allowed) |

The exact commit for each is the third column of the manifest at the top of
[`scripts/fetch-submodules.sh`](scripts/fetch-submodules.sh). That manifest is
the release's only record of the pins: nothing here tracks those three
directories, and they do not exist until the script clones them. Fetching them
needs SSH access to the repos above (`ssh -T git@github.com` should
authenticate).

```bash
scripts/fetch-submodules.sh                    # clone all three at their pins
scripts/fetch-submodules.sh warp               # restrict to one or more of them
scripts/fetch-submodules.sh --check            # report the state of each, no writes
scripts/fetch-submodules.sh --reverse          # delete them again (refuses if dirty)
scripts/fetch-submodules.sh --reverse --force  # ... even then
```

The script keeps its name from the git submodules these three were on the branch
this release was cut from. On a branch that still registers them it defers to
`git submodule update --init`, checking the manifest against the gitlinks first.

## Patches

Local changes to a dependency are stored as `patches/<name>/NNNN-*.patch`
(produced with `git format-patch`, applied in filename order):

```
patches/
├── warp/
│   └── 0001-Guard-rocWMMA-16x16-fast-path-on-WP_TILE_BLOCK_DIM-6.patch
├── mujoco/
│   └── 0001-ROCm-HIP-support-for-vendored-warp-jax_experimental-.patch
└── mujoco_playground/
    ├── 0001-Pin-deps-and-toolchain-for-local-ROCm-warp-mujoco-bu.patch
    ├── 0002-Regenerate-uv.lock-for-pinned-deps-and-local-sources.patch
    └── 0003-Guard-eval-metric-lookup-in-progress-fn-for-log_trai.patch
```

They are applied on top of the pinned checkouts as **working-tree changes**, so
the pin itself stays pristine — `git -C <name> rev-parse HEAD` still reports the
commit in the manifest, which is why `scripts/fetch-submodules.sh --check` reads
`ok` with the stack applied. Manage the stack with `scripts/apply-patches.sh`:

```bash
scripts/apply-patches.sh            # apply all patches (skips already-applied)
scripts/apply-patches.sh --check    # dry-run: report what would apply, change nothing
scripts/apply-patches.sh --reverse  # un-apply the stack (restore clean checkouts)
scripts/apply-patches.sh warp       # restrict to one or more named dependencies
```

The script is idempotent (re-running reports `already-applied`) and exits
non-zero if any patch fails to apply, so it is safe to run in CI.

### Adding a new patch

Edit the dependency in place, then capture the change and restore the pin. Each
of the three is an ordinary git clone once fetched, so this works here as it
would anywhere:

```bash
cd <name>
git add <changed files>
git commit -m "Short description of the change"
git format-patch -1 --zero-commit -o ../patches/<name>/
git reset --hard HEAD~1              # restore the checkout to its clean pin
cd ..
```

The throwaway commit exists only to generate a well-described patch; resetting
it afterwards puts the checkout back on the pinned upstream commit, where
`scripts/fetch-submodules.sh --check` expects it. The new patch file is picked
up on the next `scripts/apply-patches.sh` by virtue of being in `patches/`.

### Updating a pin

Move it deliberately (the patches must still apply on the new commit):

```bash
cd <name>
git fetch origin
git checkout <new-commit-or-tag>     # e.g. origin/amd-integration for the branch tip
git rev-parse HEAD                   # the commit to record
cd ..
# edit the manifest in scripts/fetch-submodules.sh to that commit
scripts/fetch-submodules.sh --check  # confirm the checkout matches the manifest
scripts/apply-patches.sh --check     # confirm the patch stack still applies
```

Editing the manifest *is* the pin update — it is the only record of these
commits in the release, so a checkout moved without it is a local change that
nothing reproduces. On a branch that still registers the three as submodules,
`git add <name>` moves the gitlink as well and `--check` fails loudly if the two
records disagree.
