# Setup

End-to-end setup for this repo — step 2 of the path in [README.md](README.md).
See [REPO_LAYOUT.md](REPO_LAYOUT.md) for how the pinned dependencies and the
patch stack fit together.

**Prerequisites**

- Git, and SSH access to GitHub (`ssh -T git@github.com` should authenticate) —
  step 1 clones the three dependencies below from their SSH URLs.
- Docker or Apptainer (either one — see [step 2](#2-build-the-container-image)).
- An AMD GPU on the machine you run steps 3–4 on. Warp compiles device code for
  the concrete GPU architecture, so those steps detect and build for the GPU
  actually present.

---

## 1. Dependencies, patches and meshes

The `warp/`, `mujoco/` and `mujoco_playground/` directories are not part of this
release — only the commits they are pinned to are. Fetch them, apply the patch
stack on top, and download the xArm6 visual meshes. Run all of this from the
directory this file is in:

```bash
chmod +x scripts/*.sh docker/*.sh apptainer/*.sh   # only if unpacking dropped the bits
scripts/fetch-submodules.sh          # warp, mujoco, mujoco_playground at their pins
scripts/apply-patches.sh             # apply patches/*/ onto each of them
scripts/fetch-xarm6-assets.sh        # download the xArm6 meshes (not in the release)
```

`fetch-submodules.sh` holds the three pinned commits in a manifest and clones
each repository into place at exactly that commit, so it needs network access and
SSH to GitHub. Expect about 260 MB on disk once all three are checked out. It is
idempotent: re-running it reports `ok` for anything already at its pin, and it
refuses to move a directory that has uncommitted changes in it rather than
discarding your work.

`apply-patches.sh` then applies `patches/<name>/*.patch` into each of the three
as ordinary working-tree changes. Run it after every `fetch-submodules.sh`, and
re-run it freely — already-applied patches are detected and skipped.

The meshes are the STLs `training/manipulation/ufactory_xarm6/xmls/xarm6.xml`
references — vendored from the `xarm_description` package of
[`xArm-Developer/xarm_ros2`](https://github.com/xArm-Developer/xarm_ros2) rather
than shipped here, so the fetch is a required step and not an optional one:
without it every xArm6 environment fails to build its model. The script needs
network access to GitHub over HTTPS, checks each file against a sha256 manifest,
and is idempotent — re-running it fetches only what is missing or wrong.

### Verify

Check that the dependencies are at their pins, the patches applied and the meshes
arrived:

```bash
scripts/fetch-submodules.sh --check      # every line should read "ok"
scripts/apply-patches.sh --check         # every line should read "already-applied"
scripts/fetch-xarm6-assets.sh --check    # every line should read "ok"
```

## 2. Build the container image

Builds the `mjp-rocmwarp` image (ROCm + OSMesa) that steps 3–5 run inside, under
whichever of the two container runtimes you use:

```bash
docker/dockerbuild.sh              # docker: the image `mjp-rocmwarp`
apptainer/apptainerbuild.sh        # apptainer: apptainer/mjp-rocmwarp.sif
```

### Docker or Apptainer

`apptainer/` holds the same image and the same scripts for Apptainer, one for
one, so every command in the rest of this document has an equivalent with
`docker` replaced by `apptainer` throughout — `apptainer/apptainerbuild.sh`,
`apptainer/apptainerwarpbuild.sh`, `apptainer/apptainerplaygroundrun.sh`,
`apptainer/apptainertrainingrun.sh` — taking the same arguments and doing the
same thing. Pick one and stay with it; they keep separate venvs and caches, so
switching costs a `uv sync` rather than breaking anything.

**Prefer Apptainer on a SLURM cluster.** Its container is an ordinary child
process of whatever started it, so the job's own confinement simply applies: the
allocated GPUs and cores are the ones the container sees, files are written as
you, and `scancel` or the walltime kill takes the container with it. Under
Docker the container belongs to a system daemon instead, outside the job's
cgroup and owned by root, so `docker/dockerrun_core.sh` has to re-derive the
allocation (walking the KFD topology for `--device` flags, the affinity mask for
`--cpuset-cpus`), map your user in, and be torn down from an exit trap — all of
which Apptainer needs none of. The image is also a single file
(`apptainer/mjp-rocmwarp.sif`) on the shared filesystem, built once for the
cluster rather than once per node.

Prefer Docker where the image itself is being changed often: it rebuilds
incrementally from a layer cache, and building the Apptainer image needs
`fakeroot` or a `/etc/subuid` entry for the `apt-get` step (failing that,
`apptainer/apptainerbuild.sh --from-docker` converts the image Docker built).

## 3. Build Warp for your GPU

Compile the Warp native library against the local GPU, inside an ephemeral
`mjp-rocmwarp` container. This detects the HIP architecture automatically and
writes `warp/warp/bin/warp.so` into the `warp/` directory step 1 created, where
later runs pick it up:

```bash
docker/dockerwarpbuild.sh
```

(Run this on the GPU node: if no architecture can be detected the build stops
with an error rather than guessing one, since a library built for the wrong card
is worse than none. To cross-build for a different card, set e.g.
`HIP_ARCH=gfx950 docker/dockerwarpbuild.sh`.)

## 4. Trial training run

Train `PandaPickCubeCartesian` inside the playground container to confirm the
whole stack works. `dockerplaygroundrun.sh` syncs the project venv
(`--extra tensorboard,rocm`) and then runs the command:

```bash
docker/dockerplaygroundrun.sh uv run train-jax-ppo \
  --env_name PandaPickCubeCartesian \
  --impl warp \
  --use_tb \
  --log_training_metrics
```

- `--impl warp` exercises the Warp library built in step 3.
- `--use_tb` writes TensorBoard logs; `--log_training_metrics` records the
  per-update training metrics (loss / KL / etc.).

Logs and checkpoints land under `mujoco_playground/logs/<env>-<timestamp>/`.
Point TensorBoard at that directory to watch the run.

That completes the setup. To train this repo's own `XArm6Pick` environment, see
[Train the xArm6 pick-and-hold policy](README.md#3-train-the-xarm6-pick-and-hold-policy)
in the README; its runs land in `training/logs/` rather than under `mujoco_playground/`.
