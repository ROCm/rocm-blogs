#!/bin/bash

# Extract the OS type from /etc/lsb-release
os_type=$(grep DISTRIB_CODENAME /etc/lsb-release | cut -d'=' -f2)
echo "os type ==>"$os_type

# Create the sources list file based on the OS type
if [ "$os_type" == "noble" ]; then

    echo "Creating the Ubuntu sources list file for Noble version..."
    cat <<EOF > /etc/apt/sources.list.d/ubuntu.sources
Types: deb
URIs: https://archive.ubuntu.com/ubuntu/
Suites: noble noble-updates noble-backports
Components: main universe restricted multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

## Ubuntu security updates. Aside from URIs and Suites,
## this should mirror your choices in the previous section.
Types: deb
URIs: https://security.ubuntu.com/ubuntu/
Suites: noble-security
Components: main universe restricted multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
EOF

elif [ "$os_type" == "jammy" ]; then

    echo "Updating http to https in /etc/apt/sources.list file..."
    sed -i 's|http://|https://|g' /etc/apt/sources.list

else
    echo "OS type is not Noble or Jammy. Skipping the creation of the sources list file."
fi

# Create and configure the verify peer configuration file
echo "Creating verify peer configuration..."
cat <<EOF > /etc/apt/apt.conf.d/99verify-peer.conf
Acquire {
    https::Verify-Peer false
}
EOF

# Update package lists and install CA certificates
echo "Updating package lists and installing CA certificates..."
apt update
apt install -y ca-certificates

# Remove the verify peer configuration file
rm /etc/apt/apt.conf.d/99verify-peer.conf

echo "Script execution completed."
