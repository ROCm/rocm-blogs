#!/bin/bash
#
# Build the Warp native library for the local AMD GPU, inside an ephemeral
# mjp-rocmwarp container.
#
# Works in the warp/ checkout instead of mujoco_playground/, detects the HIP
# architecture of the GPUs actually allocated to this job, and runs Warp's
# build_lib.py against it. The resulting warp/warp/bin/warp.so lands in the
# bind-mounted checkout, so it persists after the container exits and is picked
# up by every later run.
#
# Usage:
#   dockerwarpbuild                      # detect arch, build warp, then exit
#   dockerwarpbuild bash                 # build, then drop into a shell
#   dockerwarpbuild "python -c 'import warp; warp.init()'"   # build, then verify
#
# Any command is run *after* the build, in the same shell, exactly as in
# dockerplaygroundrun.sh. With no command the container exits once the build
# finishes (unlike dockerplaygroundrun.sh, which opens a shell), so this works
# as a batch step.
#
# Options (must come before the command):
#   --root   Run the container as root instead of the host user (see
#            dockerplaygroundrun.sh for the caveats).
#
# Environment:
#   HIP_ARCH         Skip detection and build for these targets instead, e.g.
#                    HIP_ARCH=gfx90a or HIP_ARCH=gfx90a,gfx942. Useful for
#                    cross-building for a node you are not currently on.
#   WARP_BUILD_ARGS  Extra arguments appended to build_lib.py, e.g.
#                    WARP_BUILD_ARGS="--debug".
#
# Fails when the target architecture is neither detected nor given: a Warp HIP
# build compiles device code for a concrete architecture, and Warp's fallback is
# a hardcoded gfx942 (see _parse_hip_arches in warp/_src/build_dll.py), which is
# silently wrong on any other card. Detecting and passing --hip-arch explicitly
# is the point of this script, so building against that assumed default is worse
# than not building at all.
#
set -euo pipefail

DOCKERRUN_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Detect the GPU architecture(s) present, as a comma-separated list.
# rocm_agent_enumerator is the canonical tool and prints one gfx target per
# agent; gfx000 is the CPU agent and is not a build target. rocminfo is the
# fallback for images that ship it but not the enumerator.
detect_hip_arch() {
  local arches=""
  if command -v rocm_agent_enumerator >/dev/null 2>&1; then
    arches="$(rocm_agent_enumerator 2>/dev/null \
      | grep -E '^gfx[0-9a-f]+' | grep -vx 'gfx000' | sort -u | paste -sd, -)"
  fi
  if [[ -z "$arches" ]] && command -v rocminfo >/dev/null 2>&1; then
    arches="$(rocminfo 2>/dev/null \
      | awk '/^[[:space:]]*Name:[[:space:]]+gfx/{print $2}' \
      | grep -vx 'gfx000' | sort -u | paste -sd, -)"
  fi
  printf '%s' "$arches"
}

if [[ -n "${HIP_ARCH:-}" ]]; then
  hip_arch="$HIP_ARCH"
  echo "Using HIP architecture from environment: $hip_arch"
else
  hip_arch="$(detect_hip_arch)"
  if [[ -z "$hip_arch" ]]; then
    echo "ERROR: could not detect any AMD GPU architecture on this host." >&2
    echo "       Tried rocm_agent_enumerator and rocminfo." >&2
    echo "       A Warp HIP build targets a concrete gfx architecture, and" >&2
    echo "       falling back to Warp's assumed default would build for the" >&2
    echo "       wrong card." >&2
    echo "       Run this on a GPU node, or set HIP_ARCH=gfx942 to cross-build." >&2
    exit 1
  fi
  echo "Detected HIP architecture(s): $hip_arch"
fi

# The value is interpolated into a shell snippet below, so keep it to the shape
# a gfx target actually has.
if [[ ! "$hip_arch" =~ ^gfx[0-9a-z]+(,gfx[0-9a-z]+)*$ ]]; then
  echo "ERROR: '$hip_arch' does not look like a gfx target list." >&2
  exit 2
fi

# Work in the warp checkout.
PROJECT_SUBDIR=warp
# No virtualenv: the build runs in a throwaway uv environment (see below), so
# there is no warp/.venv to persist or to shadow.
MOUNT_PROJECT_VENV=0
# With no command, exit once the build finishes rather than opening a shell, so
# this is usable as a batch step (`srun dockerwarpbuild`) and its exit status is
# the build's.
DEFAULT_COMMAND=true

# Make the target visible to anything else that builds HIP code in this
# container; Warp's build_dll.py reads HIP_ARCH when --hip-arch is absent.
EXTRA_DOCKER_FLAGS=(-e HIP_ARCH="$hip_arch")

# Build in a throwaway environment rather than syncing the project: --no-project
# stops uv from creating or using warp/.venv, and --with numpy supplies Warp's
# only import-time dependency. build_lib.py, build_llvm and the warp package all
# come from the checkout itself (the script's directory leads sys.path), so
# nothing needs to be installed for the build to see them. The interpreter still
# follows warp/.python-version.
#
# --hip-arch is passed explicitly because it takes precedence over both the
# HIP_ARCH environment variable and Warp's hardcoded gfx942 default. --rocm-path
# pins the SDK to the image's ROCm install instead of relying on build_lib.py's
# auto-detection (ROCM_PATH, then hipconfig, then hipcc). WARP_BUILD_ARGS is
# appended last, so it can override any of these (argparse takes the final
# occurrence of a flag).
#
# -j uses every core the container is allowed (the SLURM allocation, or the whole
# node when running outside one), or OMP_NUM_THREADS when the caller asked for a
# specific thread budget; dockerrun_core.sh resolves the two into DOCKERRUN_CPUS.
# build_lib.py's own default already reads the affinity mask but caps it at 8, so
# it leaves most of a big allocation idle. It sizes a thread pool over the native
# sources, so the real concurrency never exceeds their count (~30) however large
# the allocation is; pass WARP_BUILD_ARGS="-j 16" to go lower still.
CONTAINER_SETUP="
  echo \"Building Warp for --hip-arch $hip_arch on \$DOCKERRUN_CPUS cores ...\"
  uv run --no-project --with numpy python build_lib.py \\
    --rocm-path /opt/rocm \\
    -j \"\$DOCKERRUN_CPUS\" \\
    --hip-arch '$hip_arch' ${WARP_BUILD_ARGS:-}
  echo 'Warp build finished:'
  ls -l warp/bin/warp*.so
"

# shellcheck source=dockerrun_core.sh
source "$DOCKERRUN_SCRIPT_DIR/dockerrun_core.sh"
