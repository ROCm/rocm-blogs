#!/bin/bash
#
# Build the mjp-rocmwarp image (ROCm + OSMesa).
# Run from anywhere; the Dockerfile and build context are this script's own dir.
#
# Usage:
#   dockerbuild.sh              # build mjp-rocmwarp from ./Dockerfile
#   dockerbuild.sh --no-cache   # extra args are forwarded to docker build
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

exec docker build --network host -t mjp-rocmwarp -f "$DIR/Dockerfile" "$@" "$DIR"