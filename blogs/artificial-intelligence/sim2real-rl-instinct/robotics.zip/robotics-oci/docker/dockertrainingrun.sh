#!/bin/bash
#
# Single-run dev container for the training/ package: launches an ephemeral
# mjp-rocmwarp container restricted to the SLURM-allocated GPUs, syncs the venv,
# runs the command passed on the CLI, then removes the container (--rm) when the
# command exits.
#
# This is dockerplaygroundrun.sh with training/ as the working directory, so the
# environments in this repo are addressed as they sit in the checkout:
#
#   dockertrainingrun uv run python train_jax_ppo.py --env_name XArm6Pick --impl warp
#
# rather than through the ../training/train_jax_ppo.py the playground variant
# needs. Paths passed to the trainer are relative to training/ here for the same
# reason -- and runs land in training/logs/, so a checkpoint to resume from is
# logs/<run>/checkpoints.
#
# Usage:
#   dockertrainingrun                         # interactive bash shell in training/
#   dockertrainingrun uv run python train_jax_ppo.py --env_name XArm6Pick
#   dockertrainingrun "uv run python train_jax_ppo.py --env_name ... && echo done"
#
# The command is taken two ways (one argument is a shell command line, several are
# an argv vector), and --root behaves, exactly as in dockerplaygroundrun.sh; see
# it and dockerrun_core.sh for those details and for the mounts, GPU/CPU
# allocation and user mapping.
#
# Which project this runs against:
#
# training/ is a plain package rather than a uv project -- no pyproject.toml, and
# nothing installs it -- so it runs on MuJoCo Playground's environment, the same
# one dockerplaygroundrun.sh syncs. UV_PROJECT points uv's project discovery at
# mujoco_playground/ while the working directory stays here; that is what it does
# (--directory is the flag that moves the cwd, --project only decides which
# pyproject.toml is in force). VENV_SUBDIR then keeps the persisted venv mount on
# mujoco_playground/.venv, so the two variants share one environment instead of
# each building its own copy of a multi-gigabyte ROCm install.
#
# The trainer is reachable from here because the editable install of `playground`
# puts the mujoco_playground checkout on sys.path, so its `learning` package
# imports from any working directory.
#
set -euo pipefail

DOCKERRUN_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Work in training/, against the Playground project and its venv (see above).
PROJECT_SUBDIR=training
VENV_SUBDIR=mujoco_playground
CONTAINER_SETUP='
  export UV_PROJECT="$PWD/../mujoco_playground"
  uv sync --extra "tensorboard,rocm"
'

# shellcheck source=dockerrun_core.sh
source "$DOCKERRUN_SCRIPT_DIR/dockerrun_core.sh"
