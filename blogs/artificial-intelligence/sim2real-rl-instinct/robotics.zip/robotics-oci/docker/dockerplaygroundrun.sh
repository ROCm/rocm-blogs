#!/bin/bash
#
# Single-run dev container for the mujoco_playground project: launches an
# ephemeral mjp-rocmwarp container restricted to the SLURM-allocated GPUs, syncs
# the project venv, runs the command passed on the CLI, then removes the
# container (--rm) when the command exits.
#
# Usage:
#   dockerplaygroundrun                       # interactive bash shell in the container
#   dockerplaygroundrun uv run train-jax-ppo --env_name XArm6Reach5Joint --impl warp
#   dockerplaygroundrun "uv run train-jax-ppo --env_name ... && echo done"
#
# The command is taken two ways, by argument count:
#   one argument   -> a shell command line, so `&&`, `|`, `cd x && ...` and
#                     redirections work (it is run by bash, not exec'd)
#   two or more    -> an argv vector, exec'd as-is with no shell in between, so
#                     embedded quotes survive: dockerplaygroundrun python -c "print('a b')"
# A single-argument command that is a bare program name still works, since a
# lone program name is also a valid shell command line.
#
# Options (must come before the command):
#   --root   Run the container as root instead of the host user. Disabled by
#            default; by default the container runs as the invoking host user
#            (--user $(id -u):$(id -g)) so files it creates stay host-owned.
#            Use --root only when a command needs root (e.g. apt-get inside the
#            container) -- note it can leave root-owned files in .dockerhome that
#            later non-root runs can't overwrite.
#
# Everything not specific to this project (GPU/CPU allocation, mounts, container
# HOME, user mapping) lives in dockerrun_core.sh; see dockerwarpbuild.sh for
# the other variant.
#
set -euo pipefail

DOCKERRUN_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Work in the Playground checkout and sync its venv before running the command.
PROJECT_SUBDIR=mujoco_playground
CONTAINER_SETUP='
  uv sync --extra "tensorboard,rocm"
'

# shellcheck source=dockerrun_core.sh
source "$DOCKERRUN_SCRIPT_DIR/dockerrun_core.sh"
