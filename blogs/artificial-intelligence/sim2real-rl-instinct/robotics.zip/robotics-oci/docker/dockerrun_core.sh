# shellcheck shell=bash
#
# Core runner for ephemeral mjp-rocmwarp dev containers.
#
# This file is *sourced* by a variant script (dockerplaygroundrun.sh, dockerwarpbuild.sh,
# ...) and ends by exec'ing `docker run`, so it never returns. Everything that is
# independent of which project is being worked on lives here: GPU/CPU allocation,
# path derivation, the container HOME, the venv mount, user mapping and the
# docker run invocation. A variant only has to say *where* to work and *what* to
# do there.
#
# Contract - a variant sets these before sourcing, then sources this file so it
# inherits the variant's positional parameters ("$@" = the user command):
#
#   PROJECT_SUBDIR   (required) Subdirectory of the repo root that becomes the
#                    container working directory. Also names the persisted venv
#                    (docker/.venv_$PROJECT_SUBDIR), unless VENV_SUBDIR says
#                    otherwise.
#   VENV_SUBDIR      (optional, default $PROJECT_SUBDIR) Subdirectory of the repo
#                    root whose .venv the persisted mount covers. Set it when the
#                    working directory is not itself the uv project being used --
#                    a variant that works in a plain package directory and runs
#                    against another project's environment -- so both variants
#                    share one venv instead of each building its own copy.
#   CONTAINER_SETUP  (optional) Shell snippet run inside the container before the
#                    user command, in the same shell (so it may export variables).
#                    Runs under `set -e`. $DOCKERRUN_CPUS is set in its
#                    environment to the number of cores the container may use,
#                    or to OMP_NUM_THREADS when the caller has set that.
#   MOUNT_PROJECT_VENV  (optional, default 1) When 1, mount a persisted
#                    docker/.venv_$VENV_SUBDIR over that directory's .venv. Set
#                    to 0 for projects that need no virtualenv at all.
#   DEFAULT_COMMAND  (optional) Shell command line to run when the user gives no
#                    command. Without it, no command means an interactive shell,
#                    which is right for a dev container but wrong for a batch
#                    task that must exit with the work's status.
#   EXTRA_DOCKER_FLAGS  (optional array) Extra flags spliced into `docker run`,
#                    e.g. (-e HIP_ARCH=gfx942).
#   IMAGE            (optional, default mjp-rocmwarp) Image to run.
#   DOCKERRUN_NAME   (optional) Name for the container (docker run --name), which
#                    gives the caller a handle to stop it by. The container is
#                    created by the Docker daemon rather than as a child of this
#                    script, so it outlives whatever kills the script -- and an
#                    orphan goes on holding the GPU. A batch script that can be
#                    signalled (`scancel`, or SLURM's SIGKILL at the walltime cap)
#                    should set this and `docker rm -f` it from an exit trap.
#
# Debugging: set DOCKERRUN_PRINT=1 to print the assembled `docker run` argv, one
# argument per line, and exit without starting a container.

if [[ -z "${PROJECT_SUBDIR:-}" ]]; then
  echo "dockerrun_core.sh: PROJECT_SUBDIR must be set before sourcing" >&2
  exit 2
fi
MOUNT_PROJECT_VENV="${MOUNT_PROJECT_VENV:-1}"
VENV_SUBDIR="${VENV_SUBDIR:-$PROJECT_SUBDIR}"
IMAGE="${IMAGE:-mjp-rocmwarp}"
EXTRA_DOCKER_FLAGS=("${EXTRA_DOCKER_FLAGS[@]:-}")
# An unset array expands to a single empty string above; drop it.
[[ ${#EXTRA_DOCKER_FLAGS[@]} -eq 1 && -z "${EXTRA_DOCKER_FLAGS[0]}" ]] && EXTRA_DOCKER_FLAGS=()

# Parse leading options (before the user command). Stop at the first non-option
# argument (or an explicit `--`), leaving "$@" as the command to run.
run_as_root=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --root) run_as_root=1; shift ;;
    --) shift; break ;;
    *) break ;;
  esac
done

# A variant with a natural default action substitutes it for the interactive
# shell, so `srun dockerwarpbuild` exits when the build does instead of hanging
# on a shell nobody is attached to.
if [[ $# -eq 0 && -n "${DEFAULT_COMMAND:-}" ]]; then
  set -- "$DEFAULT_COMMAND"
fi

echo "Hostname ==> $(hostname)"

# The SLURM-allocated GPUs are the rows rocm-smi prints; column 2 is each GPU's
# KFD topology node id. Look up each allocated node's DRM render minor from the
# KFD topology (drm_render_minor) and build the --device flags restricting the
# container to exactly those /dev/dri/renderD* nodes. Deriving the mapping from
# sysfs at runtime is correct on any node, without maintaining a topology-specific
# KFD-node -> renderD lookup table.
input_keys=$(rocm-smi | grep -E '^[0-9]' | awk '{printf "%s ", $2}') || true

gpus_for_docker=""
for node in $input_keys; do
    props="/sys/class/kfd/kfd/topology/nodes/${node}/properties"
    if [[ ! -r "$props" ]]; then
        echo "WARNING: no KFD topology properties for node ${node} (${props}); skipping" >&2
        continue
    fi
    rmin=$(grep -oP 'drm_render_minor \K[0-9]+' "$props" || true)
    if [[ -z "$rmin" || "$rmin" == "0" ]]; then
        echo "WARNING: node ${node} has no drm_render_minor (not a render GPU?); skipping" >&2
        continue
    fi
    gpus_for_docker+="--device /dev/dri/renderD${rmin} "
done

echo "The allocated GPUs are KFD nodes : $input_keys"
echo "Restricting container to SLURM-allocated GPUs: --device=/dev/kfd ${gpus_for_docker}"

# $gpus_for_docker is intentionally unquoted so it word-splits into multiple --device args.
device_flags=(--device=/dev/kfd ${gpus_for_docker})

# SLURM confines the job to its allocated cores with a cgroup on the srun process,
# but the container is created by the Docker daemon (a separate system service),
# so it lands outside that cgroup and would see every core on the node. Translate
# the allocation into an explicit --cpuset-cpus, the same way the GPUs above have
# to be translated into --device flags. This process's affinity mask is what srun
# has already narrowed to the allocation; outside SLURM it lists all host cores,
# which is a no-op restriction.
cpu_flags=()
host_cpuset="$(awk '/^Cpus_allowed_list:/{print $2}' /proc/self/status || true)"
if [[ -n "$host_cpuset" ]]; then
    # Count the cores by expanding the mask's ranges (e.g. "0-3,8,12-15" -> 9).
    # `nproc` would be the obvious choice but it also honours OMP_NUM_THREADS,
    # which belongs to the thread budget applied below, not to what the hardware
    # allows -- mixing the two here would cap the cpuset itself at the requested
    # thread count.
    cpu_count="$(awk -F, '{n = 0
        for (i = 1; i <= NF; i++) {
            split($i, r, "-")
            n += (r[2] == "" ? 1 : r[2] - r[1] + 1)
        }
        print n}' <<<"$host_cpuset")"
    cpu_flags+=(--cpuset-cpus="$host_cpuset")
    echo "Restricting container to allocated CPUs: --cpuset-cpus=$host_cpuset ($cpu_count cores)"
else
    # Nothing restricts the container here, so every installed core is usable.
    # --all keeps OMP_NUM_THREADS out of the count, as above.
    cpu_count="$(nproc --all)"
    echo "WARNING: could not read Cpus_allowed_list; container CPUs left unrestricted" >&2
fi

# OpenMP/BLAS thread pools size themselves from the host core count rather than
# the affinity mask, so they oversubscribe an allocation that is only a slice of
# the node. Default them to the allocation size; a caller who sets
# OMP_NUM_THREADS is asking for a specific degree of parallelism, so that wins.
# DOCKERRUN_CPUS publishes the resulting budget to variants that parallelise
# their own work (e.g. a compile), so they stay within it too instead of adding
# their own core-count worth of processes on top of the thread pools. It is
# passed explicitly rather than left to `nproc` inside the container because
# nproc's own OMP_NUM_THREADS handling silently clamps to the online core count,
# which would quietly discard a deliberate oversubscription.
thread_count="${OMP_NUM_THREADS:-$cpu_count}"
thread_env_flags=(
    -e DOCKERRUN_CPUS="$thread_count"
    -e OMP_NUM_THREADS="$thread_count"
    -e MKL_NUM_THREADS="${MKL_NUM_THREADS:-$thread_count}"
    -e OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-$thread_count}"
)

# Derive all paths from the variant script's own location so the runner works from
# any checkout location (no hardcoded $HOME/robotics/... paths). Variants live at
# docker/ under the repo root, so the repo root is one level up. The repo root
# holds the editable checkouts they depend on (warp/, mujoco_playground/), so
# mounting it makes those deps resolve in the container.
# DOCKERRUN_SCRIPT_DIR is exported by the variant (this file sits next to it in docker/).
SCRIPT_DIR="$DOCKERRUN_SCRIPT_DIR"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_NAME="$(basename "$REPO_ROOT")"

# The container mirrors the repo root under /workspace/<repo name>, so everything
# inside it keeps the same relative layout inside the container. The project being
# worked on lives in a subdirectory of the repo root, so that (not the repo root)
# is the working dir, which is where `uv sync` finds pyproject.toml.
CONTAINER_PARENT=/workspace
CONTAINER_ROOT="$CONTAINER_PARENT/$REPO_NAME"
WORKDIR="$CONTAINER_ROOT/$PROJECT_SUBDIR"

if [[ ! -d "$REPO_ROOT/$PROJECT_SUBDIR" ]]; then
  echo "ERROR: project directory '$REPO_ROOT/$PROJECT_SUBDIR' does not exist." >&2
  exit 2
fi
if [[ "$MOUNT_PROJECT_VENV" -eq 1 && ! -d "$REPO_ROOT/$VENV_SUBDIR" ]]; then
  echo "ERROR: venv directory '$REPO_ROOT/$VENV_SUBDIR' does not exist." >&2
  exit 2
fi

# Give the container its own HOME directory, persisted on the host as .dockerhome
# next to the variant script (docker/.dockerhome), kept separate from the host's
# real home and the host's own .venv so the two toolchains don't clobber each
# other. It lives inside the repo, which is already bind-mounted into the container
# (via $REPO_ROOT:$CONTAINER_ROOT), so it survives the ephemeral (--rm) container
# automatically: the uv-managed Python (~/.local) and the uv/GPU caches (~/.cache)
# persist here, so `uv sync` only does incremental work instead of rebuilding from
# scratch. The container path is the same location relative to the repo root
# (which is mounted at $CONTAINER_ROOT).
SCRIPT_REL="${SCRIPT_DIR#"$REPO_ROOT"/}"   # e.g. docker
HOST_HOME="$SCRIPT_DIR/.dockerhome"
CONTAINER_HOME="$CONTAINER_ROOT/$SCRIPT_REL/.dockerhome"
mkdir -p "$HOST_HOME"

# The repo bind-mount would otherwise expose the host's own <project>/.venv
# inside the container, where it is useless: its interpreter lives under the host's
# real home, a path that does not exist in the container. Mount a container-only
# directory over that path instead. uv then creates its default <project>/.venv
# (no UV_PROJECT_ENVIRONMENT needed) while the host's copy stays hidden and
# untouched, and the venv persists across the ephemeral (--rm) container because
# it is really this host directory. Create it up front so Docker does not
# materialise the mount source as a root-owned directory.
# Derived from VENV_SUBDIR (the working directory, unless the variant separated
# the two) so the name and the location cannot drift apart if the project moves.
# Skipped entirely by MOUNT_PROJECT_VENV=0, for projects that build without a
# virtualenv: there is then no host .venv to shadow and nothing to persist.
venv_flags=()
if [[ "$MOUNT_PROJECT_VENV" -eq 1 ]]; then
  HOST_PROJECT_VENV="$SCRIPT_DIR/.venv_$VENV_SUBDIR"
  mkdir -p "$HOST_PROJECT_VENV"
  venv_flags=(-v "$HOST_PROJECT_VENV:$CONTAINER_ROOT/$VENV_SUBDIR/.venv")
fi

# Run the variant's setup (venv sync, build, ...) and then the user command. The
# -w flag already puts us in WORKDIR, and uv is baked into the mjp-rocmwarp image
# (see docker/Dockerfile + docker/dockerbuild.sh), so no runtime install is needed.
# Surrounding blank lines in CONTAINER_SETUP are trimmed so a variant can use a
# readable multi-line quote without changing the script the container receives.
_setup_body="${CONTAINER_SETUP:-}"
while [[ "$_setup_body" == $'\n'* ]]; do _setup_body="${_setup_body#$'\n'}"; done
while [[ "$_setup_body" == *$'\n' ]]; do _setup_body="${_setup_body%$'\n'}"; done
setup=$'\n  set -e\n'"$_setup_body"$'\n'

# Assemble the docker run invocation. Allocate a TTY interactively (no command)
# or when stdin is a terminal; otherwise stream output non-interactively so logs
# pipe cleanly (e.g. under srun).
docker_flags=(--rm)
if [[ $# -eq 0 || -t 0 ]]; then
  docker_flags+=(-it)
fi
if [[ -n "${DOCKERRUN_NAME:-}" ]]; then
  docker_flags+=(--name "$DOCKERRUN_NAME")
fi

# Run as the host user by default (host-owned files, GPU access via group-add).
# With --root, omit --user so the container runs as root.
user_flags=()
if [[ "$run_as_root" -eq 0 ]]; then
  user_flags+=(--user "$(id -u):$(id -g)")
else
  echo "Running container as ROOT (--root)."
fi

if [[ $# -eq 0 ]]; then
  # No command: drop into an interactive shell after the venv is set up.
  container_cmd=(bash -lc "$setup"' exec bash')
elif [[ $# -eq 1 ]]; then
  # A single argument is a shell command line, so `cd x && ...`, pipes and
  # redirections work as written. It is appended to the setup script and runs in
  # that same shell (inheriting `set -e`); the script's exit status is the
  # command's. Nothing can be exec'd here because the argument is a script, not
  # a program name -- that is what the multi-argument form below is for.
  container_cmd=(bash -lc "$setup""$1")
else
  # Several arguments are an argv vector: forwarded as the shell's positional
  # params and exec'd directly, so no quoting is re-interpreted by a shell.
  container_cmd=(bash -lc "$setup"' exec "$@"' bash "$@")
fi

# UV_LINK_MODE=copy overrides uv's default of hardlinking installed files out of
# its cache. Under hardlinks a file in site-packages and its cached copy are the
# same inode, so editing one in place silently rewrites the cached wheel for every
# environment built from that cache. Copying costs disk and install time but keeps
# the venv and the cache independent.
docker_run_argv=(
  docker run "${docker_flags[@]}"
  --label user="$USER"
  "${device_flags[@]}"
  "${cpu_flags[@]}"
  "${thread_env_flags[@]}"
  "${user_flags[@]}"
  --group-add video
  --group-add render
  --security-opt seccomp=unconfined
  --ipc=host
  --network=host
  --cap-add=SYS_PTRACE
  -e MUJOCO_GL=osmesa
  -e HOME="$CONTAINER_HOME"
  -e USER="$USER"
  -e LOGNAME="$USER"
  -e UV_LINK_MODE="${UV_LINK_MODE:-copy}"
  "${EXTRA_DOCKER_FLAGS[@]}"
  -v "$REPO_ROOT:$CONTAINER_ROOT"
  "${venv_flags[@]}"
  -v "/scratch/$USER:/scratch/$USER"
  -w "$WORKDIR"
  "$IMAGE"
  "${container_cmd[@]}"
)

if [[ -n "${DOCKERRUN_PRINT:-}" ]]; then
  printf '%s\n' "${docker_run_argv[@]}"
  exit 0
fi

exec "${docker_run_argv[@]}"
