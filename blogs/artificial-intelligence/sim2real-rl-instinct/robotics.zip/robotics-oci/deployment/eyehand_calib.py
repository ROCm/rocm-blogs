#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Eye-in-hand calibration for the WRIST-mounted RealSense on the xArm6.

Geometry: the camera is rigidly attached to the TCP. For a STATIC cube observed from M
different arm poses, the cube's BASE-frame position p_base is constant, while its CAMERA-frame
position p_cam^(i) changes with pose i:

    p_base = T_base_tcp^(i) @ T_tcp_cam @ p_cam^(i)        for every pose i

Unknowns: the fixed 4x4 T_tcp_cam (camera->TCP mount) AND the constant p_base (3).
This is the classic "point-only" eye-in-hand problem (a.k.a. AX=B with a fixed world point).
We solve it as a small nonlinear least-squares over [rpy(3), t(3), p_base(3)] = 9 params,
minimizing the base-frame reprojection residual across all poses. Needs M>=3 well-spread poses
(vary orientation, not just translation, or T_tcp_cam rotation is unobservable).

INPUT  poses.json: [{"p_cam":[x,y,z], "T_base_tcp":[16 row-major floats]}, ...]
       (collect with collect_pose.py: at each arm pose, it grabs a frame -> p_cam via the SAME
        SlimSAM perception, and reads TF link_base->link_tcp -> T_base_tcp.)
OUTPUT the fixed T_tcp_cam as 16 space-separated floats for:
        run_act_pickplace.sh --mode eye_in_hand --tcp-cam "f0 ... f15"

Pure numpy + scipy.optimize (scipy is small; if absent, a Gauss-Newton fallback runs).
"""
import sys, json
import numpy as np


def rpy_to_R(r, p, y):
    cr, sr = np.cos(r), np.sin(r); cp, sp = np.cos(p), np.sin(p); cy, sy = np.cos(y), np.sin(y)
    Rx = np.array([[1,0,0],[0,cr,-sr],[0,sr,cr]])
    Ry = np.array([[cp,0,sp],[0,1,0],[-sp,0,cp]])
    Rz = np.array([[cy,-sy,0],[sy,cy,0],[0,0,1]])
    return Rz @ Ry @ Rx


def residuals(params, P_cam, T_bt):
    """params=[r,p,y, tx,ty,tz, bx,by,bz]; return flat residual vector (3*M)."""
    R = rpy_to_R(*params[:3]); t = params[3:6]; p_base = params[6:9]
    T_tc = np.eye(4); T_tc[:3,:3] = R; T_tc[:3,3] = t
    res = []
    for pc, Tbt in zip(P_cam, T_bt):
        ph = np.array([pc[0], pc[1], pc[2], 1.0])
        pred = (Tbt @ T_tc @ ph)[:3]
        res.append(pred - p_base)
    return np.concatenate(res)


def solve(poses):
    P_cam = [np.asarray(p["p_cam"], float) for p in poses]
    T_bt = [np.asarray(p["T_base_tcp"], float).reshape(4,4) for p in poses]
    # init: identity mount, p_base = mean of (T_base_tcp @ p_cam) with identity mount
    p0 = np.zeros(9)
    guesses = [(Tbt @ np.array([*pc,1.0]))[:3] for pc, Tbt in zip(P_cam, T_bt)]
    p0[6:9] = np.mean(guesses, axis=0)
    try:
        from scipy.optimize import least_squares
        sol = least_squares(residuals, p0, args=(P_cam, T_bt), method="lm", max_nfev=5000)
        x = sol.x
    except ImportError:
        x = p0.copy()                                   # Gauss-Newton fallback
        for _ in range(200):
            r = residuals(x, P_cam, T_bt)
            J = np.zeros((len(r), 9)); eps = 1e-6
            for k in range(9):
                xp = x.copy(); xp[k] += eps
                J[:, k] = (residuals(xp, P_cam, T_bt) - r) / eps
            dx = np.linalg.lstsq(J, -r, rcond=None)[0]
            x += dx
            if np.linalg.norm(dx) < 1e-9:
                break
    R = rpy_to_R(*x[:3]); T_tc = np.eye(4); T_tc[:3,:3] = R; T_tc[:3,3] = x[3:6]
    res = residuals(x, P_cam, T_bt).reshape(-1,3)
    rms = np.sqrt((res**2).sum(1)).mean()
    return T_tc, x[6:9], rms, np.linalg.norm(res, axis=1)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    poses = json.load(open(sys.argv[1]))
    if len(poses) < 3:
        print(f"need >=3 poses, got {len(poses)}"); sys.exit(2)
    T_tc, p_base, rms, per = solve(poses)
    print("T_tcp_cam (4x4):"); print(np.round(T_tc, 5))
    print(f"\nsolved cube base pos: {np.round(p_base,4)}")
    print(f"per-pose residual (mm): {np.round(per*1000,1)}")
    print(f"RMS residual: {rms*1000:.1f} mm  (<~10mm good; >30mm => add poses / vary orientation)")
    print(f"\n--mode eye_in_hand --tcp-cam \"{' '.join(f'{v:.6f}' for v in T_tc.reshape(-1))}\"")
