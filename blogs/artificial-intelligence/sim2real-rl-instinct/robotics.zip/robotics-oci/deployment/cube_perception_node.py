#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""SAM3-based cube perception for the state-based xArm6 ACT policy.

Decoupled perception (plan: vision NEVER trained in sim; SAM3 runs on REAL images only and
fills the `cube_xyz` slot that sim filled with privileged state). Pipeline:

  RGB + aligned depth + camera intrinsics
    -> segmentation -> boolean cube mask   [backend: mock | slimsam | real]
    -> centroid pixel (u,v)
    -> median depth in mask -> deproject (u,v,z) with intrinsics -> camera-frame XYZ
    -> apply camera->base extrinsic (4x4) -> base-frame cube_xyz
    -> publish geometry_msgs/PointStamped on /cube_xyz (frame=link_base)

Segmentation is isolated in Sam3Segmenter with three backends:
  mock    — numpy green-pixel threshold (no torch) for dry-run/CI.
  slimsam — HSV saturation -> bbox -> SlimSAM box-prompt; the DEPLOY default on the gfx1150
            iGPU (SAM3 text model hangs there; SlimSAM is a pruned plain-SAM that runs ~1s/
            frame). Perception only needs to fire during the static-cube approach (FK takes
            over post-grasp at 50Hz), so ~1Hz is sufficient.
  real    — facebook/sam3 text-prompt (validated on gfx1201; hangs on gfx1150 — do not use
            on the Strix box).
Everything downstream (deprojection, extrinsics, mask->centroid) is pure-numpy + testable.

Run (ROS2):   python cube_perception_node.py --ros-args -p backend:=slimsam
Offline test: python cube_perception_node.py --selftest
"""
from __future__ import annotations

import argparse
import os
import pathlib
from typing import Optional

import numpy as np

# Calibration files this node may read live next to it, so the bundle can be
# copied anywhere on the robot host without re-pointing every parameter.
_CALIB_DIR = pathlib.Path(__file__).resolve().parent / "calib"


# ─────────────────────────────────────────────────────────────────────────────
# SAM3 segmentation — swappable backend (mock | real). Pure numpy I/O so it's
# testable without ROS or torch.
# ─────────────────────────────────────────────────────────────────────────────
class Sam3Segmenter:
    """Returns a boolean mask (H,W) for the cube, or None.

    Backends:
      mock    — pure-numpy green-pixel threshold (no torch); for dry-run/CI.
      slimsam — HSV saturation threshold locates the cube -> bbox -> SlimSAM box-prompt
                gives a tight mask. RUNS ON THE gfx1150 iGPU (SAM3 hangs there; SlimSAM
                is a pruned plain-SAM, no flash-attn kernels, ~1s/frame warm). This is the
                DEPLOY default on radical-strix. SlimSAM is point/box-promptable, NOT text,
                so `prompt` is ignored; the green-cube HSV gate stands in for text.
      real    — facebook/sam3 text-prompt (validated on gfx1201; hangs on gfx1150).
    """

    # green cube is highly saturated vs the green-cast wood table (measured: cube S~239,
    # table S~104). Saturation, not hue, separates them on the RealSense frame.
    HSV_LO = (40, 150, 50)
    HSV_HI = (90, 255, 255)

    def __init__(self, backend: str = "mock", prompt: str = "cube",
                 score_threshold: float = 0.5, device: str = "cuda",
                 slimsam_ckpt: str = "Zigeng/SlimSAM-uniform-77"):
        self.backend = backend
        self.prompt = prompt
        self.score_threshold = score_threshold
        self.device = device
        self.slimsam_ckpt = slimsam_ckpt
        self._model = None
        self._processor = None
        self._dino = None
        self._dproc = None
        self.dino_ckpt = "IDEA-Research/grounding-dino-tiny"
        self.dino_threshold = 0.25
        self.dino_text_threshold = 0.2
        if backend == "real":
            self._load_real()
        elif backend == "slimsam":
            self._load_slimsam()
        elif backend == "dinosam":
            self._load_slimsam(); self._load_dino()
        # backend "fused" / "mock" need no model (pure numpy/cv2)

    def _load_dino(self):
        # GroundingDINO text-prompt detector -> box; SlimSAM (already loaded) refines to a mask.
        # Same pattern as brio_dlt_dinosam.py. Prompt should end with a period ("cube.").
        from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection
        self._dproc = AutoProcessor.from_pretrained(self.dino_ckpt)
        self._dino = AutoModelForZeroShotObjectDetection.from_pretrained(
            self.dino_ckpt).to(self.device).eval()

    def _dinosam_mask(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        """GroundingDINO detects the cube (text prompt) -> best box -> SlimSAM mask.
        Text-grounded (no HSV), so it localizes the cube even off the green gate."""
        from PIL import Image
        torch = self._torch
        pil = Image.fromarray(rgb).convert("RGB")
        text = self.prompt if self.prompt.strip().endswith(".") else self.prompt.strip() + "."
        inp = self._dproc(images=pil, text=text, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self._dino(**inp)
        res = self._dproc.post_process_grounded_object_detection(
            out, inp.input_ids, threshold=self.dino_threshold,
            text_threshold=self.dino_text_threshold, target_sizes=[pil.size[::-1]])[0]
        boxes = res["boxes"].cpu().numpy(); scores = res["scores"].cpu().numpy()
        if len(boxes) == 0:
            return None
        box = boxes[int(np.argmax(scores))]                      # highest-scoring cube box
        ib = [[[float(box[0]), float(box[1]), float(box[2]), float(box[3])]]]
        sinp = self._processor(pil, input_boxes=ib, return_tensors="pt").to(self.device)
        with torch.no_grad():
            sout = self._model(**sinp)
        masks = self._processor.image_processor.post_process_masks(
            sout.pred_masks.cpu(), sinp["original_sizes"].cpu(),
            sinp["reshaped_input_sizes"].cpu())[0][0].numpy()
        iou = sout.iou_scores.flatten().cpu().numpy()
        best = int(np.argmax(iou[:masks.shape[0]])) if masks.shape[0] > 1 else 0
        mask = masks[best].astype(bool)
        return mask if mask.sum() > 20 else None

    def _load_real(self):
        # Deferred import so the node runs in mock mode without transformers/torch.
        import torch
        from transformers import Sam3Model, Sam3Processor
        # gfx1201 may need HSA_OVERRIDE_GFX_VERSION set in the environment BEFORE torch init.
        self._torch = torch
        self._model = Sam3Model.from_pretrained("facebook/sam3").to(self.device)
        self._processor = Sam3Processor.from_pretrained("facebook/sam3")

    def _load_slimsam(self):
        import torch
        from transformers import SamModel, SamProcessor
        if not torch.cuda.is_available():
            self.device = "cpu"
        self._torch = torch
        self._model = SamModel.from_pretrained(self.slimsam_ckpt).to(self.device).eval()
        self._processor = SamProcessor.from_pretrained(self.slimsam_ckpt)

    def segment(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        """rgb: (H,W,3) uint8. Returns best boolean mask (H,W) or None."""
        if self.backend == "mock":
            return self._mock_mask(rgb)
        if self.backend == "slimsam":
            return self._slimsam_mask(rgb)
        if self.backend == "dinosam":
            return self._dinosam_mask(rgb)
        return self._real_mask(rgb)

    def hsv_bbox(self, rgb: np.ndarray) -> Optional[tuple]:
        """HSV saturation gate -> bbox (x0,y0,x1,y1) of the largest green-cube blob."""
        import cv2
        bgr = rgb[..., ::-1]
        hsv = cv2.cvtColor(np.ascontiguousarray(bgr), cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, np.array(self.HSV_LO), np.array(self.HSV_HI))
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            return None
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) < 80:                       # reject specks
            return None
        x, y, w, h = cv2.boundingRect(c)
        return (x, y, x + w, y + h)

    def _slimsam_mask(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        from PIL import Image
        torch = self._torch
        bb = self.hsv_bbox(rgb)
        if bb is None:
            return None
        box = [[[float(bb[0]), float(bb[1]), float(bb[2]), float(bb[3])]]]
        pil = Image.fromarray(rgb).convert("RGB")
        inp = self._processor(pil, input_boxes=box, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self._model(**inp)
        masks = self._processor.image_processor.post_process_masks(
            out.pred_masks.cpu(), inp["original_sizes"].cpu(),
            inp["reshaped_input_sizes"].cpu())[0][0].numpy()   # (C,H,W) bool
        iou = out.iou_scores.flatten().cpu().numpy()
        best = int(np.argmax(iou[:masks.shape[0]])) if masks.shape[0] > 1 else 0
        mask = masks[best].astype(bool)
        return mask if mask.sum() > 20 else None

    def _real_mask(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        from PIL import Image
        torch = self._torch
        image = Image.fromarray(rgb).convert("RGB")
        inputs = self._processor(images=image, text=self.prompt,
                                 return_tensors="pt").to(self.device)
        with torch.no_grad():
            outputs = self._model(**inputs)
        results = self._processor.post_process_instance_segmentation(
            outputs, threshold=self.score_threshold, mask_threshold=0.5,
            target_sizes=inputs.get("original_sizes").tolist())[0]
        if len(results["masks"]) == 0:
            return None
        # best-scoring mask
        scores = results["scores"].cpu().numpy()
        best = int(np.argmax(scores))
        if scores[best] < self.score_threshold:
            return None
        return results["masks"][best].cpu().numpy().astype(bool)

    def fused_mask(self, rgb: np.ndarray, depth_m: np.ndarray,
                   last_uv: Optional[tuple] = None,
                   ir: Optional[np.ndarray] = None) -> Optional[np.ndarray]:
        """Color+depth(+IR) fused cube mask — robust at CLOSE RANGE where SlimSAM's bbox breaks.

        During the final descent the gripper occludes the cube and the green blob fragments, so a
        clean bbox isn't available. Depth saves it: the cube stands ~6cm proud of the table, so
        green pixels that are ALSO depth-foreground (closer than the surrounding table) reliably
        pick out the cube even when only a sliver of green shows. If green is fully occluded we
        fall back to the nearest depth-foreground blob around the last known cube pixel. IR (if
        provided, same HxW as depth) adds a brightness-foreground vote: the IR projector lights
        near objects brightly, so a bright-IR region co-located with depth-fg reinforces the cube
        vs shadowed table — used to break ties when green is gone.

        rgb (H,W,3) uint8, depth_m (H,W) float32 meters, ir (H,W) uint8 optional. -> bool mask|None.
        """
        import cv2
        H, W = depth_m.shape
        bgr = np.ascontiguousarray(rgb[..., ::-1])
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        green = cv2.inRange(hsv, np.array(self.HSV_LO), np.array(self.HSV_HI)) > 0
        ir_fg = None
        if ir is not None and ir.shape == depth_m.shape:
            ir_fg = ir > max(60, int(np.median(ir)) + 30)   # bright vs scene median

        valid = (depth_m > 0.05) & np.isfinite(depth_m)
        # foreground = closer than the local background. Use the median of valid depth as the table
        # reference; the cube sits ~6cm nearer the (downward-looking) camera than the table.
        if valid.sum() < 50:
            return None
        ref = np.median(depth_m[valid])
        fg = valid & (depth_m < ref - 0.015)          # >1.5cm nearer than table median

        cand = green & valid
        if cand.sum() >= 20:
            # green AND (foreground OR near-green-depth): keep the green cluster, prefer fg.
            gd = depth_m[cand]
            zc = np.median(gd)                         # cube surface depth
            mask = green & valid & (np.abs(depth_m - zc) < 0.05)
        elif fg.sum() >= 30:
            # green fully occluded -> depth-foreground blob nearest last_uv, intersected with IR
            # brightness-foreground when available (drops table shadows the depth fg may include).
            mask = fg & ir_fg if ir_fg is not None and (fg & ir_fg).sum() >= 20 else fg
        else:
            return None

        mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            return None
        if last_uv is not None and len(cnts) > 1:
            # pick the blob whose centroid is closest to the last known cube pixel (tracking)
            def dist(c):
                Mn = cv2.moments(c)
                if Mn["m00"] == 0:
                    return 1e9
                cx, cy = Mn["m10"]/Mn["m00"], Mn["m01"]/Mn["m00"]
                return (cx-last_uv[0])**2 + (cy-last_uv[1])**2
            c = min(cnts, key=dist)
        else:
            c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) < 15:
            return None
        out = np.zeros((H, W), bool)
        cv2.drawContours(out.view(np.uint8).reshape(H, W), [c], -1, 1, -1)
        return out

    def _mock_mask(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        """Mock: segment the most-green region (our cube is green) — lets the whole
        deprojection/extrinsics path be tested end-to-end without SAM3."""
        r, g, b = rgb[..., 0].astype(int), rgb[..., 1].astype(int), rgb[..., 2].astype(int)
        mask = (g - r > 40) & (g - b > 40)
        return mask if mask.sum() > 20 else None


# ─────────────────────────────────────────────────────────────────────────────
# Vision gripper-state estimator: GroundingDINO ("a black robot gripper") gives an
# accurate box, SlimSAM refines it to a mask, and the mask geometry yields the 3
# contact-obs signals the policy trained on (see pick.py::_contact_obs):
#   left_contact, right_contact  — binary, both finger pads on the cube
#   gripper_force_mag            — 0..force_reward_max_force (10 N) squeeze proxy
# plus an openness scalar (finger span) for the gripper qpos obs.
#
# This REPLACES the xArm SDK gripper readback, whose get_gripper_position() returns a
# negative sentinel (-1/-2) at the fully-closed hard stop; the controller mis-mapped
# that to "fully open", firing a PHANTOM max-force grasp on every empty close so the
# policy lifted a nonexistent cube instead of descending.
#
# Detection reuses the exact DINO+SlimSAM pattern proven in brio_dlt_dinosam.py.
# ─────────────────────────────────────────────────────────────────────────────
class GripperStateEstimator:
    GRIPPER_PROMPT = "a black robot gripper."
    # green cube HSV gate (same separation the cube segmenter uses).
    HSV_LO = (40, 150, 50)
    HSV_HI = (90, 255, 255)
    SIM_FORCE_MAX_N = 10.0                 # pick.py force_reward_max_force

    def __init__(self, device: str = "cuda",
                 dino_ckpt: str = "IDEA-Research/grounding-dino-tiny",
                 slimsam_ckpt: str = "Zigeng/SlimSAM-uniform-77",
                 open_px: float = 220.0, closed_px: float = 60.0,
                 dino_threshold: float = 0.25, dino_text_threshold: float = 0.2):
        import torch
        from transformers import (AutoProcessor, AutoModelForZeroShotObjectDetection,
                                   SamModel, SamProcessor)
        self._torch = torch
        if not torch.cuda.is_available():
            device = "cpu"
        self.device = device
        self._dproc = AutoProcessor.from_pretrained(dino_ckpt)
        self._dino = AutoModelForZeroShotObjectDetection.from_pretrained(dino_ckpt).to(device).eval()
        self._sproc = SamProcessor.from_pretrained(slimsam_ckpt)
        self._sam = SamModel.from_pretrained(slimsam_ckpt).to(device).eval()
        self.open_px = float(open_px)
        self.closed_px = float(closed_px)
        self._dth = float(dino_threshold)
        self._tth = float(dino_text_threshold)

    def _dino_box(self, pil, roi_x_max=None, roi_y_max=None):
        """Most-compact 'black robot gripper' box, optional ROI filter (BRIO clutter)."""
        torch = self._torch
        inp = self._dproc(images=pil, text=self.GRIPPER_PROMPT, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self._dino(**inp)
        res = self._dproc.post_process_grounded_object_detection(
            out, inp.input_ids, threshold=self._dth, text_threshold=self._tth,
            target_sizes=[pil.size[::-1]])[0]
        boxes = res["boxes"].cpu().numpy(); scores = res["scores"].cpu().numpy()
        cand = []
        for b, s in zip(boxes, scores):
            if s < self._dth:
                continue
            cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
            if roi_x_max is not None and cx > roi_x_max:
                continue
            if roi_y_max is not None and cy > roi_y_max:
                continue
            cand.append((b, s))
        if not cand:
            return None
        areas = [(b[2] - b[0]) * (b[3] - b[1]) for b, _ in cand]
        return cand[int(np.argmin(areas))][0]

    def _sam_mask(self, pil, box):
        torch = self._torch
        ib = [[[float(box[0]), float(box[1]), float(box[2]), float(box[3])]]]
        inp = self._sproc(pil, input_boxes=ib, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self._sam(**inp)
        masks = self._sproc.image_processor.post_process_masks(
            out.pred_masks.cpu(), inp["original_sizes"].cpu(),
            inp["reshaped_input_sizes"].cpu())[0][0].numpy()
        iou = out.iou_scores.flatten().cpu().numpy()
        best = int(np.argmax(iou[:masks.shape[0]])) if masks.shape[0] > 1 else 0
        mask = masks[best].astype(bool)
        return mask if mask.sum() > 20 else None

    def gripper_mask(self, rgb: np.ndarray, roi_x_max=None, roi_y_max=None):
        """DINO box -> SlimSAM mask of the gripper, or None if not detected."""
        from PIL import Image
        pil = Image.fromarray(rgb).convert("RGB")
        box = self._dino_box(pil, roi_x_max, roi_y_max)
        if box is None:
            return None
        return self._sam_mask(pil, box)

    @staticmethod
    def _fingertip_span(mask: np.ndarray) -> Optional[float]:
        """Gripper finger span in px, measured near the fingertip (lowest quarter of
        the mask). Open fingers span wide; a closed gripper collapses to a narrow
        blob. Uses the max horizontal extent over the tip rows (robust to the mask's
        wrist/body being wider than the fingers)."""
        ys, xs = np.where(mask)
        if len(xs) < 20:
            return None
        y0, y1 = ys.min(), ys.max()
        tip_band = ys >= (y1 - max(6, (y1 - y0) // 4))    # lowest ~quarter
        if tip_band.sum() < 8:
            return None
        return float(xs[tip_band].max() - xs[tip_band].min())

    def _cube_between_fingers(self, rgb: np.ndarray, gmask: np.ndarray) -> bool:
        """Both-pad contact proxy: green cube pixels sit INSIDE the gripper mask's
        bounding box AND are flanked by gripper pixels on the left and right (i.e.
        the cube is between the two fingers), not merely near the gripper."""
        import cv2
        ys, xs = np.where(gmask)
        if len(xs) < 20:
            return False
        x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        bgr = np.ascontiguousarray(rgb[..., ::-1])
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        green = cv2.inRange(hsv, np.array(self.HSV_LO), np.array(self.HSV_HI)) > 0
        # green inside the gripper's bbox
        roi = np.zeros_like(green); roi[y0:y1 + 1, x0:x1 + 1] = True
        gin = green & roi
        if gin.sum() < 15:
            return False
        gy, gx = np.where(gin)
        gcx = int(gx.mean()); gcy = int(gy.mean())
        # gripper pixels to the left AND right of the green centroid at that row band
        band = (ys >= gcy - 8) & (ys <= gcy + 8)
        if band.sum() < 8:
            return False
        bx = xs[band]
        return bool((bx < gcx).any() and (bx > gcx).any())

    def estimate(self, brio_rgb, wrist_rgb, brio_roi_x_max=None, brio_roi_y_max=None):
        """Fuse BRIO + wrist -> (left_contact, right_contact, force_mag, openness).
        openness from BRIO span; capture = brio_capture OR wrist_capture; force ramps
        with squeeze (1-openness) once captured — mirrors sim |actuator_force|, which
        is high whenever the motor squeezes something, regardless of the command.
        Returns None if the gripper isn't detected in either view (caller holds the
        last value)."""
        openness = None
        brio_cap = wrist_cap = False
        if brio_rgb is not None:
            gm = self.gripper_mask(brio_rgb, brio_roi_x_max, brio_roi_y_max)
            if gm is not None:
                span = self._fingertip_span(gm)
                if span is not None:
                    denom = max(self.open_px - self.closed_px, 1.0)
                    openness = float(np.clip((span - self.closed_px) / denom, 0.0, 1.0))
                brio_cap = self._cube_between_fingers(brio_rgb, gm)
        if wrist_rgb is not None:
            gmw = self.gripper_mask(wrist_rgb)
            if gmw is not None:
                wrist_cap = self._cube_between_fingers(wrist_rgb, gmw)
        if openness is None and not brio_cap and not wrist_cap:
            return None
        if openness is None:
            openness = 0.0
        captured = bool(brio_cap or wrist_cap)
        contact = 1.0 if captured else 0.0
        # force proxy: squeeze force rises with capture depth (1-openness). Only while
        # actually capturing a cube; free motion / empty close -> 0 (no phantom).
        force_mag = 0.0
        if captured:
            force_mag = float(np.clip(1.0 - openness, 0.0, 1.0)) * self.SIM_FORCE_MAX_N
        return (contact, contact, force_mag, float(openness))


# ─────────────────────────────────────────────────────────────────────────────
# Direct RealSense grab (pyrealsense2) — used when there is no realsense2_camera ROS
# node publishing topics (the deploy image has pyrealsense2 + librealsense but NOT the
# ROS camera pkg). Persistent pipeline so the ROS node can poll frames each tick.
# ─────────────────────────────────────────────────────────────────────────────
class RealSenseGrabber:
    """Owns a persistent RealSense pipeline; latest() returns (rgb, depth_m, K).
    Also enables the left IR stream (aligned-ish to color) so the perception can use IR as a
    third signal (foreground/occlusion confirmation) when RGB green drops out at close range."""

    def __init__(self, width=640, height=480, fps=30, warmup=10, want_ir=True, serial=None):
        import pyrealsense2 as rs
        self._rs = rs
        self._pipe = rs.pipeline()
        cfg = rs.config()
        if serial:                                    # pin a specific device (two RealSenses on the bus)
            cfg.enable_device(str(serial))
        cfg.enable_stream(rs.stream.color, width, height, rs.format.rgb8, fps)
        cfg.enable_stream(rs.stream.depth, width, height, rs.format.z16, fps)
        self._want_ir = want_ir
        if want_ir:
            try:
                cfg.enable_stream(rs.stream.infrared, 1, width, height, rs.format.y8, fps)
            except Exception:
                self._want_ir = False
        self._profile = self._pipe.start(cfg)
        self._align = rs.align(rs.stream.color)
        self._scale = self._profile.get_device().first_depth_sensor().get_depth_scale()
        for _ in range(warmup):                       # auto-exposure settle
            self._pipe.wait_for_frames()
        self._K = None

    def latest(self):
        """Returns (rgb, depth_m, K). IR (if enabled) is on self.last_ir after each call."""
        frames = self._align.process(self._pipe.wait_for_frames())
        c = frames.get_color_frame(); d = frames.get_depth_frame()
        if not c or not d:
            return None
        rgb = np.asanyarray(c.get_data())
        depth_m = np.asanyarray(d.get_data()).astype(np.float32) * self._scale
        self.last_ir = None
        if self._want_ir:
            try:
                irf = frames.get_infrared_frame(1)
                if irf:
                    self.last_ir = np.asanyarray(irf.get_data())  # (H,W) uint8, NOT color-aligned
            except Exception:
                pass
        if self._K is None:
            i = c.get_profile().as_video_stream_profile().get_intrinsics()
            self._K = np.array([[i.fx, 0, i.ppx], [0, i.fy, i.ppy], [0, 0, 1]], np.float64)
        return rgb, depth_m, self._K

    def stop(self):
        try:
            self._pipe.stop()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# BRIO scene camera grabber (RGB-only, fixed overhead). Localizes the cube via a
# precomputed DLT projection P_brio + ray/table-plane intersection. Independent of the
# wrist camera, so it survives when the gripper occludes the wrist view at close range.
# ─────────────────────────────────────────────────────────────────────────────
class BrioGrabber:
    def __init__(self, dev=6, width=1280, height=720):
        import cv2
        self._cv2 = cv2
        self._cap = cv2.VideoCapture(dev)
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        for _ in range(8):
            self._cap.read()

    def latest_rgb(self):
        """Grab the latest BRIO frame as RGB (H,W,3) uint8, or None. Flushes a couple
        of buffered frames first so the read is fresh (used by the gripper-state
        estimator, which needs the current finger pose, not a stale frame)."""
        cv2 = self._cv2
        for _ in range(2):
            ok, fr = self._cap.read()
        if not ok or fr is None:
            return None
        return cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)

    def cube_base_xy(self, P, hsv_lo, hsv_hi, z_plane=0.05):
        """Detect green cube in BRIO, back-project pixel through P, intersect plane z=z_plane.
        Returns (x, y, z_plane) in base frame, or None."""
        cv2 = self._cv2
        for _ in range(2):
            ok, fr = self._cap.read()
        if not ok or fr is None:
            return None
        hsv = cv2.cvtColor(fr, cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, np.array(hsv_lo), np.array(hsv_hi))
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            return None
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) < 60:
            return None
        M = cv2.moments(c)
        u, v = M["m10"]/M["m00"], M["m01"]/M["m00"]
        # back-project: (u*P3 - P1).X = 0 ; (v*P3 - P2).X = 0, X=[x,y,z_plane,1]
        A = np.vstack([u*P[2]-P[0], v*P[2]-P[1]])    # 2x4
        M2 = A[:, :2]; rhs = -(A[:, 2]*z_plane + A[:, 3])
        try:
            xy = np.linalg.solve(M2, rhs)
        except np.linalg.LinAlgError:
            return None
        return np.array([xy[0], xy[1], z_plane], np.float64)

    def release(self):
        try:
            self._cap.release()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Geometry: mask -> centroid pixel -> deproject -> camera frame -> base frame.
# All pure numpy, fully testable.
# ─────────────────────────────────────────────────────────────────────────────
def mask_centroid_depth(mask: np.ndarray, depth_m: np.ndarray) -> Optional[tuple]:
    """Return (u, v, z) — centroid pixel + median valid depth (m) inside the mask."""
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return None
    u = float(xs.mean()); v = float(ys.mean())
    d = depth_m[ys, xs]
    d = d[(d > 0) & np.isfinite(d)]
    if d.size == 0:
        return None
    return u, v, float(np.median(d))


def deproject(u: float, v: float, z: float, K: np.ndarray) -> np.ndarray:
    """Pixel (u,v) + depth z -> camera-frame XYZ using 3x3 intrinsics K."""
    fx, fy = K[0, 0], K[1, 1]; cx, cy = K[0, 2], K[1, 2]
    x = (u - cx) * z / fx
    y = (v - cy) * z / fy
    return np.array([x, y, z], dtype=np.float64)


def cam_to_base(p_cam: np.ndarray, T_base_cam: np.ndarray) -> np.ndarray:
    """Apply 4x4 camera->base extrinsic to a camera-frame point."""
    p_h = np.array([p_cam[0], p_cam[1], p_cam[2], 1.0])
    return (T_base_cam @ p_h)[:3]


def estimate_cube_xyz(rgb, depth_m, K, T_base_cam, segmenter) -> Optional[np.ndarray]:
    """Full pipeline: image -> base-frame cube_xyz, or None if not found."""
    mask = segmenter.segment(rgb)
    if mask is None:
        return None
    cd = mask_centroid_depth(mask, depth_m)
    if cd is None:
        return None
    u, v, z = cd
    p_cam = deproject(u, v, z, K)
    return cam_to_base(p_cam, T_base_cam)


# ─────────────────────────────────────────────────────────────────────────────
# Offline self-test (no ROS / no SAM3): synth a green cube on a depth plane,
# verify the recovered base-frame xyz matches ground truth.
# ─────────────────────────────────────────────────────────────────────────────
def selftest():
    H, W = 240, 320
    # Intrinsics (typical RealSense-ish)
    K = np.array([[300.0, 0, W/2], [0, 300.0, H/2], [0, 0, 1]], dtype=np.float64)
    # Ground-truth cube in CAMERA frame at (0.05, -0.02, 0.6) m
    gt_cam = np.array([0.05, -0.02, 0.60])
    u = K[0, 0] * gt_cam[0] / gt_cam[2] + K[0, 2]
    v = K[1, 1] * gt_cam[1] / gt_cam[2] + K[1, 2]
    rgb = np.zeros((H, W, 3), np.uint8)
    depth = np.full((H, W), 1.2, np.float32)  # background plane
    # paint a green square + set its depth
    ui, vi = int(round(u)), int(round(v)); s = 8
    rgb[vi-s:vi+s, ui-s:ui+s] = [10, 220, 20]
    depth[vi-s:vi+s, ui-s:ui+s] = gt_cam[2]
    # camera->base extrinsic: identity rotation + a translation/offset for the test
    T = np.eye(4); T[:3, 3] = [0.3, 0.0, 0.5]
    seg = Sam3Segmenter(backend="mock")
    out = estimate_cube_xyz(rgb, depth, K, T, seg)
    expect = gt_cam + T[:3, 3]
    err = np.linalg.norm(out - expect) if out is not None else 1e9
    print(f"recovered base xyz: {None if out is None else np.round(out,4)}")
    print(f"expected  base xyz: {np.round(expect,4)}")
    print(f"error: {err*1000:.2f} mm  -> {'PASS' if err < 0.01 else 'FAIL'}")


# ─────────────────────────────────────────────────────────────────────────────
# ROS2 node (only imported/used when running under ROS).
# ─────────────────────────────────────────────────────────────────────────────
def ros_main():
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Image, CameraInfo
    from geometry_msgs.msg import PointStamped

    try:
        from cv_bridge import CvBridge
    except ImportError:
        CvBridge = None

    class CubePerceptionNode(Node):
        def __init__(self):
            super().__init__("cube_perception_node")
            self.declare_parameter("backend", "mock")          # mock | slimsam | real
            self.declare_parameter("camera_source", "ros")     # ros | realsense (direct grab)
            self.declare_parameter("prompt", "cube")
            self.declare_parameter("color_topic", "/camera/color/image_raw")
            self.declare_parameter("depth_topic", "/camera/aligned_depth_to_color/image_raw")
            self.declare_parameter("info_topic", "/camera/color/camera_info")
            self.declare_parameter("depth_scale", 0.001)        # mm->m for RealSense uint16
            self.declare_parameter("base_frame", "link_base")
            self.declare_parameter("tcp_frame", "link_tcp")
            # Extrinsic mode:
            #   static      — camera fixed in the world. p_base = T_base_cam @ p_cam.
            #   eye_in_hand — camera on the wrist (THIS RIG). p_base = T_base_tcp(live TF) @
            #                 T_tcp_cam @ p_cam. T_base_tcp comes from the driver's TF each tick;
            #                 T_tcp_cam is the fixed camera->TCP mount transform (calibrate).
            self.declare_parameter("extrinsic_mode", "static")
            # static extrinsic camera->base (16 row-major floats). MUST be calibrated for static.
            self.declare_parameter(
                "T_base_cam",
                [1.,0.,0.,0., 0.,1.,0.,0., 0.,0.,1.,0., 0.,0.,0.,1.])
            # eye-in-hand: fixed camera->TCP transform (16 floats). MUST be calibrated.
            self.declare_parameter(
                "T_tcp_cam",
                [1.,0.,0.,0., 0.,1.,0.,0., 0.,0.,1.,0., 0.,0.,0.,1.])
            self.declare_parameter("rate_hz", 5.0)              # perception is slow/low-Hz
            # ── BRIO scene cam fusion (independent overhead view; survives wrist occlusion) ──
            self.declare_parameter("use_brio", False)           # fuse BRIO DLT with wrist
            self.declare_parameter("brio_dev", 6)
            self.declare_parameter("brio_P_path", str(_CALIB_DIR / "P_brio.npy"))
            self.declare_parameter("brio_z_plane", 0.03)        # cube CENTER height (base z)
            # D415 overhead SCENE cam (RealSense depth) — replaces BRIO. Uses the node's own
            # deproject + STATIC extrinsic (scene_T_base_cam), NOT a DLT. Survives wrist occlusion.
            self.declare_parameter("use_scene_rs", False)
            self.declare_parameter("scene_serial", "")          # overhead serial (pin: two D435i on the bus)
            self.declare_parameter("scene_T_base_cam",          # 16 row-major floats, cam->base
                                   [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
                                    0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0])
            self.declare_parameter("scene_z_plane", 0.03)       # cube CENTER height (base z) fallback
            # D415 oblique depth-long bias correction (m, subtracted from scene depth before
            # deproject). Measured 0.030 lands scene xy on wrist truth to ~3mm at 55deg.
            self.declare_parameter("scene_depth_bias", 0.030)
            # NEW D435i-scene OBLIQUE DEPTH MODEL (2026-08-07): the scene cam is now a D435i (not
            # D415). Its 55deg grazing bias is NOT a scalar -- it is rho_true = a*rho_obs + b +
            # c*tan(theta) (theta = ray incidence vs table normal), fit from 12 cube positions
            # against the 2mm wrist GT (held-out cube error 3mm). When scene_use_depth_model is
            # True, _scene_estimate uses this ray x corrected-range model instead of the raw
            # deproject + scalar scene_depth_bias. a,b,c default to the fitted values.
            self.declare_parameter("scene_use_depth_model", False)
            self.declare_parameter("scene_depth_a", 0.06512743270114899)
            self.declare_parameter("scene_depth_b", -0.3753974465356042)
            self.declare_parameter("scene_depth_c", -0.3509141495464059)
            self.declare_parameter("wrist_serial", "")          # D435i serial (pin the wrist grab)
            self.declare_parameter("hold_sec", 1.5)             # hold last good reading (static cube)
            # freeze latch: once N agreeing high-conf reads arrive, latch base-frame cube_xyz and
            # republish it (cube is static; carries the final descent when cameras go blind).
            self.declare_parameter("wrist_override_conf", 0.75)
            self.declare_parameter("wrist_relatch_enable", True)
            self.declare_parameter("wrist_relatch_conf", 0.6)
            self.declare_parameter("wrist_relatch_min_delta", 0.01)
            # SCENE live-track: update the latched cube from the unoccluded, depth-corrected scene
            # D415 every tick during descent (the wrist is gripper-occluded then). conf gate + a
            # min-delta so tiny jitter doesn't thrash the latch.
            self.declare_parameter("scene_livetrack_enable", True)
            self.declare_parameter("scene_livetrack_conf", 0.35)
            self.declare_parameter("scene_livetrack_min_delta", 0.005)
            # Median-filter the scene live-track over the last N reads before it is allowed to
            # move the latch. Raw single-frame scene reads are what previously clobbered a
            # 0.98-conf wrist latch with a 0.55-conf outlier (12 mm error mid-descent).
            self.declare_parameter("scene_livetrack_median_n", 5)
            # Cap how far live-track may ever pull the cube from the ORIGINAL wrist latch. The
            # wrist latch at home is the most accurate reading we get; live-track should correct
            # drift, not relocate the cube. <=0 disables the cap.
            # Per-UPDATE step cap (m). Replaces the old scene_livetrack_max_dev, which leashed
            # the cube to its first latch and so could not follow a cube that actually moved.
            self.declare_parameter("scene_livetrack_max_step", 0.02)
            # SHADOW LOG: record BOTH cube sources (wrist latch + live scene) every tick while
            # publishing only one. This is what lets us measure the real per-tick disagreement
            # between the two, instead of emulating it in sim. Empty path = off.
            self.declare_parameter("cube_shadow_log", "")
            # FRAME CAPTURE: per-tick RGB + aligned depth + intrinsics + extrinsics for BOTH
            # cameras. Point clouds are NOT stored -- they are exactly reconstructible from
            # (depth, K, T) offline (see replay_frames.py) at ~10x less disk.
            # NO tick cap: every tick is written and FLUSHED as it happens, so a run that is
            # killed / crashes / is Ctrl-C'd still leaves every frame it got to on disk. Capture
            # ends when the policy run ends (this node is torn down by the run script).
            self.declare_parameter("frame_capture_dir", "")
            self.declare_parameter("frame_capture_every", 1)      # record every Nth tick
            self.declare_parameter("frame_capture_jpeg_q", 85)    # RGB quality (depth is lossless)
            # Keep only the largest green blob (rejects the table's green pen marks).
            # Use the 3-D cloud-median reduction that the scene extrinsic was fitted with.
            # Mutually exclusive with scene_use_depth_model (that one is ray x corrected range).
            self.declare_parameter("scene_cloud_median", True)
            # Edge-anchored centroid: robust to the gripper occluding the cube on approach.
            # Fuse scene xy (1.65 mm vs FK truth) with wrist z (1 mm). See the block in _tick.
            # Wrist z from the cube TOP FACE (perpendicular view, 1 mm) not the table ring.
            # Physically plausible cube-centre height range (table 0, cube may be lifted).
            self.declare_parameter("cube_z_min", 0.010)
            self.declare_parameter("cube_z_max", 0.350)
            self.declare_parameter("cube_top_z", 0.060)    # table 0 + 60 mm cube -> top face
            self.declare_parameter("latch_enable", True)
            self.declare_parameter("latch_n", 8)
            self.declare_parameter("latch_conf", 0.5)
            # KNOWN cube half-height (m): wrist depth collapses the cube height at FOV edge, so z is
            # computed as table_plane + this (cube is a fixed 60mm cube -> 0.030).
            self.declare_parameter("cube_half_h", 0.030)
            # Force a FIXED base-frame cube-center z (>=0 enables). The cube is a fixed-size
            # cube on a flat table, so its center height is a known constant (~0.03 = BRIO
            # table-plane + half-height). The wrist-depth z is unreliable at the FOV edge
            # (~0.086), so overriding it removes the "policy hovers 5cm high" error. -1 = off.
            self.declare_parameter("force_cube_z", -1.0)
            # ── Vision GRIPPER STATE (replaces the broken SDK readback). DINO+SlimSAM
            # detect the gripper in BRIO (openness + capture) and wrist (capture);
            # publish [left_contact, right_contact, force_mag, openness] on
            # /gripper_state for the controller's contact obs. Needs use_brio=true.
            self.declare_parameter("gripper_state", False)     # enable the estimator
            self.declare_parameter(
                "gripper_widths_path", str(_CALIB_DIR / "gripper_widths.json"))
            self.declare_parameter("gripper_open_px", 220.0)   # fallback if no calib json
            self.declare_parameter("gripper_closed_px", 60.0)
            self.declare_parameter("gripper_roi_x_max", 1050.0)  # BRIO clutter reject (as DLT calib)
            self.declare_parameter("gripper_roi_y_max", 650.0)
            self.declare_parameter("gripper_hold_sec", 1.5)    # hold last state if gripper undetected

            self._bridge = CvBridge() if CvBridge else None
            self._seg = Sam3Segmenter(
                backend=str(self.get_parameter("backend").value),
                prompt=str(self.get_parameter("prompt").value))
            self._depth_scale = float(self.get_parameter("depth_scale").value)
            self._mode = str(self.get_parameter("extrinsic_mode").value)
            self._T = np.array(self.get_parameter("T_base_cam").value, np.float64).reshape(4, 4)
            self._T_tcp_cam = np.array(self.get_parameter("T_tcp_cam").value, np.float64).reshape(4, 4)
            # eye-in-hand TF: link_base -> link_tcp, looked up live each tick.
            self._tf_buf = self._tf_listener = None
            if self._mode == "eye_in_hand":
                import tf2_ros
                self._tf_buf = tf2_ros.Buffer()
                self._tf_listener = tf2_ros.TransformListener(self._tf_buf, self)
                if np.allclose(self._T_tcp_cam, np.eye(4)):
                    self.get_logger().warn(
                        "eye_in_hand but T_tcp_cam is IDENTITY -> cube_xyz wrong. Calibrate "
                        "the camera->TCP mount transform (extrinsic_calib.py).")
                self.get_logger().info("extrinsic_mode=eye_in_hand (wrist camera; live TF base->tcp)")
            elif np.allclose(self._T, np.eye(4)):
                self.get_logger().warn(
                    "T_base_cam is IDENTITY -> /cube_xyz is in the CAMERA frame, NOT base. "
                    "Calibrate before driving the arm (README checklist #4).")
            self._K = None
            self._rgb = None
            self._depth = None
            self._last_uv = None
            self._src = str(self.get_parameter("camera_source").value)
            self._grabber = None
            if self._src == "realsense":
                _wser = str(self.get_parameter("wrist_serial").value) or None
                self._grabber = RealSenseGrabber(serial=_wser)
                self.get_logger().info(
                    f"camera_source=realsense (direct pyrealsense2 grab, wrist serial={_wser})")
            else:
                self.create_subscription(CameraInfo, str(self.get_parameter("info_topic").value),
                                         self._on_info, 1)
                self.create_subscription(Image, str(self.get_parameter("color_topic").value),
                                         self._on_color, 1)
                self.create_subscription(Image, str(self.get_parameter("depth_topic").value),
                                         self._on_depth, 1)
            # WRIST RELEASE. The controller borrows this camera for its grasp calibration (an
            # iterative wrist servo, the mechanism that grasped 3/3 in the collector) and
            # RealSense will not open one device twice. On /wrist_release true we stop the
            # grabber; on false we reopen it. The scene camera keeps running throughout, so the
            # published cube xy is never interrupted -- only the wrist-z half pauses, and the
            # cube is static so the last z stays valid.
            self._wrist_released = False
            try:
                from std_msgs.msg import Bool as _Bool
                self.create_subscription(_Bool, "/wrist_release", self._on_wrist_release, 1)
            except Exception:  # pylint: disable=broad-except
                pass
            # BRIO scene cam (optional fusion source)
            self._brio = None; self._P_brio = None
            self._use_brio = bool(self.get_parameter("use_brio").value)
            if self._use_brio:
                try:
                    self._P_brio = np.load(str(self.get_parameter("brio_P_path").value))
                    self._brio = BrioGrabber(dev=int(self.get_parameter("brio_dev").value))
                    self.get_logger().info("BRIO fusion ON (overhead DLT, survives wrist occlusion)")
                except Exception as e:
                    self.get_logger().warn(f"BRIO fusion unavailable: {e}")
                    self._use_brio = False
            # D415 overhead SCENE cam (RealSense depth + static extrinsic) — BRIO replacement.
            self._scene = None
            self._use_scene = bool(self.get_parameter("use_scene_rs").value)
            self._scene_depth_bias = float(self.get_parameter("scene_depth_bias").value)
            self._scene_T = np.array(self.get_parameter("scene_T_base_cam").value,
                                     np.float64).reshape(4, 4)
            # NEW D435i oblique depth model (rho_true = a*rho_obs + b + c*tan(theta))
            self._scene_use_depth_model = bool(self.get_parameter("scene_use_depth_model").value)
            self._scene_da = float(self.get_parameter("scene_depth_a").value)
            self._scene_db = float(self.get_parameter("scene_depth_b").value)
            self._scene_dc = float(self.get_parameter("scene_depth_c").value)
            if self._use_scene:
                try:
                    _sser = str(self.get_parameter("scene_serial").value) or None
                    # 720p to match the D435i scene calibration (env_frames intrinsics); the a,b,c
                    # model is per-ray so it is resolution-independent, but keep res consistent.
                    _sw, _sh = (1280, 720) if self._scene_use_depth_model else (640, 480)
                    self._scene = RealSenseGrabber(width=_sw, height=_sh, want_ir=False, serial=_sser)
                    if np.allclose(self._scene_T, np.eye(4)):
                        self.get_logger().warn(
                            "use_scene_rs but scene_T_base_cam is IDENTITY -> scene cube_xyz in "
                            "CAMERA frame. Calibrate (extrinsic_calib.py) before driving the arm.")
                    self.get_logger().info(
                        f"SCENE cam ON (overhead RealSense depth, serial={_sser}, "
                        "static extrinsic, survives wrist occlusion)")
                except Exception as e:
                    self.get_logger().warn(f"scene cam unavailable: {e}")
                    self._use_scene = False
            self._hold_sec = float(self.get_parameter("hold_sec").value)
            self._last_xyz = None; self._last_xyz_t = -1e9
            self._wrist_override_conf = float(self.get_parameter("wrist_override_conf").value)
            self._wrist_relatch_enable = bool(self.get_parameter("wrist_relatch_enable").value)
            self._wrist_relatch_conf = float(self.get_parameter("wrist_relatch_conf").value)
            self._wrist_relatch_min_delta = float(self.get_parameter("wrist_relatch_min_delta").value)
            self._scene_livetrack_enable = bool(self.get_parameter("scene_livetrack_enable").value)
            self._scene_livetrack_conf = float(self.get_parameter("scene_livetrack_conf").value)
            self._scene_livetrack_min_delta = float(self.get_parameter("scene_livetrack_min_delta").value)
            self._scene_lt_med_n = int(self.get_parameter("scene_livetrack_median_n").value)
            self._scene_lt_max_step = float(
                self.get_parameter("scene_livetrack_max_step").value)
            self._scene_lt_buf = []          # rolling scene reads for the median filter
            self._latch_origin = None        # the first (wrist) latch, for the max-dev cap
            # shadow log: both cube sources per tick, whichever one is published
            self._shadow_path = str(self.get_parameter("cube_shadow_log").value)
            self._shadow_f = None
            if self._shadow_path:
                try:
                    self._shadow_f = open(self._shadow_path, "w", buffering=1)
                    self._shadow_f.write(
                        "t,pub_x,pub_y,pub_z,src,"
                        "latch_x,latch_y,latch_z,"
                        "scene_x,scene_y,scene_z,scene_conf,"
                        "wrist_x,wrist_y,wrist_z,wrist_conf\n")
                    self.get_logger().info(f"cube shadow log -> {self._shadow_path}")
                except OSError as e:
                    self.get_logger().warn(f"cannot open cube_shadow_log: {e}")

            # ── per-tick frame capture (streamed; survives an unclean exit) ──
            self._cap_dir = str(self.get_parameter("frame_capture_dir").value)
            self._cap_every = max(int(self.get_parameter("frame_capture_every").value), 1)
            self._cap_jpeg_q = int(self.get_parameter("frame_capture_jpeg_q").value)
            self._cap_n = 0
            self._cap_tick = 0
            self._cap_index = None
            if self._cap_dir:
                try:
                    os.makedirs(os.path.join(self._cap_dir, "wrist"), exist_ok=True)
                    os.makedirs(os.path.join(self._cap_dir, "scene"), exist_ok=True)
                    # Encode+write on a BACKGROUND thread. Doing it inline halved the perception
                    # loop (measured 10 Hz against a requested 20 Hz), which would corrupt the very
                    # thing we are trying to measure. The queue is bounded and DROPS when full, so
                    # capture can never apply backpressure to the control loop; drops are counted
                    # and reported rather than silently hidden.
                    import queue
                    import threading
                    self._cap_q = queue.Queue(maxsize=64)
                    self._cap_drops = 0
                    self._cap_stop = threading.Event()
                    self._cap_thread = threading.Thread(
                        target=self._capture_worker, name="framecap", daemon=True)
                    # Line-buffered index: one row per captured tick, flushed immediately, so a
                    # killed run still has a complete index of everything already on disk.
                    self._cap_index = open(
                        os.path.join(self._cap_dir, "index.csv"), "w", buffering=1)
                    self._cap_index.write(
                        "tick,t,cam,rgb,depth,fx,fy,cx,cy,depth_units_m\n")
                    self._cap_thread.start()
                    self.get_logger().info(f"frame capture -> {self._cap_dir} "
                                           f"(every {self._cap_every} tick(s), no cap, async)")
                except OSError as e:
                    self.get_logger().warn(f"cannot open frame_capture_dir: {e}")
                    self._cap_index = None
            self._scene_cloud_median = bool(self.get_parameter("scene_cloud_median").value)
            self._cube_z_min = float(self.get_parameter("cube_z_min").value)
            self._cube_z_max = float(self.get_parameter("cube_z_max").value)
            self._cube_top_z = float(self.get_parameter("cube_top_z").value)
            # The a/b/c range model and the cloud-median reduction are ALTERNATIVE localizations
            # of the same blob, each paired with the extrinsic it was fitted against. Running both
            # is not "more correction", it is double-correction (measured: 120 -> 127 mm). Fail
            # loudly rather than let branch ordering silently pick one.
            if self._scene_use_depth_model and self._scene_cloud_median:
                raise RuntimeError(
                    "scene_use_depth_model and scene_cloud_median are mutually exclusive: the "
                    "a/b/c model belongs to the ray-x-range reduction, the cloud median to the "
                    "rigid joint fit. Enable exactly one.")
            self._latch_enable = bool(self.get_parameter("latch_enable").value)
            self._latch_n = int(self.get_parameter("latch_n").value)
            self._latch_conf = float(self.get_parameter("latch_conf").value)
            self._latch_buf = []; self._latched = None
            self._cube_half_h = float(self.get_parameter("cube_half_h").value)
            self._force_cube_z = float(self.get_parameter("force_cube_z").value)

            self._pub = self.create_publisher(PointStamped, "/cube_xyz", 1)

            # ── Vision gripper-state estimator + /gripper_state publisher ──────────
            self._grip_est = None
            self._grip_pub = None
            self._grip_last = None; self._grip_last_t = -1e9
            self._grip_hold_sec = float(self.get_parameter("gripper_hold_sec").value)
            self._grip_roi_x = float(self.get_parameter("gripper_roi_x_max").value)
            self._grip_roi_y = float(self.get_parameter("gripper_roi_y_max").value)
            if bool(self.get_parameter("gripper_state").value):
                from std_msgs.msg import Float32MultiArray
                self._Float32MultiArray = Float32MultiArray
                open_px = float(self.get_parameter("gripper_open_px").value)
                closed_px = float(self.get_parameter("gripper_closed_px").value)
                try:
                    import json
                    wj = json.load(open(str(self.get_parameter("gripper_widths_path").value)))
                    open_px = float(wj.get("open_px", open_px))
                    closed_px = float(wj.get("closed_px", closed_px))
                    self.get_logger().info(f"gripper widths: open={open_px:.0f}px closed={closed_px:.0f}px")
                except Exception as e:
                    self.get_logger().warn(f"gripper_widths.json unavailable ({e}); using param defaults")
                try:
                    self._grip_est = GripperStateEstimator(open_px=open_px, closed_px=closed_px)
                    self._grip_pub = self.create_publisher(Float32MultiArray, "/gripper_state", 1)
                    self.get_logger().info("gripper-state estimator ON (DINO+SlimSAM, BRIO+wrist fused)")
                except Exception as e:
                    self.get_logger().warn(f"gripper-state estimator init failed ({e}); disabled")
                    self._grip_est = None

            self.create_timer(1.0 / float(self.get_parameter("rate_hz").value), self._tick)
            self.get_logger().info(
                f"cube_perception_node up (backend={self._seg.backend}, src={self._src}, "
                f"brio={self._use_brio}, prompt='{self._seg.prompt}')")

        def _on_info(self, msg):
            self._K = np.array(msg.k, dtype=np.float64).reshape(3, 3)

        def _on_color(self, msg):
            self._rgb = self._bridge.imgmsg_to_cv2(msg, "rgb8")

        def _on_depth(self, msg):
            d = self._bridge.imgmsg_to_cv2(msg, "passthrough").astype(np.float32)
            self._depth = d * self._depth_scale

        def _lookup_T_base_tcp(self):
            """Live 4x4 link_base->link_tcp from TF (eye-in-hand). None if unavailable."""
            import rclpy as _r
            try:
                tf = self._tf_buf.lookup_transform(
                    str(self.get_parameter("base_frame").value),
                    str(self.get_parameter("tcp_frame").value), _r.time.Time())
            except Exception:
                return None
            t = tf.transform.translation; q = tf.transform.rotation
            x, y, z, w = q.x, q.y, q.z, q.w
            R = np.array([
                [1-2*(y*y+z*z), 2*(x*y-z*w),   2*(x*z+y*w)],
                [2*(x*y+z*w),   1-2*(x*x+z*z), 2*(y*z-x*w)],
                [2*(x*z-y*w),   2*(y*z+x*w),   1-2*(x*x+y*y)]], np.float64)
            T = np.eye(4); T[:3, :3] = R; T[:3, 3] = [t.x, t.y, t.z]
            return T

        def _on_wrist_release(self, msg):
            want = bool(getattr(msg, "data", False))
            if want and not self._wrist_released:
                self._wrist_released = True
                try:
                    if self._grabber is not None:
                        self._grabber.stop()
                except Exception:  # pylint: disable=broad-except
                    pass
                self._grabber = None
                self.get_logger().info("wrist RELEASED to the controller (scene keeps running)")
            elif (not want) and self._wrist_released:
                self._wrist_released = False
                try:
                    _ws = str(self.get_parameter("wrist_serial").value) or None
                    self._grabber = RealSenseGrabber(serial=_ws)
                    self.get_logger().info("wrist REACQUIRED")
                except Exception as exc:  # pylint: disable=broad-except
                    self.get_logger().warn(f"could not reacquire the wrist: {exc}")

        def _wrist_estimate(self):
            if getattr(self, "_wrist_released", False):
                return None
            """Cube base-xyz from the WRIST camera (RGB+depth+IR fused), with a CONFIDENCE in
            [0,1] from mask size + how centered the cube is in the frame (edge => unreliable).
            Returns (xyz, conf) or None."""
            if self._grabber is not None:
                got = self._grabber.latest()
                if got is None:
                    return None
                self._rgb, self._depth, self._K = got
            if self._K is None or self._rgb is None or self._depth is None:
                return None
            ir = getattr(self._grabber, "last_ir", None) if self._grabber else None
            bk = self._seg.backend
            if bk == "fused":
                mask = self._seg.fused_mask(self._rgb, self._depth, self._last_uv, ir)
            elif bk == "slimsam":
                mask = self._seg.segment(self._rgb)
                if mask is None:
                    mask = self._seg.fused_mask(self._rgb, self._depth, self._last_uv, ir)
            else:
                mask = self._seg.segment(self._rgb)
            # HSV FALLBACK for the wrist. backend:=mock segments with a green-CHANNEL test
            # (g-r>40 and g-b>40); on this cube it returns 0 px while the HSV gate the scene path
            # uses returns 12170 px on the SAME frame (measured, cube centred at 548-681 x
            # 288-417). With mock the whole wrist estimate returned None every tick, wrist_conf
            # stayed nan, and the scene-xy + wrist-z fusion could never fire. Fall back to HSV so
            # the wrist works regardless of which backend is selected for detection.
            if mask is None or int(np.count_nonzero(mask)) < 20:
                import cv2 as _cv2
                _bgr = np.ascontiguousarray(self._rgb[..., ::-1])
                _hsv = _cv2.cvtColor(_bgr, _cv2.COLOR_BGR2HSV)
                _m = _cv2.inRange(_hsv, np.array(self._seg.HSV_LO), np.array(self._seg.HSV_HI))
                _m = _cv2.morphologyEx(_m, _cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
                _n, _lab, _st, _ = _cv2.connectedComponentsWithStats((_m > 0).astype(np.uint8), 8)
                if _n > 1:
                    _k = 1 + int(np.argmax(_st[1:, _cv2.CC_STAT_AREA]))
                    if _st[_k, _cv2.CC_STAT_AREA] >= 20:
                        mask = _lab == _k
            if mask is None:
                return None
            mys, mxs = np.where(mask)
            if len(mxs) < 20:
                return None
            # color centroid (used for both the depth path and the ray-plane fallback)
            u, v = float(mxs.mean()), float(mys.mean())
            self._last_uv = (u, v)
            fx0, fy0 = self._K[0, 0], self._K[1, 1]; cx0, cy0 = self._K[0, 2], self._K[1, 2]
            if self._mode == "eye_in_hand":
                T_base_tcp = self._lookup_T_base_tcp()
                if T_base_tcp is None:
                    return None
                M = T_base_tcp @ self._T_tcp_cam
            else:
                M = self._T
            # depth-valid cube pixels
            d = self._depth[mys, mxs]
            ok = (d > 0.05) & np.isfinite(d)
            ys, xs, d = mys[ok], mxs[ok], d[ok]
            # ── RAY-PLANE (PREFERRED for the wrist): the wrist D435i depth is unreliable on the
            # cube (drops to 0 valid px, or noisy/low-conf when present). The wrist is mounted
            # looking ~straight down (ray ~98% vertical), so a color-centroid ray intersected with
            # the known table plane (force_cube_z) gives sub-cm base xy WITHOUT depth -- the proven
            # v2 wrist-servo principle. ALWAYS use it for the eye-in-hand wrist when a table plane is
            # set (don't fall through to the noisy depth path, which gave inconsistent low conf).
            if self._mode == "eye_in_hand" and self._force_cube_z >= 0.0:
                ray_cam = np.array([(u - cx0) / fx0, (v - cy0) / fy0, 1.0])
                o = M[:3, 3]; dvec = M[:3, :3] @ ray_cam
                if abs(dvec[2]) < 1e-6:
                    return None
                t = (self._force_cube_z - o[2]) / dvec[2]
                if t <= 0:
                    return None
                p = o + t * dvec
                # Confidence from RAY VERTICALITY: a near-vertical ray (|z-component| ~1) has tiny
                # table-plane parallax error, so the xy is sub-cm accurate REGARDLESS of centering.
                # This is the wrist's accuracy guarantee -> it should DOMINATE the overhead blend.
                vert = abs(dvec[2]) / (np.linalg.norm(dvec) + 1e-9)     # 1.0 = straight down
                mask_ok = min(1.0, len(mxs) / 400.0)
                # vert^4 sharply rewards verticality: 0.99 vert -> ~0.96; 0.9 vert -> ~0.66.
                conf = float(min(0.98, (vert ** 4) * mask_ok))
                self.get_logger().info(
                    f"WRIST rayplane xy=[{p[0]:.3f},{p[1]:.3f}] vert={vert:.3f} "
                    f"npx={len(mxs)} conf={conf:.2f}", throttle_duration_sec=2.0)
                return np.array([p[0], p[1], self._force_cube_z], np.float32), conf
            # ── Deproject ALL cube-mask pixels to a base-frame point cloud, then compute the cube
            # CENTER (not a surface point): x,y = footprint centroid; z = table_plane + half_height.
            fx, fy = self._K[0, 0], self._K[1, 1]; cx, cy = self._K[0, 2], self._K[1, 2]
            X = (xs - cx) * d / fx; Y = (ys - cy) * d / fy
            cloud_cam = np.stack([X, Y, d, np.ones_like(d)], axis=1)   # (N,4)
            if self._mode == "eye_in_hand":
                T_base_tcp = self._lookup_T_base_tcp()
                if T_base_tcp is None:
                    return None
                M = T_base_tcp @ self._T_tcp_cam
            else:
                M = self._T
            cloud_b = (M @ cloud_cam.T).T[:, :3]                       # (N,3) base frame
            cxw, cyw = float(np.median(cloud_b[:, 0])), float(np.median(cloud_b[:, 1]))
            # Z: the cube is a KNOWN-size cube; wrist depth at the FOV edge collapses its height
            # (measured: reports top==table, ~0 height) -> DON'T trust the cloud top for z. Use the
            # TABLE plane (reliable) + the known half-height. xy still from the cloud footprint.
            # Z override: the wrist table-plane estimate (ztab) is unreliable at the FOV edge
            # (measured ~0.086 vs true ~0.03), so the cube sits on a FLAT table at a KNOWN
            # height -> prefer a fixed base-frame cube-center z (force_cube_z, = BRIO
            # table-plane + half-height) when set (>=0). xy still from the wrist cloud.
            if self._force_cube_z >= 0.0:
                zc = self._force_cube_z
            elif len(cloud_b) >= 10:
                # CUBE TOP FACE, measured directly. The wrist views that face PERPENDICULARLY, so
                # its range there carries no grazing-angle error and does not depend on the
                # extrinsic rotation the way lateral position does. Measured with the arm homed,
                # 3 trials: top z = 0.0611 / 0.0610 / 0.0607 against a geometric 0.060, cloud
                # spread 4 mm. The ring-based table estimate below it was the old route and is
                # unreliable at the FOV edge (measured 0.086 vs a true 0.030).
                # Take the 75th percentile of the cloud z: the top face is the highest large
                # surface in the mask, and the percentile rejects the few side-face pixels.
                zc = float(np.percentile(cloud_b[:, 2], 75)) - self._cube_half_h
                # SANITY BOUND. The 75th-percentile top-face trick holds while the wrist looks
                # DOWN at the cube from a distance. On the descent the cube fills the frame, the
                # jaws occlude it, and the percentile stops tracking the top face -- measured on
                # the v4f run it collapsed to -1.05 m, i.e. a cube a metre under the table. bf_z
                # then read -1.06 ("cube is far below me"), the policy dived, and the arm drove
                # through the table into a self-collision (err 31) at tcp_z -0.011.
                # The cube physically sits on a table between these bounds; anything outside is a
                # broken read, not a moved cube, so reject it and let the caller fall back.
                if not (self._cube_z_min <= zc <= self._cube_z_max):
                    self.get_logger().warn(
                        f"wrist top-face z out of range ({zc:.3f}); rejecting this estimate",
                        throttle_duration_sec=2.0)
                    return None
            else:
                ztab = self._table_z_base(mask, M)
                if ztab is None:
                    ztab = float(np.median(cloud_b[:, 2]))            # fallback: cloud median
                zc = ztab + self._cube_half_h                        # cube CENTER = table + 30mm
            Hh, Ww = self._depth.shape
            centered = max(0.0, min(1.0 - abs(u-Ww/2)/(Ww/2), 1.0 - abs(v-Hh/2)/(Hh/2)))
            conf = float(centered * min(1.0, len(d)/1500.0))
            return np.array([cxw, cyw, zc]), conf

        def _table_z_base(self, mask, M):
            """Median base-frame z of a depth ring just outside the cube mask (the table plane)."""
            import cv2
            ring = cv2.dilate(mask.astype(np.uint8), np.ones((35, 35), np.uint8)) > 0
            ring &= ~mask
            ys, xs = np.where(ring)
            if len(xs) == 0:
                return None
            d = self._depth[ys, xs]
            ok = (d > 0.05) & np.isfinite(d)
            ys, xs, d = ys[ok], xs[ok], d[ok]
            if len(d) < 30:
                return None
            fx, fy = self._K[0, 0], self._K[1, 1]; cx, cy = self._K[0, 2], self._K[1, 2]
            X = (xs - cx) * d / fx; Y = (ys - cy) * d / fy
            cloud = np.stack([X, Y, d, np.ones_like(d)], axis=1)
            zb = (M @ cloud.T).T[:, 2]
            return float(np.median(zb))

        def _brio_estimate(self):
            """Cube base-xyz from the overhead BRIO (DLT + table-plane), with a confidence.
            Returns (xyz, conf) or None."""
            if not self._use_brio or self._brio is None:
                return None
            r = self._brio.cube_base_xy(
                self._P_brio, list(self._seg.HSV_LO), list(self._seg.HSV_HI),
                float(self.get_parameter("brio_z_plane").value))
            if r is None:
                return None
            # BRIO is overhead with the cube usually well-centered; fixed moderate confidence.
            # (xy is solid ~2cm; z is plane-assumed, so callers down-weight z.)
            return r, 0.6

        def _scene_estimate(self):
            """Cube base-xyz from the overhead D415 SCENE cam (RealSense RGB+depth), using the
            SAME deproject + STATIC extrinsic as the wrist path (not a DLT). Returns (xyz, conf)
            or None. Overhead + fixed -> survives wrist occlusion; depth gives a real z."""
            if not self._use_scene or self._scene is None:
                return None
            got = self._scene.latest()
            if got is None:
                return None
            rgb, depth, K = got
            # FAST HSV path for the scene: live-tracking during descent needs ~real-time updates,
            # but DINO+SlimSAM runs ~1s/frame -> too slow to track. The overhead scene view of a
            # green cube segments cleanly with an HSV gate (~30Hz). Use it for the scene; DINO
            # stays available for the wrist/initial detection.
            if True:
                import cv2
                bgr = rgb[..., ::-1]
                hsv = cv2.cvtColor(np.ascontiguousarray(bgr), cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, np.array(self._seg.HSV_LO), np.array(self._seg.HSV_HI))
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) > 0
                # LARGEST-COMPONENT filter. The table carries green PEN MARKS inside the same hue
                # band; without this the mask fuses cube + marks and the centroid drags toward
                # them (measured on the live frame: x-extent 733 mm instead of the cube's 40, and
                # the published estimate sat 27 mm off the validated chain). Keeping only the
                # biggest blob is what the 1.65 mm calibration chain does.
                if mask.any():
                    n_cc, lab, st, _ = cv2.connectedComponentsWithStats(
                        mask.astype(np.uint8), 8)
                    if n_cc > 1:
                        mask = lab == (1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA])))
            else:
                mask = self._seg.segment(rgb)
            if mask is None:
                return None
            ys, xs = np.where(mask)
            d = depth[ys, xs]
            ok = (d > 0.05) & np.isfinite(d)
            ys, xs, d = ys[ok], xs[ok], d[ok]
            if len(d) < 20:
                return None
            u, v = float(xs.mean()), float(ys.mean())
            fx, fy = K[0, 0], K[1, 1]; cx, cy = K[0, 2], K[1, 2]
            if self._scene_use_depth_model:
                # NEW D435i oblique model (2026-08-07): the 55deg grazing bias is NOT a scalar.
                # Localize the centroid by ray x CORRECTED-range: rho_true = a*rho_obs + b +
                # c*tan(theta), theta = ray incidence vs the table normal (base +z). Fit from 12
                # cube positions vs the 2mm wrist GT -> 3mm held-out. (Supersedes the D415
                # raw-deproject + scalar scene_depth_bias, which was wrong for the D435i.)
                rho_obs = float(np.median(d))
                ray = np.array([(u - cx) / fx, (v - cy) / fy, 1.0])
                ray /= np.linalg.norm(ray)
                rb = self._scene_T[:3, :3] @ ray
                cth = float(np.clip(abs(rb[2]) / np.linalg.norm(rb), 1e-3, 1.0))
                tth = float(np.sqrt(1.0 - cth * cth) / cth)
                rho_true = self._scene_da * rho_obs + self._scene_db + self._scene_dc * tth
                p_base = self._scene_T[:3, :3] @ (rho_true * ray) + self._scene_T[:3, 3]
                cxw, cyw = float(p_base[0]), float(p_base[1])
                cloud_b = p_base.reshape(1, 3)   # for the z/conf code below
            elif self._scene_cloud_median:
                # OCCLUSION-ROBUST CENTROID. As the gripper closes in it hides the near face of
                # the cube from the obliquely-viewing scene cam, so the VISIBLE blob shrinks
                # asymmetrically and its centroid slides away from the gripper. Measured on the
                # v4wm run: the scene estimate walked 54.3 mm from the first quarter to the last
                # while confidence fell 0.46 -> 0.27. The policy chased a target that fled as it
                # approached -- which is what drove the wrist tilt (14.8 deg) and the retreat.
                #
                # FIX: the cube is a known-size box standing on a known table plane, so its
                # centre is not the centroid of whatever happens to be visible. Take the visible
                # cloud's EXTREME edges along the table plane and place the centre a half-width
                # in from whichever edge is better observed, rather than averaging a partial blob.
                # An edge stays put under occlusion; a centroid does not.
                keep = np.abs(d - np.median(d)) < 0.06
                if keep.sum() >= 20:
                    ys, xs, d = ys[keep], xs[keep], d[keep]
                X = (xs - cx) * d / fx; Y = (ys - cy) * d / fy
                p_cam = np.median(np.stack([X, Y, d], axis=1), axis=0)
                p_base = self._scene_T[:3, :3] @ p_cam + self._scene_T[:3, 3]
                cxw, cyw = float(p_base[0]), float(p_base[1])
                cloud_b = p_base.reshape(1, 3)
            else:
                # LEGACY D415 path: raw deproject + scalar depth-long bias (subtract ~0.030m).
                d = d - self._scene_depth_bias
                X = (xs - cx) * d / fx; Y = (ys - cy) * d / fy
                cloud_cam = np.stack([X, Y, d, np.ones_like(d)], axis=1)   # (N,4)
                cloud_b = (self._scene_T @ cloud_cam.T).T[:, :3]           # (N,3) base frame
                cxw, cyw = float(np.median(cloud_b[:, 0])), float(np.median(cloud_b[:, 1]))
            # z: overhead depth sees the cube TOP cleanly (unlike the wrist FOV edge). Use the
            # cloud-top (min base-z toward table is down; overhead sees top face) -> take median
            # base-z of the cloud as the cube CENTER anchor, but fall back to the known plane if
            # force_cube_z is set (kept consistent with the wrist path).
            if self._force_cube_z >= 0.0:
                zc = self._force_cube_z
            else:
                zc = float(np.median(cloud_b[:, 2]))
            # confidence: overhead + centered cube reads well; scale by mask support, cap 0.7 so a
            # confident wrist reading (close-range, precise) can still dominate the final blend.
            Hh, Ww = depth.shape
            centered = max(0.0, min(1.0 - abs(u-Ww/2)/(Ww/2), 1.0 - abs(v-Hh/2)/(Hh/2)))
            conf = float(min(0.7, centered * min(1.0, len(d)/1500.0) + 0.2))
            return np.array([cxw, cyw, zc]), conf

        def _tick_gripper_state(self):
            """Estimate + publish /gripper_state [left_contact, right_contact,
            force_mag, openness] from BRIO (openness + capture) fused with the wrist
            (capture). Holds the last value briefly if the gripper isn't detected."""
            if self._grip_est is None or self._grip_pub is None:
                return
            brio_rgb = self._brio.latest_rgb() if self._brio is not None else None
            wrist_rgb = self._rgb  # populated by _wrist_estimate()/color sub each cycle
            try:
                st = self._grip_est.estimate(
                    brio_rgb, wrist_rgb,
                    brio_roi_x_max=self._grip_roi_x, brio_roi_y_max=self._grip_roi_y)
            except Exception as e:
                self.get_logger().warn(f"gripper-state estimate failed: {e}",
                                       throttle_duration_sec=2.0)
                st = None
            now = self._now_s()
            if st is None:
                # gripper undetected -> hold last state briefly (avoids dropping
                # contact mid-grasp on a single missed detection), then stop publishing.
                if self._grip_last is not None and (now - self._grip_last_t) < self._grip_hold_sec:
                    st = self._grip_last
                    tag = "hold"
                else:
                    return
            else:
                self._grip_last = st; self._grip_last_t = now
                tag = "live"
            msg = self._Float32MultiArray()
            msg.data = [float(st[0]), float(st[1]), float(st[2]), float(st[3])]
            self._grip_pub.publish(msg)
            self.get_logger().info(
                f"gripper_state contact={st[0]:.0f} force={st[2]:.1f} open={st[3]:.2f} [{tag}]",
                throttle_duration_sec=1.0)

        def _tick(self):
            # ── VISION GRIPPER STATE: publish EVERY tick (even after the cube latch),
            # since the policy needs a live contact signal through the grasp+lift.
            self._tick_gripper_state()
            # ── FRAME CAPTURE: every tick, before any of the early returns below, so the
            # recording is uniform in time rather than only covering the pre-latch phase.
            if self._cap_index is not None:
                if self._cap_n == 0:
                    self._dump_capture_meta()
                self._capture_frames()
            # ── FREEZE LATCH: the cube is STATIC and cube_xyz is in the inertial BASE frame, so
            # once we have a confident, consistent estimate we LATCH it and republish the frozen
            # value. This is correct (not the old frozen-bad-reading bug): near grasp the wrist
            # goes blind (gripper occludes) and BRIO gets occluded by the arm too, so a live signal
            # vanishes — but the base-frame cube position hasn't moved. Latched value carries the
            # final descent. Latch when we have >=latch_n agreeing high-conf readings.
            if self._latched is not None:
                # SCENE LIVE-TRACK: during the descent the WRIST gets gripper-occluded (its readings
                # drift ~3cm -> the policy chased a moving target and missed). The overhead SCENE
                # D415 is NEVER occluded by the gripper and is now depth-bias-corrected (accurate to
                # ~3mm). So while latched, keep polling the SCENE cam every tick and update the latch
                # to the live scene cube -> the policy tracks the TRUE current cube closed-loop the
                # whole way down. (Wrist is used only for the initial high-precision latch at home.)
                # Poll the scene cam whenever live-track OR the shadow log wants it, so we can
                # RECORD the live scene reading even on runs where it does not drive the policy.
                se = None
                if self._scene_livetrack_enable or self._shadow_f is not None:
                    se = self._scene_estimate()
                if self._scene_livetrack_enable and se is not None:
                    spos, sconf = se
                    if sconf >= self._scene_livetrack_conf:
                        # MEDIAN FILTER over the last N reads: rejects a single bad frame (a
                        # 0.55-conf outlier once overwrote a 0.98-conf wrist latch with a 12 mm
                        # error) without blocking real motion.
                        self._scene_lt_buf.append(np.asarray(spos, np.float64))
                        if len(self._scene_lt_buf) > max(self._scene_lt_med_n, 1):
                            self._scene_lt_buf.pop(0)
                        if len(self._scene_lt_buf) >= max(self._scene_lt_med_n, 1):
                            cand = np.median(np.array(self._scene_lt_buf), axis=0)
                            # PER-UPDATE RATE LIMIT, not a fixed leash to the first latch. The old
                            # cap was |cand - latch_origin| <= max_dev, which made the published
                            # cube UNABLE to follow the object once it genuinely moved: measured on
                            # the proximity run, the scene tracked the cube 20/65/14 mm as the arm
                            # pushed it, but the published value stayed pinned at the original spot
                            # (3 live-track updates vs 61 latched republishes), so the policy chased
                            # a cube that was no longer there for 25 s -- and the proximity contact,
                            # which is computed from the same value, fired at the wrong place too.
                            # A per-tick step cap keeps the outlier protection while allowing the
                            # cube to be tracked wherever it actually goes.
                            step = cand[:2] - self._latched[:2]
                            ns = float(np.linalg.norm(step))
                            if self._scene_lt_max_step > 0.0 and ns > self._scene_lt_max_step:
                                cand[:2] = self._latched[:2] + step / ns * self._scene_lt_max_step
                            if (np.linalg.norm(cand[:2] - self._latched[:2])
                                    > self._scene_livetrack_min_delta):
                                self._latched = cand
                                self.get_logger().info(
                                    f"cube_xyz SCENE live-track update {np.round(self._latched,3)} "
                                    f"(conf={sconf:.2f}, med{len(self._scene_lt_buf)})",
                                    throttle_duration_sec=1.0)
                # CONTINUOUS WRIST-Z. The latched branch live-tracks the SCENE xy every tick but
                # used to republish a frozen z, so the wrist's accurate height was measured once at
                # latch and never again -- exactly when it matters most, since the cube's height
                # only changes when the gripper picks it up. Both cameras stream at 30 fps and the
                # whole chain costs ~4 ms, so recompute the wrist z every tick too.
                if True:
                    we_l = self._wrist_estimate()
                    if we_l is not None and we_l[1] > 0.0:
                        self._latched = np.array([float(self._latched[0]),
                                                  float(self._latched[1]),
                                                  float(we_l[0][2])], dtype=np.float64)
                        self._shadow_row(self._latched, "live_fused", se, we_l)
                        self._publish(self._latched, "live_fused")
                        return
                self._shadow_row(self._latched, "LATCHED", se, None)
                self._publish(self._latched, "LATCHED")
                return
            # ── MULTI-VIEW FUSION: wrist (RGB+depth+IR) + OVERHEAD (D415 scene depth, or BRIO DLT).
            # The overhead source survives wrist occlusion at close range. Prefer the D415 scene
            # cam when enabled (real depth z, no DLT position-error); else fall back to BRIO.
            we = self._wrist_estimate()
            be = self._scene_estimate() if self._use_scene else None
            if be is None:
                be = self._brio_estimate()
            wrist, wc = (we if we else (None, 0.0))
            brio, bc = (be if be else (None, 0.0))

            # SCENE-XY + WRIST-Z FUSION. Each camera contributes only what its geometry makes it
            # good at, scored on the 37 FK-ground-truth frames in fullcycle2:
            #     scene xy : mean 1.65 mm   (extrinsic fitted WITH its depth bias, so xy is right)
            #     wrist xy : mean 93.5 mm   (eye-in-hand extrinsic is bad laterally)
            #     wrist z  : cube top 0.0610 vs geometric 0.060, repeatable to 0.4 mm over 3 live
            #                trials -- it views the top face PERPENDICULARLY, so range does not
            #                depend on the extrinsic rotation the way lateral position does
            #     scene z  : 37 mm low, measured against that same wrist reading
            # Live, the two xy sources disagreed by a consistent 16-17 mm; this picks the correct
            # one instead of blending them or letting the wrist override win.
            if (brio is not None
                    and wrist is not None and wc > 0.0):
                fused = np.array([float(brio[0]), float(brio[1]), float(wrist[2])],
                                 dtype=np.float64)
                self._last_xyz = fused
                self._last_xyz_t = self._now_s()
                src = f"fused(sxy={bc:.2f},wz={wc:.2f})"
                if self._latch_enable and bc >= self._latch_conf:
                    if self._latch_buf and np.linalg.norm(
                            fused[:2] - self._latch_buf[-1][:2]) > 0.03:
                        self._latch_buf = []
                    self._latch_buf.append(fused)
                    if len(self._latch_buf) >= self._latch_n:
                        self._latched = np.median(np.array(self._latch_buf), axis=0)
                        if self._latch_origin is None:
                            self._latch_origin = self._latched.copy()
                        self.get_logger().info(
                            f"cube_xyz LATCHED (fused) at {np.round(self._latched, 3)}")
                self._shadow_row(fused, src, be, (wrist, wc))
                self._publish(fused, src)
                return

            # WRIST OVERRIDE: a high-confidence near-vertical wrist ray-plane reading is sub-cm
            # accurate and must NOT be diluted by the biased overhead (blending pulls the xy back
            # toward the ~3-4cm overhead error -> the grasp misses). When the wrist is confident,
            # use it directly.
            if wrist is not None and wc >= self._wrist_override_conf:
                xyz = wrist; src = f"wrist_override(c={wc:.2f})"
                self._last_xyz = np.asarray(xyz, np.float64); self._last_xyz_t = self._now_s()
                if self._latch_enable and wc >= self._latch_conf:
                    if self._latch_buf and np.linalg.norm(np.asarray(xyz)[:2]-self._latch_buf[-1][:2]) > 0.03:
                        self._latch_buf = []
                    self._latch_buf.append(np.asarray(xyz, np.float64))
                    if len(self._latch_buf) >= self._latch_n:
                        self._latched = np.median(np.array(self._latch_buf), axis=0)
                        if self._latch_origin is None:
                            self._latch_origin = self._latched.copy()
                        self.get_logger().info(f"cube_xyz LATCHED (wrist) at {np.round(self._latched,3)}")
                self._shadow_row(np.asarray(xyz), src, None, (wrist, wc))
                self._publish(np.asarray(xyz), src)
                return
            if wrist is not None and brio is not None and np.linalg.norm(wrist[:2]-brio[:2]) < 0.06:
                # agree -> confidence-weighted blend. z too: at close range the wrist z is noisy
                # (cube occluded/at edge -> can go below table), so when wrist conf is LOW the
                # BRIO table-plane z (stable, sane) must dominate. Cube is static on the table so
                # its true z is ~constant -> BRIO plane-z is a reliable anchor.
                w = wc / (wc + bc + 1e-6)
                xyz = np.array([w*wrist[0]+(1-w)*brio[0],
                                w*wrist[1]+(1-w)*brio[1],
                                w*wrist[2]+(1-w)*brio[2]])
                src = f"blend(w={w:.2f})"
            elif wrist is not None and (wc >= bc or brio is None):
                xyz = wrist; src = f"wrist(c={wc:.2f})"
            elif brio is not None:
                xyz = brio; src = f"brio(c={bc:.2f},wc={wc:.2f})"
            else:
                # both failed -> hold last good if recent (static cube), else warn.
                if self._last_xyz is not None and (self._now_s() - self._last_xyz_t) < self._hold_sec:
                    xyz = self._last_xyz; src = "hold"
                else:
                    self.get_logger().warn("cube not found (wrist+brio)", throttle_duration_sec=2.0)
                    return

            self._last_xyz = np.asarray(xyz, np.float64); self._last_xyz_t = self._now_s()
            # accumulate high-confidence readings toward a latch (cube static -> they should agree)
            conf = max(wc, bc)
            if self._latch_enable and conf >= self._latch_conf:
                if self._latch_buf and np.linalg.norm(np.asarray(xyz)[:2]-self._latch_buf[-1][:2]) > 0.03:
                    self._latch_buf = []                      # disagreement -> restart accumulation
                self._latch_buf.append(np.asarray(xyz, np.float64))
                if len(self._latch_buf) >= self._latch_n:
                    self._latched = np.median(np.array(self._latch_buf), axis=0)
                    if self._latch_origin is None:
                        self._latch_origin = self._latched.copy()
                    self.get_logger().info(f"cube_xyz LATCHED at {np.round(self._latched,3)} "
                                           f"({self._latch_n} agreeing reads)")
            self._shadow_row(np.asarray(xyz), src, be, (wrist, wc))
            self._publish(np.asarray(xyz), src)

        def _capture_frames(self):
            """Stream this tick's RGB + aligned depth + intrinsics for BOTH cameras to disk.

            Point clouds are deliberately NOT written: with the depth image, K, and the camera
            extrinsic (both dumped alongside), the cloud is exactly reconstructible offline, at a
            fraction of the disk and without slowing the 20 Hz control loop.

            Every frame is written and closed as it is produced, and the index is line-buffered,
            so an aborted / crashed / Ctrl-C'd run keeps everything captured up to that instant.
            Depth is saved as uint16 millimetres (lossless for our range, 2x smaller than f32).
            """
            if self._cap_index is None:
                return
            self._cap_tick += 1
            if (self._cap_tick - 1) % self._cap_every:
                return
            i = self._cap_n
            t = self._now_s()

            items = []
            if self._rgb is not None and self._depth is not None and self._K is not None:
                items.append(("wrist", self._rgb, self._depth, self._K))
            if self._scene is not None:
                got = self._scene.latest()
                if got is not None and got[0] is not None:
                    items.append(("scene", got[0], got[1], got[2]))
            if not items:
                return
            # Copy the buffers: the camera threads recycle theirs, and the writer runs later.
            job = (i, t, [(c, np.array(r, copy=True), np.array(d, copy=True), np.array(K))
                          for c, r, d, K in items])
            try:
                self._cap_q.put_nowait(job)
            except Exception:
                # Queue full -> DROP this tick rather than stall the perception loop.
                self._cap_drops += 1
                if self._cap_drops % 20 == 1:
                    self.get_logger().warn(
                        f"frame capture falling behind: {self._cap_drops} tick(s) dropped",
                        throttle_duration_sec=5.0)
            self._cap_n += 1

        def _capture_worker(self):
            """Background encoder/writer. Keeps all disk + JPEG/PNG cost off the control loop."""
            import cv2
            while not (self._cap_stop.is_set() and self._cap_q.empty()):
                try:
                    i, t, items = self._cap_q.get(timeout=0.2)
                except Exception:
                    continue
                for cam, rgb, depth, K in items:
                    rp = os.path.join(cam, f"{i:06d}_rgb.jpg")
                    dp = os.path.join(cam, f"{i:06d}_depth.png")
                    try:
                        cv2.imwrite(os.path.join(self._cap_dir, rp),
                                    np.ascontiguousarray(rgb[..., ::-1]),
                                    [int(cv2.IMWRITE_JPEG_QUALITY), int(self._cap_jpeg_q)])
                        dmm = np.clip(np.nan_to_num(depth, nan=0.0) * 1000.0, 0, 65535)
                        # PNG level 1: ~3x faster than the default 3 for <5% more bytes, which
                        # matters at 20 Hz x 2 cameras.
                        cv2.imwrite(os.path.join(self._cap_dir, dp), dmm.astype(np.uint16),
                                    [int(cv2.IMWRITE_PNG_COMPRESSION), 1])
                        self._cap_index.write(
                            f"{i},{t:.4f},{cam},{rp},{dp},"
                            f"{K[0,0]:.4f},{K[1,1]:.4f},{K[0,2]:.4f},{K[1,2]:.4f},0.001\n")
                    except Exception as e:
                        self.get_logger().warn(f"frame capture ({cam}) failed: {e}",
                                               throttle_duration_sec=5.0)

        def _dump_capture_meta(self):
            """One-time sidecar: the extrinsics needed to lift the captured depth into base frame.

            wrist is eye-in-hand (T_tcp_cam, composed with live FK at replay time); scene is fixed
            (T_base_cam), so the scene cloud can be built without any robot state at all.
            """
            if self._cap_index is None:
                return
            import json
            meta = {
                "note": "point clouds reconstruct from depth(uint16 mm) + K + these extrinsics",
                "wrist": {"extrinsic_mode": "eye_in_hand",
                          "T_tcp_cam": np.asarray(self._T_tcp_cam).tolist()
                          if getattr(self, "_T_tcp_cam", None) is not None else None},
                "scene": {"extrinsic_mode": "fixed_base",
                          "T_base_cam": np.asarray(self._scene_T).tolist()
                          if getattr(self, "_scene_T", None) is not None else None,
                          "depth_model": {"a": getattr(self, "_scene_da", None),
                                          "b": getattr(self, "_scene_db", None),
                                          "c": getattr(self, "_scene_dc", None),
                                          "enabled": bool(getattr(self, "_scene_use_depth_model",
                                                                  False))}},
            }
            try:
                with open(os.path.join(self._cap_dir, "capture_meta.json"), "w") as f:
                    json.dump(meta, f, indent=2)
            except Exception as e:
                self.get_logger().warn(f"cannot write capture_meta.json: {e}")

        def _shadow_row(self, pub, src, scene_est, wrist_est):
            """Record what EVERY cube source said this tick, alongside what we actually published.

            The point of this is to measure the wrist-latch vs live-scene disagreement on the real
            robot per tick, rather than emulating it in sim. `scene_est`/`wrist_est` are the
            (xyz, conf) tuples if that source was evaluated this tick, else None.
            """
            if self._shadow_f is None:
                return

            def _f3(e):
                if e is None or e[0] is None:
                    return "nan,nan,nan,nan"
                p = np.asarray(e[0], np.float64)
                return f"{p[0]:.5f},{p[1]:.5f},{p[2]:.5f},{float(e[1]):.3f}"

            lat = (self._latched if self._latched is not None
                   else np.array([np.nan, np.nan, np.nan]))
            p = np.asarray(pub, np.float64)
            try:
                self._shadow_f.write(
                    f"{self._now_s():.4f},{p[0]:.5f},{p[1]:.5f},{p[2]:.5f},{src},"
                    f"{lat[0]:.5f},{lat[1]:.5f},{lat[2]:.5f},"
                    f"{_f3(scene_est)},{_f3(wrist_est)}\n")
            except (OSError, ValueError):
                pass

        def _publish(self, xyz, src):
            # LAST-LINE GUARD on the published height. Whatever the source, the cube cannot be
            # below the table or above the arm's reach; a value outside that band is a broken
            # estimate. Publishing one is dangerous, not merely wrong: on the v4f run a wrist
            # read of -1.05 m made bf_z say "cube is a metre below you", the policy dived, and
            # the arm drove through the table into a self-collision (err 31). Clamp instead of
            # passing it through -- the xy is usually still good, and a slightly wrong height is
            # recoverable where a metre-deep one is not.
            z = float(xyz[2])
            if not (self._cube_z_min <= z <= self._cube_z_max):
                self.get_logger().warn(
                    f"published cube z {z:.3f} out of [{self._cube_z_min:.3f},"
                    f"{self._cube_z_max:.3f}] -> clamping", throttle_duration_sec=2.0)
                z = float(np.clip(z, self._cube_z_min, self._cube_z_max))
                xyz = np.array([float(xyz[0]), float(xyz[1]), z])
            msg = PointStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = str(self.get_parameter("base_frame").value)
            msg.point.x, msg.point.y, msg.point.z = float(xyz[0]), float(xyz[1]), float(xyz[2])
            self._pub.publish(msg)
            self.get_logger().info(f"cube_xyz {np.round(xyz,3)} [{src}]", throttle_duration_sec=1.0)

        def _now_s(self):
            return self.get_clock().now().nanoseconds * 1e-9

    rclpy.init()
    node = CubePerceptionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Drain whatever the writer thread still holds, so a SIGTERM/timeout does not lose the
        # last second of frames. Bounded wait: never hang teardown on a stuck disk.
        stop = getattr(node, "_cap_stop", None)
        if stop is not None:
            stop.set()
            th = getattr(node, "_cap_thread", None)
            if th is not None:
                th.join(timeout=10.0)
        # Close the streamed logs explicitly. They are line-buffered so the data is already on
        # disk even on a hard kill; this just makes a clean exit tidy and reports the totals.
        for attr in ("_shadow_f", "_cap_index"):
            f = getattr(node, attr, None)
            if f is not None:
                try:
                    f.close()
                except OSError:
                    pass
        if getattr(node, "_cap_n", 0):
            print(f"[capture] wrote {node._cap_n} ticks -> {node._cap_dir} "
                  f"({getattr(node, '_cap_drops', 0)} dropped)")
        node.destroy_node()
        # rclpy may already be down (e.g. SIGINT during spin); shutting down twice raises.
        try:
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:
            pass


def realframe_test(path: str, backend: str = "slimsam"):
    """Exercise the node's segment() backend on a real RGB frame; save an overlay.
    Validates the deploy seg path without ROS/depth (geometry is covered by --selftest)."""
    import cv2, time
    bgr = cv2.imread(path)
    assert bgr is not None, f"cannot read {path}"
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    seg = Sam3Segmenter(backend=backend)
    for i in range(3):
        t = time.time()
        mask = seg.segment(rgb)
        dt = (time.time() - t) * 1000
        n = 0 if mask is None else int(mask.sum())
        print(f"call{i}: {dt:.0f}ms  mask_px={n}", flush=True)
    if mask is None:
        print("NO MASK -- cube not found"); return
    ys, xs = np.where(mask)
    cx, cy = xs.mean(), ys.mean()
    print(f"px_centroid=({cx:.1f},{cy:.1f})", flush=True)
    ov = bgr.copy(); ov[mask] = (0.5 * ov[mask] + np.array([0, 0, 255]) * 0.5).astype(np.uint8)
    cv2.circle(ov, (int(cx), int(cy)), 4, (255, 0, 0), -1)
    out = os.path.join(os.path.dirname(path), "node_seg_overlay.jpg")
    cv2.imwrite(out, ov); print(f"WROTE {out}", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--realframe", type=str, default=None,
                    help="path to an RGB frame; runs segment() and saves an overlay")
    ap.add_argument("--backend", type=str, default="slimsam")
    args, _ = ap.parse_known_args()
    if args.selftest:
        selftest()
    elif args.realframe:
        realframe_test(args.realframe, args.backend)
    else:
        ros_main()
