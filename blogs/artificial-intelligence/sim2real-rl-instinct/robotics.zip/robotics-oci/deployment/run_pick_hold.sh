#!/usr/bin/env bash
#
# Run one pick-and-hold episode on a real xArm6.
#
# The ordering here is not incidental -- it is the whole point of the script:
#
#   1. home the arm and open the gripper, BEFORE perception starts. The hold
#      target is the cube position latched at the start of the episode, so the
#      latch has to happen with the arm stationary at the pose the policy expects
#      to start from, or the target is anchored to a smeared cube position.
#   2. start perception and wait for that latch. Starting the policy first would
#      have it act on a stale or missing /cube_xyz.
#   3. start the controller, which owns the arm until the episode ends.
#
# Prerequisites, in order of how often they are the thing that is wrong:
#   * the xArm ROS 2 driver is up and publishing /xarm/joint_states (this script
#     does NOT launch it). The driver must publish at the control rate: the stock
#     launch config publishes joint_states at 5 Hz, which is far too slow for a
#     40 Hz loop. Launch it with report_type:=dev to get ~100 Hz.
#   * scene_T_base_cam is calibrated for this cell (calibrate_scene_camera.py);
#     with the identity default the cube position is in camera coordinates and
#     the arm will drive somewhere unintended;
#   * POLICY_ONNX points at an exported policy;
#   * both RealSense cameras are on the bus, at the serials below.
#
# Usage:
#   ./run_pick_hold.sh 0.002                 # a tight clamp, for bring-up
#   ./run_pick_hold.sh                       # the tested per-tick clamp
#   POLICY_ONNX=/path/to/policy.onnx ./run_pick_hold.sh
#
# ** MOVES THE ROBOT. Have someone on the e-stop. **
#
# Stop it with Ctrl-C; the arm holds its last commanded pose (it does not go
# limp), and perception is killed on the way out.
# NOT set -u: ROS 2's setup.bash reads unset variables (AMENT_TRACE_SETUP_FILES and
# friends), so sourcing it under -u aborts the script before anything runs. Every
# variable here has a default, so -u buys nothing anyway.
set -o pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------- configuration
# The policy. xarm6_pick.onnx ships here: it is the v4 checkpoint
# (slowgripdr_pickhold_v4_000317194240) that the reference cell ran, so a fresh
# clone works without training first. Point POLICY_ONNX at your own export to
# replace it; training/export_policy_to_onnx.py writes the same 188-in/7-out graph.
POLICY_ONNX="${POLICY_ONNX:-$HERE/xarm6_pick.onnx}"

# Per-tick joint-delta clamp (rad), the main safety knob: it bounds how far any
# joint can move in one 25 ms tick regardless of what is commanded. 0.004 is the
# value the reference cell ran; lower throttles the approach. Start low on a new
# cell.
CLAMP="${1:-0.004}"

# The arm's IP. The controller opens a direct SDK connection to it, alongside
# ROS, for two reasons: the gripper's width feedback -- which is how a grasp is
# confirmed -- is not exposed as a ROS topic, and the arm is driven in mode 1
# (set_servo_angle_j streaming), which the ROS service interface does not offer.
ROBOT_IP="${ROBOT_IP:-192.168.1.231}"

# RealSense serials. Both cameras are D435i on the same bus, so each is pinned by
# serial -- enumeration order is not stable and the two are indistinguishable by model.
WRIST_SERIAL="${WRIST_SERIAL:-346522071715}"   # D435i, on the wrist
SCENE_SERIAL="${SCENE_SERIAL:-261222073781}"   # D435i, overhead

# Wrist camera -> TCP transform (16 row-major floats). This is the reference cell's,
# solved from the shipped calib/poses_wrist.json (6 poses, 2.0 mm RMS). Re-solve it for
# your cell with calibrate_wrist_camera.py; it only changes on a remount.
T_TCP_CAM="${T_TCP_CAM:-[-0.024106,-0.998854,-0.041345,0.072575,0.999691,-0.023831,-0.007118,-0.038362,0.006125,-0.041503,0.999120,-0.154673,0.0,0.0,0.0,1.0]}"

# Overhead camera -> base transform (16 row-major floats). THIS IS PER CELL: solve it
# with calibrate_scene_camera.py and paste the result here. The value below is the
# reference cell's (calib/scene_joint_fit.json, 36 pairs, 3.6 mm RMS) and is wrong for
# any other cell -- it encodes where that camera is bolted.
SCENE_T="${SCENE_T:-[0.848668,0.198476,-0.490275,-0.068190,0.525761,-0.417806,0.740955,-0.497121,-0.057778,-0.886592,-0.458930,0.503818,0.000000,0.000000,0.000000,1.000000]}"

# Residual grasp-xy bias (m), applied once when the wrist calibration converges.
# Below is the reference cell's; measure yours by grasping a cube at a known
# position rather than inheriting this one.
GRASP_OFF_X="${GRASP_OFF_X:--0.020}"
GRASP_OFF_Y="${GRASP_OFF_Y:-0.0}"

# Home pose (rad): the pose the policy was trained to start from.
HOME_JOINTS="${HOME_JOINTS:-[2.9415, -0.9205, -0.4684, 0.0882, 1.3669, 0.0]}"

CAP_DIR="${CAP_DIR:-$HERE/runs}"
PERCEPTION_LOG="${PERCEPTION_LOG:-/tmp/pick_hold_perception.log}"
CONTROLLER_LOG="${CONTROLLER_LOG:-/tmp/pick_hold_controller.log}"

# ------------------------------------------------------------------ sanity check
if [[ ! -f "$POLICY_ONNX" ]]; then
  echo "missing: $POLICY_ONNX" >&2
  echo "xarm6_pick.onnx ships in this directory and is stored with Git LFS -- a clone" >&2
  echo "made without git-lfs gets a text pointer instead of the model. 'git lfs pull'" >&2
  echo "fixes that. Or point POLICY_ONNX at a policy you exported yourself." >&2
  exit 1
fi
# An LFS pointer is a ~130-byte text file; onnxruntime's failure on one is not obvious.
if [[ "$(wc -c <"$POLICY_ONNX")" -lt 100000 ]]; then
  echo "$POLICY_ONNX is only $(wc -c <"$POLICY_ONNX") bytes -- this is a Git LFS pointer," >&2
  echo "not the model. Run 'git lfs pull'." >&2
  exit 1
fi
# An uncalibrated (identity) extrinsic does not fail loudly at run time: it makes
# the perception node publish cube positions in camera coordinates, which the
# controller believes and acts on. Cheaper to refuse here.
if python3 -c '
import sys
v = [float(x) for x in sys.argv[1].strip().strip("[]").split(",")]
eye = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
sys.exit(0 if len(v) == 16 and all(abs(a-b) < 1e-6 for a, b in zip(v, eye)) else 1)
' "$SCENE_T"; then
  echo "SCENE_T is the identity: the scene camera is not calibrated." >&2
  echo "Run calibrate_scene_camera.py first (see README.md)." >&2
  exit 1
fi

# shellcheck disable=SC1091
source /opt/ros/jazzy/setup.bash
# shellcheck disable=SC1091
source /xarm_ws/install/setup.bash

mkdir -p "$CAP_DIR"
pkill -9 -f cube_perception_node >/dev/null 2>&1
pkill -9 -f xarm6_pick_hold_controller_node >/dev/null 2>&1
sleep 2

# ------------------------------------ 1. enable the arm, home it, open the jaws
# Done over the SDK rather than the ROS services because the controller drives
# the arm in mode 1 and the gripper over the same interface; homing through a
# different path than the run uses is how mode/state mismatches slip in.
echo "=== enabling the arm, homing, opening the gripper ==="
python3 - "$ROBOT_IP" "$HOME_JOINTS" <<'PYHOME'
import ast, sys, time
from xarm.wrapper import XArmAPI

ip, home = sys.argv[1], ast.literal_eval(sys.argv[2])
a = XArmAPI(ip, is_radian=True)
a.connect()
time.sleep(0.5)
if a.error_code:
    print(f"clearing error {a.error_code}")
    a.clean_error()
    a.clean_warn()
a.motion_enable(True)
a.set_mode(0)
a.set_state(0)
time.sleep(0.3)
a.set_servo_angle(angle=home, speed=0.3, mvacc=3.0, wait=True, is_radian=True)
a.set_gripper_enable(True)
a.set_gripper_mode(0)
a.set_gripper_speed(2000)
a.set_gripper_position(850, wait=True)
print(f"arm err={a.error_code} state={a.state}, homed, gripper open")
a.disconnect()
PYHOME
sleep 1

# --------------------------------------------- 2. perception, then wait to latch
# The controller latches the cube itself from the first readings on /cube_xyz and
# never live-tracks it after that, so perception only has to be publishing a
# stable position before the controller starts.
# The cube is found with an HSV gate + OpenCV connected components on the RGB, and
# the centroid deprojected with the aligned depth. backend:=mock leaves the node's
# optional SlimSAM/GroundingDINO paths unloaded -- unused here, and they need torch.
echo "=== starting perception ==="
python3 "$HERE/cube_perception_node.py" --ros-args \
  -p backend:=mock \
  -p camera_source:=realsense -p extrinsic_mode:=eye_in_hand \
  -p "T_tcp_cam:=$T_TCP_CAM" -p rate_hz:=30.0 -p force_cube_z:=-1.0 \
  -p wrist_serial:="'$WRIST_SERIAL'" -p use_brio:=false \
  -p use_scene_rs:=true -p scene_serial:="'$SCENE_SERIAL'" \
  -p "scene_T_base_cam:=$SCENE_T" -p scene_z_plane:=0.03 \
  -p scene_cloud_median:=true -p scene_use_depth_model:=false \
  -p scene_livetrack_enable:=false \
  > "$PERCEPTION_LOG" 2>&1 &
PERCEPTION_PID=$!
trap 'kill $PERCEPTION_PID 2>/dev/null' EXIT

echo "=== waiting for a cube position (up to 40 s) ==="
CUBE=""
for _ in $(seq 1 40); do
  sleep 1
  CUBE="$(grep -o 'cube_xyz \[[^]]*\]' "$PERCEPTION_LOG" 2>/dev/null | tail -1)"
  [[ -n "$CUBE" ]] && break
  if ! kill -0 $PERCEPTION_PID 2>/dev/null; then
    echo "perception exited; see $PERCEPTION_LOG" >&2
    exit 1
  fi
done
if [[ -z "$CUBE" ]]; then
  echo "no cube seen in 40 s -- aborting before any motion." >&2
  echo "Usually: the cube is out of the scene camera's view, or the HSV bounds" >&2
  echo "do not match it. See $PERCEPTION_LOG." >&2
  exit 1
fi
echo "cube: $CUBE"

# ---------------------------------------------------------- 3. run the episode
echo "=== running (joint clamp $CLAMP rad/tick) ==="
python3 "$HERE/xarm6_pick_hold_controller_node.py" --ros-args \
  -p onnx_path:="$POLICY_ONNX" \
  -p robot_ip:="$ROBOT_IP" \
  -p dry_run:="${DRY_RUN:-false}" \
  -p max_joint_delta:="$CLAMP" \
  -p wrist_serial:="'$WRIST_SERIAL'" \
  -p grasp_off_x:="$GRASP_OFF_X" -p grasp_off_y:="$GRASP_OFF_Y" \
  -p joint_states_topic:=/xarm/joint_states \
  -p cube_topic:=/cube_xyz \
  -p log_path:="$CAP_DIR/pick_hold.csv" \
  2>&1 | tee "$CONTROLLER_LOG"

kill $PERCEPTION_PID 2>/dev/null
sleep 1
echo "=== phases ==="
grep -E "^\[INFO\].*-->|LATCHED|HELD|EMPTY|error|halting" "$CONTROLLER_LOG" | tail -20
echo "=== log: $CAP_DIR/pick_hold.csv ==="
