# Running the pick-and-hold policy on a real xArm6

Takes a policy exported from `training/` and has a real xArm6 pick a green cube off the
table and hold it. Copy this directory to the robot machine and work through the steps
below in order. **Steps 3-6 move the robot** -- keep a person on the e-stop.

| File | Role |
|---|---|
| `xarm6_pick_hold_controller_node.py` | Runs the policy at 40 Hz and streams its actions to the arm and gripper. |
| `cube_perception_node.py` | Finds the cube, publishes `/cube_xyz` in the base frame. HSV gate + OpenCV on the RGB, centroid from the aligned depth -- no model, no GPU. |
| `calibrate_wrist_camera.py` | Step 3: wrist camera to TCP. **Moves the robot.** |
| `calibrate_scene_camera.py` | Step 4: overhead camera to base. **Moves the robot.** |
| `eyehand_calib.py` | Solves the wrist extrinsic from the poses step 3 collects. |
| `xarm6_fk.py`, `numeric_ik.py` | Kinematics helpers. |
| `run_pick_hold.sh` | Step 6: runs one episode. **Moves the robot.** |
| `Dockerfile`, `requirements.txt` | The runtime. |
| `xarm6_pick.onnx` | The policy the reference cell ran (Git LFS). |
| `calib/` | That cell's wrist poses and overhead-camera fit. Replace with your own. |

**Hardware.** An xArm6 with the UFACTORY gripper; **two RealSense D435i** -- one on the
wrist, one overhead looking at the pick area; a green cube; a clear table. Detection is
colour-based, so the cube needs to be the only strongly green thing in view. For a
different green, edit `HSV_LO` / `HSV_HI` at the top of `cube_perception_node.py` (and
the matching `hsv_lo` / `hsv_hi` controller parameters).

## 1. Build and enter the container

```bash
docker build -t xarm6-deploy .
docker run -it --rm --network host --privileged -v /dev:/dev -v "$PWD:/deploy" xarm6-deploy
```

`--network host` so ROS reaches the arm, `--privileged -v /dev:/dev` for the cameras over
USB. To build librealsense from source with HIP instead of using the pip wheel, see the
`REALSENSE_FROM_SOURCE` and `HIP_ARCHS` build args at the top of the `Dockerfile`.

## 2. Start the driver and find the camera serials

```bash
ros2 launch xarm_api xarm6_driver.launch.py robot_ip:=192.168.1.231 report_type:=dev
```

`report_type:=dev` matters: the stock config publishes `/xarm/joint_states` at 5 Hz, far
too slow for a 40 Hz loop. Check with `ros2 topic hz /xarm/joint_states` (want ~100 Hz).

Both cameras are D435i, so they can only be told apart by serial. List them, then unplug
the wrist one and re-run to see which serial disappears:

```bash
python3 -c "import pyrealsense2 as rs
for d in rs.context().devices: print(d.get_info(rs.camera_info.name), d.get_info(rs.camera_info.serial_number))"
```

Put the two serials in `run_pick_hold.sh` as `WRIST_SERIAL` and `SCENE_SERIAL`, or export
them. Every step below reads them from there.

## 3. Calibrate the wrist camera (moves the robot)

The shipped `calib/` and the transforms in `run_pick_hold.sh` are the reference cell's,
so steps 3 and 4 are what adapt this to yours. The overhead one (step 4) is not optional
-- it encodes where that camera is bolted. Put the cube on the table where the arm can
see it from home, then:

```bash
python3 calibrate_wrist_camera.py                  # tours 6 poses, writes calib/poses_wrist.json
python3 eyehand_calib.py calib/poses_wrist.json    # solves and prints T_tcp_cam
```

Under ~10 mm RMS is good (the shipped one is 2.0 mm over 6 poses); over ~30 mm means adding
poses or more orientation spread. Paste the printed transform into `run_pick_hold.sh` as
`T_TCP_CAM`. The controller also reads `calib/poses_wrist.json` directly at startup, so
leave it in place. Only redo this if the camera is remounted.

## 4. Calibrate the overhead camera (moves the robot)

This is the step that most determines whether the arm reaches the right place, and it is
per cell. Clear the table -- the arm tours a grid with the gripper closed and empty.

```bash
python3 calibrate_scene_camera.py dry     # prints the grid, moves nothing. Check it first.
python3 calibrate_scene_camera.py auto    # tours the grid
python3 calibrate_scene_camera.py solve   # fits and prints the SCENE_T string
```

Paste `SCENE_T` into `run_pick_hold.sh`. The reference cell solved to 3.6 mm RMS; much worse
means the tip detection needs attention rather than that the number is usable.

## 5. Dry run (no motion)

```bash
python3 xarm6_pick_hold_controller_node.py --ros-args -p dry_run:=true -p log_path:=/tmp/dry.csv
```

Runs the full loop and sends nothing to the arm. In `/tmp/dry.csv`: the TCP and cube columns
should be populated and not NaN, and the cube-relative distance should change when you move
the cube. `dry_run` defaults to false, so a live run does not need it.

## 6. Run (moves the robot)

```bash
./run_pick_hold.sh 0.002
```

The argument is the per-tick joint-delta clamp in radians, the main safety knob. 0.004 is
what the reference cell ran; start below it and work up. The script homes the arm, opens the
jaws, waits for a cube position, then runs. Ctrl-C stops it and the arm holds its last pose.
Per-tick CSV lands in `runs/`.

A good run reaches the cube, closes on it, then lifts and holds. In the CSV the `pulse`
column settles inside the held band (120-600) and `tcp_z` climbs by ~200 mm and stays
there. The arm should finish without a robot error.

If the grasp is consistently off to one side, measure the bias by grasping a cube at a known
position and set `GRASP_OFF_X` / `GRASP_OFF_Y`.

## Parameters

Every controller default is a ROS parameter, in the `p(...)` block at the top of the file.
`POLICY_ONNX` (default `./xarm6_pick.onnx`, the shipped v4 checkpoint) and `ROBOT_IP` are
set in `run_pick_hold.sh`.

The exported `.yaml` is **not** read at run time. If a retrain changes the action scales,
joint limits or control rate, update `joint_action_scale`, `gripper_action_scale`,
`joint_lo`/`joint_hi` and `rate_hz` to match it by hand.
