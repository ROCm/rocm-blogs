#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Run the pick-and-hold policy on a real xArm6.

Rebuilds the policy's observation from the robot's sensors, runs the ONNX graph at 40 Hz,
and streams the decoded actions to the arm and gripper.

Observation, 188-D: 4 stacked frames of 47, oldest first. Per frame: qpos(7) qvel(6) tcp(3)
rot_rows23(6) ctrl_lead(7) box_from_tcp(3) box_rot(6) target_from_box(3) target_box_rot(3)
contact(3).

Actions, 7: the first six are per-joint setpoint deltas, scaled by joint_action_scale and
clamped by max_joint_delta; the seventh integrates the gripper command.

The cube position is latched once, from the first readings on /cube_xyz, and not tracked
after that. Once the cube is in the gripper it rides with the TCP in the observation, and
contact is reported from the measured gripper width.

Paths are relative to this file, so the directory can be copied to the robot as a unit.
"""

from __future__ import annotations

import math
import os
import pathlib
import sys
import threading
import time
from typing import Any

import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

_HERE = pathlib.Path(__file__).resolve().parent
_CALIB_DIR = _HERE / "calib"
sys.path.insert(0, str(_HERE))

try:
    from geometry_msgs.msg import PointStamped
except ImportError:
    PointStamped = None

from xarm6_fk import fk as _fk
from numeric_ik import numeric_ik as _ik

_ARM = 6
_PER_FRAME = 47
_HIST = 4
_STATE_DIM = _PER_FRAME * _HIST
_TARGET_UP = np.array([0.0, 0.0, 0.25], dtype=np.float64)

class GraspCommand:
    """Closes the grasp once the policy has brought the arm over the cube: refines the
    grasp xy from the wrist camera, descends, closes, and confirms from the gripper
    width."""

    def __init__(self, c: "XArm6PickHoldController") -> None:
        self.c = c
        self.stage = "idle"
        self.joint_target: np.ndarray | None = None
        self.grip_override: float | None = None
        self.abort_reason = ""
        self.xy = np.zeros(2, dtype=np.float64)
        self.iter = 0
        self.fail_count = 0
        self.wait_until = 0.0
        self.descending = False
        self.t0 = 0.0

    def start(self, xy: np.ndarray) -> None:
        self.stage = "calib"
        self.xy = np.asarray(xy, dtype=np.float64).copy()
        self.iter = 0
        self.fail_count = 0
        self.descending = False
        self.t0 = time.time()
        self.wait_until = self.t0 + 1.0
        self.c._release_wrist(True)

    def _to(self, stage: str, msg: str) -> None:
        self.stage = stage
        self.t0 = time.time()
        self.c.get_logger().info(f"    grasp -> {stage}: {msg}")

    def _abort(self, reason: str) -> str:
        if self.stage == "calib":
            self.c._close_wrist()
        self.stage = "idle"
        self.abort_reason = reason
        return "abort"

    def _track(self, goal: np.ndarray) -> str:
        q = self.c._pose_step(goal)
        if q is None:
            self.fail_count += 1
            self.joint_target = self.c.setpoint.copy()
            return "exhausted" if self.fail_count >= self.c.retry_max else "holding"
        self.fail_count = 0
        self.joint_target = q
        return "tracking"

    def step(self, tcp: np.ndarray) -> str:
        c = self.c
        self.joint_target = None
        self.grip_override = None

        if self.stage == "calib":
            self.grip_override = 0.0
            cur = _fk(c.setpoint)[:3, 3]
            look_z = float(np.clip(cur[2], c.calib_z_min, c.calib_z_max))
            goal = np.array([self.xy[0], self.xy[1], look_z])
            t = self._track(goal)
            if t == "exhausted":
                return self._abort(
                    f"could not reach the wrist-look pose ({self.fail_count} tries)")
            if t == "holding" or not c._at(goal) or time.time() < self.wait_until:
                return "running"
            w = c._wrist_xy()
            if w is None:
                c._close_wrist()
                self._to("descend", "the wrist cannot see the cube -- descending on the "
                                    "perception xy instead")
                return "running"
            moved = float(np.linalg.norm(w - self.xy))
            self.iter += 1
            c.get_logger().info(f"    grasp calib {self.iter}: wrist says "
                                f"[{w[0]:+.4f} {w[1]:+.4f}], moved {moved*1000:.1f} mm")
            self.xy = w
            self.wait_until = time.time() + 0.4
            if moved < c.calib_eps or self.iter >= c.calib_max_iter:
                self.xy = self.xy + c.grasp_off
                c._close_wrist()
                self._to("descend", f"converged -> grasp xy "
                                    f"[{self.xy[0]:+.4f} {self.xy[1]:+.4f}] "
                                    f"(incl. collector grasp offset)")
            return "running"

        if self.stage == "descend":
            self.grip_override = 0.0
            cur = _fk(c.setpoint)[:3, 3]
            over = (float(np.linalg.norm(cur[:2] - self.xy)) < 0.01
                    and cur[2] > c.grasp_z + 0.02)
            if over:
                self.descending = True
            z = c.grasp_z if (over or self.descending) else c.approach_z
            goal = np.array([self.xy[0], self.xy[1], z])
            t = self._track(goal)
            if t == "exhausted":
                return self._abort(f"could not descend ({self.fail_count} tries)")
            if t == "tracking" and c._at(goal):
                self._to("close", f"at grasp pose {np.round(goal, 4).tolist()}")
            return "running"

        if self.stage == "close":
            self.joint_target = c.setpoint.copy()
            self.grip_override = c.grip_hi
            if time.time() - self.t0 > c.close_sec:
                self._to("confirm", "close settled -> reading the pulse")
            return "running"

        if self.stage == "confirm":
            self.joint_target = c.setpoint.copy()
            self.grip_override = c.grip_hi
            pl = c.pulse
            if pl is None or not (c.held_lo <= pl <= c.held_hi):
                self.grip_override = 0.0
                return self._abort(f"EMPTY: pulse={pl} -> reopening, the policy retries")
            cnow = c.cube if c.cube is not None else tcp
            c.grasp_hold_off = (cnow - tcp).astype(np.float64)
            c.grasped = True
            self.stage = "idle"
            c.get_logger().info(
                f"    grasp HELD: pulse={pl:.0f} ({c._jaw_mm():.0f} mm jaw), "
                f"cube offset {np.round(c.grasp_hold_off, 4).tolist()}")
            return "done"

        return "running"

class XArm6PickHoldController(Node):

    def __init__(self) -> None:
        super().__init__("xarm6_pick_hold_controller")
        p = self.declare_parameter

        p("onnx_path", str(_HERE / "xarm6_pick.onnx"))
        p("cube_topic", "/cube_xyz")
        p("joint_states_topic", "/xarm/joint_states")
        p("robot_ip", "192.168.1.231")

        p("rate_hz", 40.0)
        p("episode_steps", 400)
        p("joint_action_scale", 0.02)
        p("gripper_action_scale", 0.085)
        p("grip_hi", 0.85)
        p("max_joint_delta", 0.004)
        p("max_lead", 0.15)
        p("joint_lo", [-6.28, -2.05, -3.92, -6.28, -1.69, -6.28])
        p("joint_hi", [6.28, 2.09, 0.18, 6.28, 3.14, 6.28])

        p("mm_per_count", 0.1025)
        p("open_pulse", 850)
        p("held_lo", 120.0)
        p("held_hi", 600.0)

        p("latch_n", 9)
        p("conv_eps", 0.01)
        p("conv_hold", 6)
        p("min_approach_ticks", 60)
        p("min_descent", 0.05)
        p("handover_dz", 0.05)
        p("handover_radius", 0.12)
        p("settle_ticks", 6)
        p("grasp_z", 0.020)
        p("hover_z", 0.25)
        p("step_size", 0.004)
        p("seed_pose", [2.95472, -0.19178, -0.46743, -0.14908, 0.5651, -0.00237])
        p("calib_z_min", 0.10)
        p("calib_z_max", 0.20)
        p("approach_z", 0.12)
        p("z_floor", 0.015)
        p("x_inner_limit", -0.175)
        p("retry_max", 25)
        p("close_sec", 1.5)
        p("arrive_tol", 0.006)
        p("calib_eps", 0.005)
        p("calib_max_iter", 4)
        p("grasp_off_x", -0.020)
        p("grasp_off_y", 0.0)
        p("wrist_serial", "346522071715")
        p("hsv_lo", [40, 150, 50])
        p("hsv_hi", [90, 255, 255])

        p("cube_timeout", 1.0)
        p("log_path", "")
        p("dry_run", False)

        g = lambda k: self.get_parameter(k).value
        self.onnx_path = str(g("onnx_path"))
        self.rate_hz = float(g("rate_hz"))
        self.dt = 1.0 / self.rate_hz
        self.episode_steps = int(g("episode_steps"))
        self.jscale = float(g("joint_action_scale"))
        self.gscale = float(g("gripper_action_scale"))
        self.grip_hi = float(g("grip_hi"))
        self.max_dq = float(g("max_joint_delta"))
        self.max_lead = float(g("max_lead"))
        self.jlo = np.array([float(v) for v in g("joint_lo")], dtype=np.float64)
        self.jhi = np.array([float(v) for v in g("joint_hi")], dtype=np.float64)
        self.mm_per_count = float(g("mm_per_count"))
        self.open_pulse = int(g("open_pulse"))
        self.held_lo = float(g("held_lo"))
        self.held_hi = float(g("held_hi"))
        self.latch_n = int(g("latch_n"))
        self.conv_eps = float(g("conv_eps"))
        self.conv_hold = int(g("conv_hold"))
        self.min_approach_ticks = int(g("min_approach_ticks"))
        self.min_descent = float(g("min_descent"))
        self.start_z = None
        self.handover_dz = float(g("handover_dz"))
        self.handover_radius = float(g("handover_radius"))
        self.settle_ticks = int(g("settle_ticks"))
        self.grasp_z = float(g("grasp_z"))
        self.hover_z = float(g("hover_z"))
        self.step_size = float(g("step_size"))
        self.retry_max = int(g("retry_max"))
        self.calib_z_min = float(g("calib_z_min"))
        self.calib_z_max = float(g("calib_z_max"))
        self.approach_z = float(g("approach_z"))
        self.z_floor = float(g("z_floor"))
        self.x_inner_limit = float(g("x_inner_limit"))
        self.seed_pose = np.array([float(v) for v in g("seed_pose")], dtype=np.float64)
        self.close_sec = float(g("close_sec"))
        self.arrive_tol = float(g("arrive_tol"))
        self.calib_eps = float(g("calib_eps"))
        self.calib_max_iter = int(g("calib_max_iter"))
        self.grasp_off = np.array([float(g("grasp_off_x")), float(g("grasp_off_y"))])
        self.wrist_serial = str(g("wrist_serial"))
        self.hsv_lo = tuple(int(v) for v in g("hsv_lo"))
        self.hsv_hi = tuple(int(v) for v in g("hsv_hi"))
        self.cube_timeout = float(g("cube_timeout"))
        self.dry_run = bool(g("dry_run"))
        log_path = str(g("log_path"))

        self.q = np.zeros(_ARM, dtype=np.float64)
        self.qd = np.zeros(_ARM, dtype=np.float64)
        self.have_q = False
        self.setpoint = np.zeros(_ARM, dtype=np.float64)
        self.setpoint_init = False
        self.grip_ctrl = 0.0
        self.cube: np.ndarray | None = None
        self.cube_t = -1e9
        self.cube_spawn: np.ndarray | None = None
        self.latch_buf: list[np.ndarray] = []
        self.hist: list[np.ndarray] = []
        self.step_i = 0
        self.phase = "REACH"
        self.near_cnt = 0
        self.prev_setpoint = None
        self.phase_t0 = time.time()
        self.joint_target: np.ndarray | None = None
        self.grip_override: float | None = None
        self.grasp_R: np.ndarray | None = None
        self.done = False
        self.grasp = GraspCommand(self)
        self.grasped = False
        self.grasp_hold_off: np.ndarray | None = None
        self._last_contact = np.zeros(3)

        self.wgrab = None
        self.T_tcp_cam = None
        if not self.dry_run:
            try:
                import json
                import eyehand_calib
                self.T_tcp_cam = eyehand_calib.solve(
                    json.load(open(_CALIB_DIR / "poses_wrist.json")))[0]
            except Exception as exc:
                self.get_logger().warn(
                    f"no wrist extrinsic: {exc}; the grasp calibration will be skipped")

        self.pulse: float | None = None
        self._tx_target = self.open_pulse
        self._tx_evt = threading.Event()
        self._stop = threading.Event()
        self.arm = None
        if not self.dry_run:
            from xarm.wrapper import XArmAPI
            self.arm = XArmAPI(str(g("robot_ip")), is_radian=True)
            self.arm.connect()
            time.sleep(0.3)
            self.arm.clean_error()
            self.arm.clean_warn()
            self.arm.motion_enable(True)
            self.arm.set_mode(1)
            self.arm.set_state(0)
            time.sleep(0.3)
            self.arm.set_gripper_enable(True)
            self.arm.set_gripper_mode(0)
            self.arm.set_gripper_speed(2000)
            self.arm.set_gripper_position(self.open_pulse, wait=True)
            self.get_logger().info(
                f"arm ready: err={self.arm.error_code} state={self.arm.state} mode={self.arm.mode}")
            threading.Thread(target=self._grip_tx, daemon=True).start()
            threading.Thread(target=self._grip_rx, daemon=True).start()

        import onnxruntime as ort
        self.sess = ort.InferenceSession(self.onnx_path, providers=["CPUExecutionProvider"])
        self.in_name = self.sess.get_inputs()[0].name
        self.get_logger().info(f"policy loaded: {os.path.basename(self.onnx_path)}")

        self.logf = None
        if log_path:
            self.logf = open(log_path, "w", buffering=1)
            self.logf.write("t,phase,tcp_x,tcp_y,tcp_z,cube_x,cube_y,cube_z,lat,"
                            "grip_ctrl,pulse,jaw_mm,a_grip,contact,force\n")

        from std_msgs.msg import Bool as _Bool
        self._rel_pub = self.create_publisher(_Bool, "/wrist_release", 1)
        self._BoolMsg = _Bool
        self.create_subscription(JointState, str(g("joint_states_topic")), self._on_js, 20)
        if PointStamped is not None:
            self.create_subscription(PointStamped, str(g("cube_topic")), self._on_cube, 10)
        self.create_timer(self.dt, self._tick)
        self.get_logger().info(f"controller up at {self.rate_hz:.0f} Hz, dry_run={self.dry_run}")

    def _grip_tx(self) -> None:
        while not self._stop.is_set():
            if not self._tx_evt.wait(timeout=0.2):
                continue
            self._tx_evt.clear()
            try:
                self.arm.set_gripper_position(int(self._tx_target), wait=False)
            except Exception:
                pass

    def _grip_rx(self) -> None:
        while not self._stop.is_set():
            try:
                code, v = self.arm.get_gripper_position()
                if code == 0 and v is not None:
                    self.pulse = float(v)
            except Exception:
                pass
            time.sleep(0.02)

    def _set_jaw(self, ctrl: float) -> None:
        frac = float(np.clip(ctrl / max(self.grip_hi, 1e-6), 0.0, 1.0))
        self._tx_target = int(round((1.0 - frac) * self.open_pulse))
        self._tx_evt.set()

    def _jaw_mm(self) -> float:
        return (self.pulse * self.mm_per_count) if self.pulse is not None else float("nan")

    def _on_js(self, msg: JointState) -> None:
        name = list(msg.name)
        idx = []
        for j in range(1, _ARM + 1):
            n = f"joint{j}"
            if n not in name:
                return
            idx.append(name.index(n))
        self.q = np.array([msg.position[i] for i in idx], dtype=np.float64)
        if msg.velocity and len(msg.velocity) > max(idx):
            self.qd = np.array([msg.velocity[i] for i in idx], dtype=np.float64)
        self.have_q = True
        if not self.setpoint_init:
            self.setpoint = self.q.copy()
            self.setpoint_init = True
            self.grasp_R = _fk(self.q)[:3, :3]
            self.start_z = float(_fk(self.q)[2, 3])
            self.get_logger().info(f"setpoint initialised at {np.round(self.q, 4).tolist()}")

    def _on_cube(self, msg: Any) -> None:
        c = np.array([msg.point.x, msg.point.y, msg.point.z], dtype=np.float64)
        if not np.all(np.isfinite(c)):
            return
        self.cube_t = time.time()
        if self.cube_spawn is None:
            self.latch_buf.append(c)
            if len(self.latch_buf) >= self.latch_n:
                self.cube_spawn = np.median(np.array(self.latch_buf), axis=0)
                self.cube = self.cube_spawn.copy()
                self.get_logger().info(
                    f"cube LATCHED at {np.round(self.cube_spawn, 4).tolist()} "
                    f"(median of {self.latch_n} reads; no live tracking from here)")

    def _obs(self, tcp: np.ndarray, R: np.ndarray) -> np.ndarray:
        grip_q = self._grip_qpos()
        qpos = np.concatenate([self.q, [grip_q]])
        lead = np.concatenate([self.setpoint - self.q, [self.grip_ctrl - grip_q]])

        if self.grasped and self.grasp_hold_off is not None:
            cube = tcp + self.grasp_hold_off
        else:
            cube = self.cube if self.cube is not None else tcp.copy()
        spawn = self.cube_spawn if self.cube_spawn is not None else cube
        box_from_tcp = cube - tcp
        box_rot = np.array([0.0, 1.0, 0.0, 0.0, 0.0, 1.0])
        target_from_box = (spawn + _TARGET_UP) - cube
        target_box_rot = np.zeros(3)
        contact = self._contact(tcp, cube)
        self._last_contact = contact

        frame = np.concatenate([
            qpos, self.qd, tcp, R[1:3, :].reshape(-1), lead,
            box_from_tcp, box_rot, target_from_box, target_box_rot, contact,
        ]).astype(np.float32)
        if frame.shape[0] != _PER_FRAME:
            raise RuntimeError(f"frame is {frame.shape[0]}, expected {_PER_FRAME}")
        frame = np.nan_to_num(frame, nan=0.0)

        if not self.hist:
            self.hist = [frame] * _HIST
        else:
            self.hist.append(frame)
            self.hist = self.hist[-_HIST:]
        return np.concatenate(self.hist).astype(np.float32)

    def _grip_qpos(self) -> float:
        if self.pulse is None:
            return float(np.clip(self.grip_ctrl, 0.0, self.grip_hi))
        frac = 1.0 - float(np.clip(max(self.pulse, 0.0) / self.open_pulse, 0.0, 1.0))
        return float(np.clip(frac * self.grip_hi, 0.0, self.grip_hi))

    def _contact(self, tcp: np.ndarray, cube: np.ndarray) -> np.ndarray:
        if self.grasped and self.pulse is not None and self.held_lo <= self.pulse <= self.held_hi:
            f = float(np.clip((self.held_hi - self.pulse) / max(self.held_hi - self.held_lo, 1.0),
                              0.3, 1.0))
            return np.array([1.0, 1.0, float(np.clip(f * 10.0, 3.0, 10.0))])
        return self._contact_proximity(tcp, cube)

    def _contact_proximity(self, tcp: np.ndarray, cube: np.ndarray) -> np.ndarray:
        dz = float(tcp[2] - cube[2])
        xy = float(np.hypot(tcp[0] - cube[0], tcp[1] - cube[1]))
        if xy > 0.02 or dz > 0.05 or dz < -0.05:
            return np.zeros(3)
        f = float(np.clip((0.05 - dz) / 0.05, 0, 1) * np.clip(1 - xy / 0.02, 0, 1))
        return np.array([f, f, float(np.clip(f * f * 10.0, 0.0, 10.0))])

    def _pose_step(self, goal_xyz: np.ndarray) -> np.ndarray | None:
        if self.grasp_R is None:
            return None
        cur = _fk(self.setpoint)[:3, 3]
        if goal_xyz[2] < self.z_floor:
            self.get_logger().warn(
                f"goal z={goal_xyz[2]:+.3f} is below the table floor ({self.z_floor:+.3f}); "
                "refusing", throttle_duration_sec=2.0)
            return None
        if goal_xyz[0] > self.x_inner_limit:
            self.get_logger().warn(
                f"goal x={goal_xyz[0]:+.3f} is inside the reach limit "
                f"({self.x_inner_limit:+.3f}); refusing", throttle_duration_sec=2.0)
            return None
        delta = goal_xyz - cur
        dist = float(np.linalg.norm(delta))
        if dist > self.step_size:
            waypoint = cur + delta / dist * self.step_size
        else:
            waypoint = goal_xyz
        try:
            q, res = _ik(waypoint, self.grasp_R, self.seed_pose)
        except Exception as exc:
            self.get_logger().warn(f"pose solve raised: {exc}")
            return None
        q = np.clip(np.asarray(q, dtype=np.float64), self.jlo, self.jhi)
        if res > 2e-2:
            self.get_logger().warn(
                f"no pose reaches waypoint {np.round(waypoint, 4).tolist()} "
                f"(res={res:.4f}, step={self.step_size*1000:.0f} mm)")
            return None
        return np.asarray(q, dtype=np.float64)

    def _at(self, goal_xyz: np.ndarray) -> bool:
        return float(np.linalg.norm(_fk(self.q)[:3, 3] - goal_xyz)) < self.arrive_tol

    def _release_wrist(self, release: bool) -> None:
        try:
            m = self._BoolMsg()
            m.data = bool(release)
            self._rel_pub.publish(m)
        except Exception:
            pass

    def _close_wrist(self) -> None:
        if self.wgrab is not None:
            try:
                self.wgrab.stop()
            except Exception:
                pass
            self.wgrab = None
        self._release_wrist(False)
        self.get_logger().info("wrist returned to perception")

    def _wrist_xy(self) -> np.ndarray | None:
        if self.T_tcp_cam is None:
            return None
        if self.wgrab is None:
            try:
                from cube_perception_node import RealSenseGrabber
                self.wgrab = RealSenseGrabber(width=1280, height=720, want_ir=False,
                                              serial=self.wrist_serial)
                time.sleep(0.5)
                self.get_logger().info("wrist camera opened for calibration")
            except Exception as exc:
                self.get_logger().warn(
                    f"cannot open the wrist camera ({exc}); is the perception node holding it? "
                    "the grasp calibration will fall through to the perception xy.")
                return None
        got = self.wgrab.latest()
        if got is None:
            return None
        rgb, depth, K = got
        import cv2
        hsv = cv2.cvtColor(np.ascontiguousarray(rgb[..., ::-1]), cv2.COLOR_BGR2HSV)
        green = cv2.inRange(hsv, np.array(self.hsv_lo), np.array(self.hsv_hi)) > 0
        valid = (depth > 0.05) & np.isfinite(depth)
        ys, xs = np.where(green & valid)
        if len(xs) < 30:
            return None
        d = depth[ys, xs]
        fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
        X = (xs - cx) * d / fx
        Y = (ys - cy) * d / fy
        pts = np.stack([X, Y, d, np.ones_like(d)], 1)
        b = (_fk(self.q) @ self.T_tcp_cam @ pts.T).T[:, :3]
        return np.array([float(np.median(b[:, 0])), float(np.median(b[:, 1]))])

    def _advance(self, name: str, msg: str) -> None:
        self.phase = name
        self.phase_t0 = time.time()
        self.get_logger().info(f"--> {name}: {msg}")

    def _run_phase(self, tcp: np.ndarray) -> None:
        cube = self.cube
        self.joint_target = None
        self.grip_override = None

        if self.phase == "REACH":
            if cube is None:
                return
            dq = (float(np.max(np.abs(self.setpoint - self.prev_setpoint)))
                  if self.prev_setpoint is not None else 1.0)
            self.prev_setpoint = self.setpoint.copy()
            descended = float(tcp[2]) < (self.start_z - self.min_descent)
            if self.step_i >= self.min_approach_ticks and descended:
                conv = dq < self.conv_eps
            else:
                conv = False
            self.near_cnt = self.near_cnt + 1 if conv else 0
            if self.near_cnt >= self.conv_hold:
                lat = float(np.linalg.norm(tcp[:2] - cube[:2]))
                self.grasp.start(cube[:2])
                self._advance("GRASP", f"policy converged (dq={dq*1000:.2f} mrad for "
                                       f"{self.near_cnt} ticks, lat={lat*1000:.0f} mm)")
            return

        if self.phase == "GRASP":
            status = self.grasp.step(tcp)
            self.joint_target = self.grasp.joint_target
            self.grip_override = self.grasp.grip_override
            if status == "done":
                self._advance("LIFT", "cube held -> the policy lifts and holds it")
            elif status == "abort":
                self.near_cnt = 0
                self._advance("REACH", self.grasp.abort_reason)
            return

        self.grip_override = self.grip_hi

    def _tick(self) -> None:
        if self.done or not self.have_q or not self.setpoint_init:
            return
        if self.cube is None or (time.time() - self.cube_t) > self.cube_timeout:
            self.get_logger().warn("waiting for the cube latch / perception",
                                   throttle_duration_sec=1.0)
            return

        T = _fk(self.q)
        tcp, R = T[:3, 3], T[:3, :3]

        obs = self._obs(tcp, R)
        act = self.sess.run(None, {self.in_name: obs[None, :]})[0][0]
        act = np.clip(act, -1.0, 1.0)

        self._run_phase(tcp)

        policy_owns = self.phase in ("REACH", "LIFT")
        if self.joint_target is not None:
            dq = np.clip(self.joint_target - self.setpoint, -self.max_dq, self.max_dq)
        elif policy_owns:
            dq = np.clip(act[:_ARM] * self.jscale, -self.max_dq, self.max_dq)
        else:
            dq = np.zeros(_ARM)
        self.setpoint = np.clip(self.setpoint + dq, self.jlo, self.jhi)
        at_lim = (self.setpoint <= self.jlo + 1e-4) | (self.setpoint >= self.jhi - 1e-4)
        if at_lim.any():
            self.get_logger().warn(
                f"joint(s) {np.where(at_lim)[0].tolist()} at their limit -- "
                f"setpoint {np.round(self.setpoint, 4).tolist()}", throttle_duration_sec=2.0)
        lead = self.setpoint - self.q
        big = np.abs(lead) > self.max_lead
        if big.any():
            self.setpoint[big] = self.q[big] + np.clip(lead[big], -self.max_lead, self.max_lead)

        self.grip_ctrl = float(np.clip(self.grip_ctrl + act[_ARM] * self.gscale, 0.0, self.grip_hi))
        self._set_jaw(self.grip_override if self.grip_override is not None else self.grip_ctrl)

        if not self.dry_run:
            try:
                self.arm.set_servo_angle_j(angles=self.setpoint.tolist(), is_radian=True)
            except Exception as exc:
                self.get_logger().warn(f"servo write failed: {exc}")
            if self.arm.error_code:
                self.get_logger().error(f"robot error {self.arm.error_code} -- halting")
                self.done = True
                return

        if self.logf is not None:
            c = (tcp + self.grasp_hold_off
                 if (self.grasped and self.grasp_hold_off is not None) else self.cube)
            lat = float(np.linalg.norm(tcp[:2] - c[:2]))
            self.logf.write(
                f"{time.time():.4f},{self.phase},{tcp[0]:.5f},{tcp[1]:.5f},{tcp[2]:.5f},"
                f"{c[0]:.5f},{c[1]:.5f},{c[2]:.5f},{lat:.5f},{self.grip_ctrl:.4f},"
                f"{-1 if self.pulse is None else self.pulse:.0f},{self._jaw_mm():.1f},"
                f"{act[_ARM]:+.4f},{self._last_contact[0]:.3f},{self._last_contact[2]:.2f}\n")

        self.step_i += 1
        if self.step_i >= self.episode_steps and self.phase == "REACH":
            self.get_logger().info(f"episode limit ({self.episode_steps}) in phase {self.phase}")
            self.done = True

    def shutdown(self) -> None:
        self._stop.set()
        if self.logf is not None:
            self.logf.close()
        if self.arm is not None:
            try:
                self.arm.set_mode(0)
                self.arm.set_state(0)
            except Exception:
                pass
            self.arm.disconnect()

def main() -> None:
    rclpy.init()
    node = XArm6PickHoldController()
    try:
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass
    finally:
        node.get_logger().info(f"finished in phase {node.phase} after {node.step_i} steps")
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
