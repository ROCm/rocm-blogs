#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Calibrate the overhead SCENE camera -> base extrinsic by SWEEPING THE GRIPPER TIP.

** THIS SCRIPT MOVES THE ROBOT. ** Run only with a person present and an e-stop in reach.

Method — the brio_dlt.py idea (tip, NOT grasp): move the gripper (no cube, gripper CLOSED) to a
grid of known base poses that vary xy AND z (non-coplanar), keeping the home grasp orientation
R=fk(HOME) FIXED. At each pose:
  - base TRUTH = FK(measured_q)[:3,3]                         (validated link_tcp)
  - camera     = scene-cam deproject of the DARK gripper-tip blob -> CAMERA-frame xyz
Umeyama solves cam->base (4x4). Because the orientation is FIXED for the whole sweep, the
constant tip<->link_tcp offset is absorbed into the extrinsic's translation -> the solved
transform maps "camera point of an object" to "where to command link_tcp to reach it" (the same
self-compensation that let the BRIO DLT grasp accurately). No grasp, no cube, so no grasp-failure.

Varying z across the grid is what constrains the extrinsic in 3D (a single-height planar tour
under-determines z).

Workflow (person present):
  1. Clear the workspace (the gripper sweeps empty). It is commanded CLOSED for a compact tip.
  2. python3 calibrate_scene_camera.py dry     -> prints the grid, moves nothing. Check it first.
  3. python3 calibrate_scene_camera.py auto    -> the arm tours the grid, detects the tip and
     homes; writes calib/scene_camera_pairs.json next to this file.
  4. python3 calibrate_scene_camera.py solve   -> fits the extrinsic and prints the SCENE_T
     string to paste into run_pick_hold.sh.

The robot IP and the camera serial differ per cell; override them in the environment:

    ROBOT_IP=192.168.1.231 SCENE_SERIAL=<overhead serial> python3 calibrate_scene_camera.py auto
Modes: auto (sweep+collect) | solve (fit) | show (dump pairs) | dry (print grid, NO motion)
"""
import os, sys, time, json, pathlib
import numpy as np, cv2
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from xarm6_fk import fk
from numeric_ik import numeric_ik

_HERE = pathlib.Path(__file__).resolve().parent
PAIRS = os.environ.get("CALIB_PAIRS", str(_HERE / "calib" / "scene_camera_pairs.json"))
IP = os.environ.get("ROBOT_IP", "192.168.1.231")
SCENE_SERIAL = os.environ.get("SCENE_SERIAL", "261222073781")   # overhead D435i
HOME = np.array([2.9415, -0.9205, -0.4684, 0.0882, 1.3669, 0.0])
R = fk(HOME)[:3, :3]                    # fixed orientation for the whole sweep
DARK_V = 70                            # gripper is dark: HSV value < DARK_V (as brio_dlt.py)
OPEN_PULSE = 850

# tip-sweep grid: xy spread across the -x pick workspace x carry heights. z variation REQUIRED.
SWEEP_XY = [(-0.29, -0.02), (-0.31, 0.05), (-0.27, -0.06), (-0.33, 0.00),
            (-0.28, 0.07), (-0.32, -0.08), (-0.26, 0.03), (-0.335, 0.02)]
# link_tcp heights: MUST span down to TABLE/grasp height (~0.04) so the calibrated volume
# includes where the cube actually sits (depth ~0.75m). The old grid (0.12-0.28) sat ABOVE the
# cube's depth -> the extrinsic extrapolated at table height -> ~3.5cm y-shift on the cube. Now
# 0.04-0.28 brackets the cube depth so the solve is accurate AT the grasp plane.
SWEEP_Z = [0.08, 0.12, 0.17, 0.22, 0.28]   # non-coplanar. 0.08 lowest: the CLOSED gripper tip
                                            # extends ~2-3cm below link_tcp, so z=0.05 hit the
                                            # table (err31); 0.08 clears it while still bracketing
                                            # the cube's depth (~cube-top height) far better than
                                            # the old 0.12 floor that caused the +3.5cm y-bias.


def make_grid():
    g = []
    for zi, z in enumerate(SWEEP_Z):
        xs = SWEEP_XY if zi % 2 == 0 else list(reversed(SWEEP_XY))    # snake -> less travel
        for (x, y) in xs:
            g.append((x, y, z))
    return g


# The overhead scene cam sees permanent DARK CLUTTER on the table (a black cable, a
# black-handled tool, a dark table cutout) that we CANNOT remove (it is the robot's
# workspace). Those clutter blobs are often LARGER than the small gripper tip, so
# max-area picks them and the calib collapses (measured: cam readings clustered into
# 2-3 fixed clutter positions, not tracking the sweep). But the gripper tip is
# ELEVATED 8-28 cm above the table -> from the overhead cam it is always the NEAREST
# dark blob. Measured margin ~10 cm at every sweep height (tip ~0.51-0.53 m vs nearest
# clutter >=0.60 m, table ~0.79 m). So we select the dark blob with the MINIMUM median
# depth, not the max area, and trim each candidate to its near-depth pixels so a tip
# blob that has merged with adjacent table/tool pixels still gives the tip centroid.
TIP_DEPTH_BAND = 0.05   # keep blob pixels within this (m) of the blob's near depth (5th pct)
TIP_MAX_DEPTH = 0.70    # tip depth ceiling. -y poses read ~0.51, +y poses ~0.62 (tip is
                        # farther from cam at +y). With the cable decoy removed by the ROI
                        # below, the next clutter is the TABLE at ~0.79 m, so 0.70 admits the
                        # +y tip while still excluding the table. (0.615 was too tight -> +y
                        # tip rejected as None.)
# The depth gate rejects all the TABLE-level dark clutter, but ONE decoy survives it: a
# black CABLE coil sitting near the camera mount in the BOTTOM-RIGHT corner. Being close
# to the overhead cam it reads ~0.56 m -- NEARER than the tip at some +y poses (0.62 m),
# so nearest-depth picks the cable there (measured: those poses' cam readings stuck to a
# fixed cable position -> RMS 125 mm). The gripper NEVER sweeps into that corner (the grid
# is the center-left table), so we simply EXCLUDE that fixed image region. In the 1280x720
# scene frame the cable+mount live at x>1040, y>410; the tip stays at y<~400, x<~1030.
EXCLUDE_X0, EXCLUDE_Y0 = 1040, 410     # bottom-right corner (cable + cam mount): zero the mask here


def scene_tip_cam(grab):
    """Scene-cam dark gripper-tip blob deprojected to the CAMERA frame, or None.
    Overhead cam: the ELEVATED gripper tip is the NEAREST dark blob (depth-gated),
    which rejects the larger but table-level dark clutter (cable/tool/cutout).

    `grab` is a PERSISTENT RealSenseGrabber opened ONCE by the caller and reused for
    every pose. Opening/closing a fresh pipeline per pose crashed the D435i after a
    couple of cycles ('Frame didn't arrive within 5000') -- rapid open/close is the
    RealSense USB fragility. One long-lived stream is stable."""
    got = None
    for _ in range(12):
        got = grab.latest()
        if got:
            break
        time.sleep(0.1)
    if got is None:
        return None
    rgb, depth, K = got
    hsv = cv2.cvtColor(np.ascontiguousarray(rgb[..., ::-1]), cv2.COLOR_BGR2HSV)
    dark = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([180, 255, DARK_V]))
    dark = cv2.morphologyEx(dark, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    # Zero the bottom-right corner (fixed cable+mount decoy the depth gate can't reject).
    dark[EXCLUDE_Y0:, EXCLUDE_X0:] = 0
    cnts, _ = cv2.findContours(dark, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = [c for c in cnts if cv2.contourArea(c) > 400]
    if not cnts:
        return None
    # Score each dark blob by its NEAR depth (5th percentile of valid depth pixels).
    # The gripper tip is the nearest -> smallest near-depth. Ignore blobs whose near
    # depth is beyond TIP_MAX_DEPTH (those are table-level clutter, never the tip).
    best = None  # (near_depth, ys, xs, d)
    for c in cnts:
        blob = np.zeros(dark.shape, np.uint8); cv2.drawContours(blob, [c], -1, 255, -1)
        valid = (blob > 0) & (depth > 0.05) & np.isfinite(depth)
        ys, xs = np.where(valid)
        if len(xs) < 30:
            continue
        d = depth[ys, xs]
        near = float(np.percentile(d, 5))
        if near > TIP_MAX_DEPTH:
            continue
        if best is None or near < best[0]:
            best = (near, ys, xs, d)
    if best is None:
        return None
    near, ys, xs, d = best
    # Trim to the near-depth pixels only, so a tip blob merged with adjacent
    # table/tool pixels still yields the tip centroid (not the merged average).
    keep = d <= near + TIP_DEPTH_BAND
    if keep.sum() < 30:
        return None
    ys, xs, d = ys[keep], xs[keep], d[keep]
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    X = (xs - cx) * d / fx; Y = (ys - cy) * d / fy
    return np.array([float(np.median(X)), float(np.median(Y)), float(np.median(d))])


def load():
    return json.load(open(PAIRS)) if os.path.exists(PAIRS) else []


def fmt_space(T):
    return " ".join(f"{v:.6f}" for v in T.reshape(-1))


def fmt_bracket(T):
    return "[" + ",".join(f"{v:.6f}" for v in T.reshape(-1)) + "]"


def umeyama_no_scale(src, dst):
    src = np.asarray(src, float); dst = np.asarray(dst, float)
    cs, cd = src.mean(0), dst.mean(0)
    S, D = src - cs, dst - cd
    H = S.T @ D
    U, _, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    Rm = Vt.T @ np.diag([1, 1, d]) @ U.T
    t = cd - Rm @ cs
    T = np.eye(4); T[:3, :3] = Rm; T[:3, 3] = t
    return T


def cmd_solve():
    pairs = load(); n = len(pairs)
    print("pairs:", n)
    if n < 4:
        print("need >=4 well-spread pairs (>=8 recommended)"); sys.exit(2)
    cam = np.array([p["cam"] for p in pairs]); base = np.array([p["base"] for p in pairs])
    # ROBUST fit: a few poses can still mis-detect (the tip merges with the black tool
    # at some -y poses -> the trimmed centroid blends tip+tool). Umeyama is least-squares
    # so a handful of ~90 mm outliers drag the WHOLE extrinsic. So: fit, then DISCARD pairs
    # with residual > max(3x median, 40 mm), and REFIT on the inliers. Report both.
    T = umeyama_no_scale(cam, base)
    res = np.linalg.norm((T[:3, :3] @ cam.T).T + T[:3, 3] - base, axis=1)
    thresh = max(3.0 * float(np.median(res)), 0.040)
    inl = res <= thresh
    print(f"initial RMS: {np.sqrt((res**2).mean())*1000:.1f} mm over {n} pairs; "
          f"outlier thresh {thresh*1000:.0f} mm -> {int(inl.sum())} inliers, "
          f"discarding {int((~inl).sum())} (idx {list(np.where(~inl)[0])})")
    if inl.sum() >= 4:
        cam, base = cam[inl], base[inl]
        T = umeyama_no_scale(cam, base)
    res = np.linalg.norm((T[:3, :3] @ cam.T).T + T[:3, 3] - base, axis=1)
    print("T_base_cam (4x4):"); print(np.round(T, 5))
    print(f"residuals (mm): {np.round(res*1000, 1)}")
    print(f"RMS: {np.sqrt((res**2).mean())*1000:.1f} mm over {len(res)} inliers "
          f"(<~10 good; >30 bad correspondences)")
    print(f"\nspace-sep (extrinsic_calib style):\n{fmt_space(T)}")
    print(f"\nSCENE_T for run_pick_hold.sh:\n{fmt_bracket(T)}")


def cmd_auto():
    from xarm.wrapper import XArmAPI
    from cube_perception_node import RealSenseGrabber
    grid = make_grid()
    print(f"AUTO tip-sweep calib: {len(grid)} poses ({len(SWEEP_XY)} xy x {len(SWEEP_Z)} heights). "
          "CLEAR THE WORKSPACE.", flush=True)
    # Open the scene cam ONCE and reuse it across every pose. Per-pose open/close
    # crashed the D435i after ~2 cycles (rapid RealSense pipeline open/close is
    # fragile); one long-lived stream is stable for the whole sweep.
    grab = RealSenseGrabber(width=1280, height=720, want_ir=False, serial=SCENE_SERIAL)
    A = XArmAPI(IP, is_radian=True); A.connect()
    A.clean_error(); A.clean_warn(); time.sleep(0.3)
    A.motion_enable(enable=True); A.set_mode(0); A.set_state(0); time.sleep(0.3)
    # NOTE: NO gripper enable/modbus here. The tip-sweep does not touch the gripper (its physical
    # state is already a consistent dark blob), and the tgpio-modbus gripper-enable was throwing
    # ControllerError 19 which then blocked ALL arm motion. brio_dlt.py likewise never grips.

    def movej(q, speed):
        A.set_servo_angle(angle=[float(v) for v in q], is_radian=True, speed=speed, acc=2.0, wait=True)

    def moveto(xyz, speed, seed=None):
        s = seed if seed is not None else np.array(A.get_servo_angle(is_radian=True)[1][:6], float)
        q, r = numeric_ik(np.asarray(xyz, float), R, s)
        if r > 2e-2:
            return None
        movej(q, speed)
        return q

    def home():
        movej(HOME, 0.35)

    home()
    time.sleep(0.5)

    pairs = []
    for i, (x, y, z) in enumerate(grid):
        q = moveto([x, y, z], 0.22 if i else 0.25)
        if q is None:
            print(f"pose {i} ({x:.3f},{y:.3f},{z:.2f}): unreachable; skip"); continue
        # ABORT if the controller faulted (a blocked move leaves the arm stuck -> garbage pairs,
        # exactly the error-19 failure mode). error_code != 0 means the move did not execute.
        if A.error_code != 0:
            print(f"pose {i}: controller error {A.error_code} -> move blocked; ABORT"); break
        time.sleep(0.7)
        mq = np.array(A.get_servo_angle(is_radian=True)[1][:6], float)
        base_truth = fk(mq)[:3, 3]
        # sanity: the commanded xy should be roughly reached (guards a silent stuck arm)
        if np.linalg.norm(base_truth[:2] - np.array([x, y])) > 0.05:
            print(f"pose {i}: arm at {np.round(base_truth,3)} not near cmd ({x:.3f},{y:.3f}); ABORT"); break
        cam = scene_tip_cam(grab)
        if cam is None:
            print(f"pose {i}: scene tip not seen; skip"); continue
        pairs.append({"cam": [float(c) for c in cam], "base": [float(b) for b in base_truth]})
        print(f"pose {i}: base={np.round(base_truth,3)} cam={np.round(cam,3)} (n={len(pairs)})", flush=True)

    home()
    grab.stop()
    A.disconnect()
    json.dump(pairs, open(PAIRS, "w"), indent=2)
    print(f"\ncollected {len(pairs)} pairs -> {PAIRS}\nnow: python3 calibrate_scene_camera.py solve")


def cmd_dry():
    grid = make_grid()
    print(f"DRY no-motion. {len(grid)} tip-sweep poses:")
    for i, (x, y, z) in enumerate(grid):
        q, r = numeric_ik(np.array([x, y, z]), R, HOME)
        print(f"  {i:2d} ({x:+.3f},{y:+.3f},{z:.2f}) res={r:.4f} {'OK' if r < 2e-2 else 'WEAK'}")


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in ("auto", "solve", "show", "dry"):
        print(__doc__); sys.exit(1)
    os.makedirs(os.path.dirname(PAIRS), exist_ok=True)
    if sys.argv[1] == "auto":
        cmd_auto()
    elif sys.argv[1] == "solve":
        cmd_solve()
    elif sys.argv[1] == "show":
        print(json.dumps(load(), indent=2))
    else:
        cmd_dry()
