#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Calibrate the WRIST camera -> TCP extrinsic (eye-in-hand), by looking at a static cube.

** THIS SCRIPT MOVES THE ROBOT. ** Run only with a person present and an e-stop in reach.

Put the green cube on the table where the arm can see it from home, then:

    python3 calibrate_wrist_camera.py            # tours the poses, writes calib/poses_wrist.json
    python3 eyehand_calib.py calib/poses_wrist.json   # solves T_tcp_cam and prints the RMS

The arm visits several poses that keep the cube in the wrist camera's view while VARYING
ORIENTATION -- that is what makes the rotation observable; a position-only tour leaves it
degenerate. At each pose it records the cube in camera coordinates (segment -> centroid
depth -> deproject) against T_base_tcp = FK(the measured joints).

The wrist serial is PINNED. Both cameras are D435i, so an unpinned grab may silently open
the scene camera instead and produce a confidently wrong extrinsic.

The robot IP and the wrist serial differ per cell; override them in the environment:

    ROBOT_IP=192.168.1.231 WRIST_SERIAL=<wrist serial> python3 calibrate_wrist_camera.py
"""
import os, sys, json, time, subprocess, pathlib
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from xarm6_fk import fk
from xarm.wrapper import XArmAPI
from cube_perception_node import RealSenseGrabber, mask_centroid_depth, deproject

_HERE = pathlib.Path(__file__).resolve().parent
WRIST_SERIAL = os.environ.get("WRIST_SERIAL", "346522071715")   # PINNED: two D435i on the bus
IP = os.environ.get("ROBOT_IP", "192.168.1.231")
HOME = np.array([2.9415, -0.9205, -0.4684, 0.0882, 1.3669, 0.0])
# perturbations: vary wrist joints (j4,j5,j6) for ORIENTATION diversity (makes the
# T_tcp_cam ROTATION observable) + small j1/j2/j3 to keep the cube in view. rad.
POSES = [
    [0, 0, 0, 0, 0, 0],
    [0.05, -0.05, 0.0, 0.20, 0.10, 0.0],
    [-0.05, -0.05, 0.0, -0.20, -0.10, 0.0],
    [0.0, -0.08, 0.05, 0.0, 0.15, 0.30],
    [0.0, -0.08, 0.05, 0.0, -0.15, -0.30],
    [0.08, -0.03, -0.03, 0.15, 0.0, 0.20],
]
OUT = os.environ.get("WRIST_POSES", str(_HERE / "calib" / "poses_wrist.json"))


# The cube is found with the SAME HSV gate the deployed perception uses. The mock
# backend's green-channel test is NOT equivalent: on a wrist frame where this HSV gate
# returns 12170 cube pixels, that test returned 0.
HSV_LO = (40, 150, 50)
HSV_HI = (90, 255, 255)


def green_mask(rgb):
    import cv2
    hsv = cv2.cvtColor(np.ascontiguousarray(rgb[..., ::-1]), cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, np.array(HSV_LO), np.array(HSV_HI)) > 0
    return m if m.sum() > 50 else None


def movej(q):
    a = ",".join(f"{v:.5f}" for v in q)
    cmd = ('ros2 service call /xarm/set_servo_angle xarm_msgs/srv/MoveJoint '
           f'"{{angles: [{a}], speed: 0.25, acc: 2.5, wait: true, timeout: 30.0}}"')
    subprocess.run(["bash", "-lc",
                    "source /opt/ros/jazzy/setup.bash; source /xarm_ws/install/setup.bash; " + cmd],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


os.makedirs(os.path.dirname(OUT), exist_ok=True)
if os.path.exists(OUT):
    os.remove(OUT)
# Motion via ROS service (SDK+ROS mix, per the deploy convention); joint readback via SDK.
_arm = XArmAPI(IP, is_radian=True); _arm.connect()
_arm.clean_error(); _arm.clean_warn(); time.sleep(0.3)
_arm.motion_enable(enable=True); _arm.set_mode(0); _arm.set_state(0); time.sleep(0.3)
# 720p wrist grab (D435i on USB3 now supports it; more pixels on the cube for the centroid).
grab = RealSenseGrabber(width=1280, height=720, want_ir=False, serial=WRIST_SERIAL)
time.sleep(1)

samples = []
for i, dp in enumerate(POSES):
    q = HOME + np.array(dp)
    movej(q)
    time.sleep(1.6)   # settle before reading joints + grabbing
    # ABORT on a controller fault (a blocked move -> stale joints -> garbage pair).
    if _arm.error_code != 0:
        print(f"pose {i}: controller error {_arm.error_code} -> ABORT")
        break
    # T_base_tcp from FRESH SDK joint readback -> FK (avoids stale TF buffer).
    code, ja = _arm.get_servo_angle(is_radian=True)
    q_meas = np.array(ja[:6], float)
    T_bt = fk(q_meas)
    # a couple of grab retries (RealSense occasionally returns None on the first poll)
    got = None
    for _ in range(15):
        got = grab.latest()
        if got:
            break
        time.sleep(0.1)
    if got is None:
        print(f"pose {i}: no wrist frame; skip")
        continue
    rgb, depth, K = got
    mask = green_mask(rgb)
    if mask is None:
        print(f"pose {i}: cube NOT seen")
        continue
    cd = mask_centroid_depth(mask, depth)
    if cd is None:
        print(f"pose {i}: no depth on cube")
        continue
    u, v, z = cd
    p_cam = deproject(u, v, z, K)
    samples.append({"p_cam": [float(x) for x in p_cam],
                    "T_base_tcp": [float(x) for x in T_bt.reshape(-1)]})
    print(f"pose {i}: p_cam={np.round(p_cam, 4)} tcp={np.round(T_bt[:3, 3], 4)} (n={len(samples)})",
          flush=True)

grab.stop()
movej(HOME)
_arm.disconnect()
json.dump(samples, open(OUT, "w"), indent=2)
print(f"collected {len(samples)} samples -> {OUT}\n"
      f"now: python3 eyehand_calib.py {OUT}")
