#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Inverse kinematics for the xArm6, by damped least squares in NumPy.

``numeric_ik(position, rotation, q_seed)`` finds joint angles that put
``link_tcp`` at a requested pose, starting from the configuration the arm is
already in.

This exists for one job in the controller: *projecting* a commanded joint
setpoint onto a constraint, such as "the same pose, but no lower than the
z floor". That is why it is seeded and iterative rather than a closed-form
solver over all eight branches -- the answer wanted is the one nearest the seed,
staying in the same arm configuration, so the joints move as little as possible.
For the same reason it is not a substitute for the policy: it is only ever used
to clamp what the policy asked for, never to decide where to go.

Convergence is Levenberg-Marquardt on the 6-D pose error with a numerically
differentiated Jacobian, clipped to the joint limits every step. Nothing about
this is fast, and it does not need to be: the controller calls it at most once
per 25 ms tick, and only while a constraint is active.
"""

import numpy as np

from xarm6_fk import fk
from xarm6_fk import JOINT_LIMITS_LOWER
from xarm6_fk import JOINT_LIMITS_UPPER

# Finite-difference step for the Jacobian (rad). Large enough to stay well clear
# of float64 cancellation, small enough that the linearization holds.
_JACOBIAN_EPS = 1e-6

# Levenberg-Marquardt damping. Raised when a step makes the error worse and
# lowered when it helps, which is what keeps the solver stable near the
# wrist singularity where the Jacobian loses rank.
_DAMPING_INIT = 1e-3
_DAMPING_MIN = 1e-9
_DAMPING_MAX = 1e3

# Per-iteration cap on how far the joints may move (rad), so a near-singular
# Jacobian cannot fling the seed across the workspace in one step.
_MAX_STEP_RAD = 0.2


def _rotation_error(current: np.ndarray, target: np.ndarray) -> np.ndarray:
  """Rotation from ``current`` to ``target`` as a rotation vector (rad).

  The axis-angle form of ``target @ current.T``: its direction is the rotation
  axis and its norm the angle, which is the orientation error in the same
  additive form as the position error, so the two stack into one residual.
  """
  relative = target @ current.T
  # The skew-symmetric part gives the axis scaled by sin(angle); combined with
  # the trace (which gives cos(angle)) this stays well conditioned at angles
  # near pi, where reading the axis off the skew part alone breaks down.
  axis = 0.5 * np.array([
      relative[2, 1] - relative[1, 2],
      relative[0, 2] - relative[2, 0],
      relative[1, 0] - relative[0, 1],
  ])
  sin_angle = np.linalg.norm(axis)
  cos_angle = 0.5 * (np.trace(relative) - 1.0)
  angle = np.arctan2(sin_angle, cos_angle)
  if sin_angle < 1e-12:
    # Either no rotation at all, or a half turn, where the axis is recovered
    # from the symmetric part instead.
    if cos_angle > 0.0:
      return np.zeros(3)
    eigenvalues, eigenvectors = np.linalg.eigh(0.5 * (relative + relative.T))
    return float(angle) * eigenvectors[:, int(np.argmax(eigenvalues))]
  return (angle / sin_angle) * axis


def _pose_error(
    q: np.ndarray, position: np.ndarray, rotation: np.ndarray
) -> np.ndarray:
  """Stacked position (m) and orientation (rad) error at ``q``."""
  pose = fk(q)
  return np.concatenate(
      [position - pose[:3, 3], _rotation_error(pose[:3, :3], rotation)]
  )


def _jacobian(
    q: np.ndarray, position: np.ndarray, rotation: np.ndarray, error: np.ndarray
) -> np.ndarray:
  """d(error)/dq by forward differences, 6x6."""
  jacobian = np.empty((6, 6))
  for i in range(6):
    perturbed = q.copy()
    perturbed[i] += _JACOBIAN_EPS
    jacobian[:, i] = (
        _pose_error(perturbed, position, rotation) - error
    ) / _JACOBIAN_EPS
  return jacobian


def numeric_ik(
    position,
    rotation,
    q_seed,
    max_iterations: int = 60,
    tolerance: float = 1e-5,
) -> tuple[np.ndarray, float]:
  """Solves for joint angles reaching a TCP pose, nearest to a seed.

  Args:
    position: Target ``link_tcp`` position in the base frame (metres, 3).
    rotation: Target ``link_tcp`` orientation in the base frame (3x3).
    q_seed: Joint angles to start from and stay close to (radians, 6).
    max_iterations: Cap on Levenberg-Marquardt iterations.
    tolerance: Residual below which the solve stops early.

  Returns:
    ``(q, residual)``. ``q`` is the best joint configuration found, always
    within the joint limits. ``residual`` is the norm of the remaining pose
    error, stacking metres and radians -- so 0.02 means the pose is off by at
    most 2 cm and 0.02 rad. The caller decides what is close enough: an
    unreachable target still returns the closest configuration reached, so
    ``residual`` must be checked before the result is commanded.
  """
  position = np.asarray(position, dtype=np.float64).reshape(3)
  rotation = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
  q = np.clip(
      np.asarray(q_seed, dtype=np.float64).reshape(-1)[:6],
      JOINT_LIMITS_LOWER,
      JOINT_LIMITS_UPPER,
  )

  error = _pose_error(q, position, rotation)
  residual = float(np.linalg.norm(error))
  best_q, best_residual = q.copy(), residual
  damping = _DAMPING_INIT

  for _ in range(max_iterations):
    if best_residual <= tolerance:
      break
    jacobian = _jacobian(q, position, rotation, error)
    # (J'J + lambda I) dq = -J'e, the damped normal equations. Solving these
    # rather than pseudo-inverting J is what makes the singular case finite.
    jtj = jacobian.T @ jacobian
    jte = jacobian.T @ error
    try:
      step = np.linalg.solve(jtj + damping * np.eye(6), -jte)
    except np.linalg.LinAlgError:
      damping = min(damping * 10.0, _DAMPING_MAX)
      continue

    norm = float(np.linalg.norm(step))
    if norm > _MAX_STEP_RAD:
      step *= _MAX_STEP_RAD / norm
    candidate = np.clip(q + step, JOINT_LIMITS_LOWER, JOINT_LIMITS_UPPER)
    candidate_error = _pose_error(candidate, position, rotation)
    candidate_residual = float(np.linalg.norm(candidate_error))

    if candidate_residual < residual:
      q, error, residual = candidate, candidate_error, candidate_residual
      damping = max(damping * 0.5, _DAMPING_MIN)
      if residual < best_residual:
        best_q, best_residual = q.copy(), residual
    else:
      # The step overshot: trust the linearization less and try again.
      damping = min(damping * 10.0, _DAMPING_MAX)
      if damping >= _DAMPING_MAX:
        break

  return best_q, best_residual
