#!/usr/bin/env python3
# Copyright(C) 2026 Advanced Micro Devices, Inc. All rights reserved.

"""Forward kinematics of the xArm6 ``link_tcp`` frame, in NumPy.

``fk(q)`` maps the six arm joint angles to the pose of the tool-centre point in
the ``link_base`` frame -- the same pose the trained policy observes as
``tcp_pos`` and the same frame the cube position is published in.

The controller needs this even though the robot publishes a TF tree, because
some of what it does is about a pose the robot is *not* at: the height its
integrated setpoint would reach if it commanded it, one tick before committing
to it. TF only ever reports where the arm actually is.

The parameters are the Denavit-Hartenberg chain of the MuJoCo model the policy
was trained in (``training/manipulation/ufactory_xarm6/xarm6_kinematics.py``).
Checked against that model over 2000 random joint configurations, this agrees
with its ``link_tcp`` site to 5e-6 m and 1.5e-5 in the rotation matrix -- the
residual being the rounding in the DH constants below, far under the accuracy
this is used at. Note that the TCP includes the 172 mm tool offset of the
gripper in that model: with a different end effector, that offset -- and only
that offset -- has to change.

Run this file to print the pose at a joint configuration -- with no arguments,
at the trained home pose -- which is the quickest way to check this chain against
what the arm itself reports:

    python3 xarm6_fk.py
    python3 xarm6_fk.py 2.9415 -0.9205 -0.4684 0.0882 1.3669 0.0
"""

import numpy as np

# xArm6 link geometry (metres / radians), from the MJCF the policy trained on.
_D1 = 0.267
_D4 = 0.3425
_D6 = 0.097
_A2 = 0.28948866
_A3 = 0.0775
_A5 = 0.076
# Shoulder/elbow offset that makes joint 2 and 3 zero at the model's zero pose.
_T2_OFFSET = -1.3849179
# link_tcp sits this far along the flange's +z, between the gripper fingers.
_TCP_OFFSET = 0.172

# Joint limits of the arm, in the order joint1..joint6. The same values the
# exported policy metadata carries, kept here so the solver next to this file
# can stay inside them without needing the metadata.
JOINT_LIMITS_LOWER = np.array(
    [-6.2832, -2.0590, -3.9270, -6.2832, -1.69297, -6.2832]
)
JOINT_LIMITS_UPPER = np.array(
    [6.2832, 2.0944, 0.19198, 6.2832, 3.14159, 6.2832]
)

# The pose every episode starts from, matching the trained scene's home keyframe
# and ``robot_setup.home_joint_angles_rad`` in the exported metadata.
HOME_JOINT_ANGLES = np.array([2.9415, -0.9205, -0.4684, 0.0882, 1.3669, 0.0])


def _dh(theta: float, d: float, a: float, alpha: float) -> np.ndarray:
  """One standard Denavit-Hartenberg homogeneous transform."""
  ct, st = np.cos(theta), np.sin(theta)
  ca, sa = np.cos(alpha), np.sin(alpha)
  return np.array([
      [ct, -st * ca, st * sa, a * ct],
      [st, ct * ca, -ct * sa, a * st],
      [0.0, sa, ca, d],
      [0.0, 0.0, 0.0, 1.0],
  ])


def fk(q) -> np.ndarray:
  """Pose of ``link_tcp`` in the ``link_base`` frame.

  Args:
    q: The six arm joint angles, in radians, in the order joint1..joint6.

  Returns:
    A 4x4 homogeneous transform: ``[:3, 3]`` is the TCP position in metres and
    ``[:3, :3]`` its orientation, both in the base frame.
  """
  q = np.asarray(q, dtype=np.float64).reshape(-1)
  if q.shape[0] < 6:
    raise ValueError(f"Expected 6 joint angles, got {q.shape[0]}.")
  half_pi = 0.5 * np.pi
  return (
      _dh(q[0], _D1, 0.0, -half_pi)
      @ _dh(q[1] + _T2_OFFSET, 0.0, _A2, 0.0)
      @ _dh(q[2] - _T2_OFFSET, 0.0, _A3, -half_pi)
      @ _dh(q[3], _D4, 0.0, half_pi)
      @ _dh(q[4], 0.0, _A5, -half_pi)
      @ _dh(q[5], _D6 + _TCP_OFFSET, 0.0, 0.0)
  )


def tcp_position(q) -> np.ndarray:
  """The TCP position alone, in metres, in the base frame."""
  return fk(q)[:3, 3]


def _main() -> None:
  import sys  # pylint: disable=import-outside-toplevel

  if len(sys.argv) == 1:
    # No arguments prints the trained home pose, which is the pose to compare
    # against the driver's own TF when checking this chain on real hardware.
    q = list(HOME_JOINT_ANGLES)
  elif len(sys.argv) == 7:
    q = [float(x) for x in sys.argv[1:7]]
  else:
    raise SystemExit(
        f"usage: {sys.argv[0]} [j1 j2 j3 j4 j5 j6]   (radians)\n"
        "With no arguments, prints the pose at the trained home configuration."
    )
  pose = fk(q)
  np.set_printoptions(precision=6, suppress=True)
  print(f"joints (rad): {np.asarray(q)}")
  print(f"joints (deg): {np.degrees(q)}")
  print(f"link_tcp position (m): {pose[:3, 3]}")
  print("link_tcp orientation (base frame):")
  print(pose[:3, :3])


if __name__ == "__main__":
  _main()
