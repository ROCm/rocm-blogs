# shellcheck shell=bash
#
# Core runner for mjp-rocmwarp apptainer containers.
#
# This file is *sourced* by a variant script (apptainerplaygroundrun.sh,
# apptainerwarpbuild.sh, ...) and ends by exec'ing `apptainer exec`, so it never
# returns. Everything that is independent of which project is being worked on
# lives here: path derivation, the container HOME, the venv mount and the
# apptainer invocation. A variant only has to say *where* to work and *what* to
# do there.
#
# This is the apptainer counterpart of docker/dockerrun_core.sh, and the
# variants sourcing it mirror that directory's one for one. It is much shorter
# for one reason: an apptainer container is an ordinary child process of the
# caller, not a request to a system daemon, so the job's own confinement already
# applies to it and does not have to be re-derived and re-imposed:
#
#   GPUs    SLURM's device cgroup covers this process and everything it starts,
#           so the container sees exactly the allocated cards. The docker runner
#           has to walk the KFD topology to turn allocated GPUs into
#           --device /dev/dri/renderD* flags because the daemon creates the
#           container outside the job's cgroup.
#   CPUs    Likewise for the cpuset: `nproc` inside the container reports the
#           allocation, so thread pools and `-j` size themselves correctly with
#           no --cpuset-cpus and no thread-count plumbing.
#   User    The container runs as the invoking user with their groups, so files
#           it writes are owned normally and no --user/--group-add mapping (nor
#           a --root escape hatch) is needed.
#   Signals The container is a child process, so scancel and the walltime
#           SIGKILL reach it. A daemon-owned docker container survives them and
#           has to be named and torn down from an exit trap.
#
# Contract - a variant sets these before sourcing, then sources this file so it
# inherits the variant's positional parameters ("$@" = the user command):
#
#   PROJECT_SUBDIR   (required) Subdirectory of the repo root that becomes the
#                    container working directory. Also names the persisted venv
#                    (apptainer/.venv_$PROJECT_SUBDIR), unless VENV_SUBDIR says
#                    otherwise.
#   VENV_SUBDIR      (optional, default $PROJECT_SUBDIR) Subdirectory of the repo
#                    root whose .venv the persisted mount covers. Set it when the
#                    working directory is not itself the uv project being used --
#                    a variant that works in a plain package directory and runs
#                    against another project's environment -- so both variants
#                    share one venv instead of each building its own copy.
#   CONTAINER_SETUP  (optional) Shell snippet run inside the container before the
#                    user command, in the same shell (so it may export
#                    variables). Runs under `set -e`.
#   MOUNT_PROJECT_VENV  (optional, default 1) When 1, mount a persisted
#                    apptainer/.venv_$VENV_SUBDIR over that directory's .venv.
#                    Set to 0 for projects that need no virtualenv at all.
#   DEFAULT_COMMAND  (optional) Shell command line to run when the user gives no
#                    command. Without it, no command means an interactive shell,
#                    which is right for a dev container but wrong for a batch
#                    task that must exit with the work's status.
#   CONTAINER_ENV    (optional array) Extra NAME=value pairs to set inside the
#                    container, e.g. (HIP_ARCH=gfx942).
#   EXTRA_APPTAINER_FLAGS  (optional array) Extra flags spliced into
#                    `apptainer exec`, e.g. (--writable-tmpfs).
#   IMAGE            (optional, default apptainer/mjp-rocmwarp.sif) SIF to run.
#
# Environment:
#   MJP_SIF          Image to run, when a variant has not set IMAGE. Useful to
#                    keep the SIF on a local disk rather than in the checkout.
#   MJP_FORWARD_ENV  Extra host variables to forward into the container, by name
#                    and space-separated (e.g. MJP_FORWARD_ENV="WANDB_API_KEY").
#                    The container environment is otherwise clean, as docker's
#                    is.
#
# Debugging: set APPTAINERRUN_PRINT=1 to print the assembled `apptainer exec`
# argv, one argument per line, and exit without starting a container.

if [[ -z "${PROJECT_SUBDIR:-}" ]]; then
  echo "apptainerrun_core.sh: PROJECT_SUBDIR must be set before sourcing" >&2
  exit 2
fi
MOUNT_PROJECT_VENV="${MOUNT_PROJECT_VENV:-1}"
VENV_SUBDIR="${VENV_SUBDIR:-$PROJECT_SUBDIR}"
CONTAINER_ENV=("${CONTAINER_ENV[@]:-}")
EXTRA_APPTAINER_FLAGS=("${EXTRA_APPTAINER_FLAGS[@]:-}")
# An unset array expands to a single empty string above; drop it.
[[ ${#CONTAINER_ENV[@]} -eq 1 && -z "${CONTAINER_ENV[0]}" ]] && CONTAINER_ENV=()
[[ ${#EXTRA_APPTAINER_FLAGS[@]} -eq 1 && -z "${EXTRA_APPTAINER_FLAGS[0]}" ]] && EXTRA_APPTAINER_FLAGS=()

# An explicit `--` ends the runner's own options; anything else is the command.
if [[ "${1:-}" == "--" ]]; then
  shift
fi

# A variant with a natural default action substitutes it for the interactive
# shell, so `srun apptainerwarpbuild` exits when the build does instead of
# hanging on a shell nobody is attached to.
if [[ $# -eq 0 && -n "${DEFAULT_COMMAND:-}" ]]; then
  set -- "$DEFAULT_COMMAND"
fi

echo "Hostname ==> $(hostname)"

# Derive all paths from the variant script's own location so the runner works
# from any checkout location. Variants live at apptainer/ under the repo root,
# so the repo root is one level up. The repo root holds the editable checkouts
# they depend on (warp/, mujoco_playground/), so binding it makes those deps
# resolve in the container.
# APPTAINERRUN_SCRIPT_DIR is set by the variant (this file sits next to it).
SCRIPT_DIR="$APPTAINERRUN_SCRIPT_DIR"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_NAME="$(basename "$REPO_ROOT")"

IMAGE="${IMAGE:-${MJP_SIF:-$SCRIPT_DIR/mjp-rocmwarp.sif}}"
if [[ ! -f "$IMAGE" ]]; then
  echo "ERROR: image '$IMAGE' does not exist." >&2
  echo "       Build it with apptainer/apptainerbuild.sh, or point MJP_SIF at one." >&2
  exit 2
fi

# The container mirrors the repo root under /workspace/<repo name>, so everything
# inside it keeps the same relative layout inside the container. The project being
# worked on lives in a subdirectory of the repo root, so that (not the repo root)
# is the working dir, which is where `uv sync` finds pyproject.toml.
CONTAINER_ROOT="/workspace/$REPO_NAME"
WORKDIR="$CONTAINER_ROOT/$PROJECT_SUBDIR"

if [[ ! -d "$REPO_ROOT/$PROJECT_SUBDIR" ]]; then
  echo "ERROR: project directory '$REPO_ROOT/$PROJECT_SUBDIR' does not exist." >&2
  exit 2
fi
if [[ "$MOUNT_PROJECT_VENV" -eq 1 && ! -d "$REPO_ROOT/$VENV_SUBDIR" ]]; then
  echo "ERROR: venv directory '$REPO_ROOT/$VENV_SUBDIR' does not exist." >&2
  exit 2
fi

bind_flags=(-B "$REPO_ROOT:$CONTAINER_ROOT")

# Give the container its own HOME directory, persisted on the host as
# .apptainerhome next to this script, kept separate from the host's real home so
# the two toolchains don't clobber each other: the uv-managed Python (~/.local)
# and the uv/GPU caches (~/.cache) live here, so `uv sync` only does incremental
# work instead of rebuilding from scratch. --home also replaces apptainer's
# default mount of the real home, which would otherwise put the host's own uv
# state in the container's path.
HOST_HOME="$SCRIPT_DIR/.apptainerhome"
CONTAINER_HOME="$CONTAINER_ROOT/${SCRIPT_DIR#"$REPO_ROOT"/}/.apptainerhome"
mkdir -p "$HOST_HOME"

# The repo bind would otherwise expose the host's own <project>/.venv inside the
# container, where it is useless: its interpreter lives under the host's real
# home, a path that does not exist in the container. Bind a container-only
# directory over that path instead. uv then creates its default <project>/.venv
# (no UV_PROJECT_ENVIRONMENT needed) while the host's copy stays hidden and
# untouched, and the venv persists across containers because it is really this
# host directory. It is kept apart from the docker runner's .venv_* for the same
# reason the homes are: a venv records the absolute path of its interpreter, and
# the two runners' interpreters live in different homes.
if [[ "$MOUNT_PROJECT_VENV" -eq 1 ]]; then
  HOST_PROJECT_VENV="$SCRIPT_DIR/.venv_$VENV_SUBDIR"
  mkdir -p "$HOST_PROJECT_VENV"
  bind_flags+=(-B "$HOST_PROJECT_VENV:$CONTAINER_ROOT/$VENV_SUBDIR/.venv")
fi

# Scratch, when the cluster gives the user one (apptainer refuses to bind a path
# that does not exist, so this cannot be unconditional as it is under docker).
if [[ -d "/scratch/$USER" ]]; then
  bind_flags+=(-B "/scratch/$USER:/scratch/$USER")
fi

# The container environment starts clean (--cleanenv below), as a docker
# container's does, so that a run does not depend on the shell it was launched
# from. What the container needs is then set explicitly.
#
# UV_LINK_MODE=copy overrides uv's default of hardlinking installed files out of
# its cache. Under hardlinks a file in site-packages and its cached copy are the
# same inode, so editing one in place silently rewrites the cached wheel for every
# environment built from that cache. Copying costs disk and install time but keeps
# the venv and the cache independent.
container_env=(
  MUJOCO_GL=osmesa
  UV_LINK_MODE="${UV_LINK_MODE:-copy}"
  USER="$USER"
  LOGNAME="$USER"
  "${CONTAINER_ENV[@]}"
)

# Host variables worth carrying across the clean environment: the GPU visibility
# SLURM sets (forwarded unchanged, so the container sees the cards exactly as the
# job does), an explicit thread budget if the caller set one, the proxy settings
# `uv sync` needs to reach the network on a walled cluster, and TERM for an
# interactive shell.
for name in \
    ROCR_VISIBLE_DEVICES HIP_VISIBLE_DEVICES GPU_DEVICE_ORDINAL \
    OMP_NUM_THREADS MKL_NUM_THREADS OPENBLAS_NUM_THREADS \
    http_proxy https_proxy no_proxy HTTP_PROXY HTTPS_PROXY NO_PROXY \
    TERM SLURM_JOB_ID ${MJP_FORWARD_ENV:-}; do
  if [[ -n "${!name:-}" ]]; then
    container_env+=("$name=${!name}")
  fi
done

# Set them through APPTAINERENV_* rather than `apptainer --env`: that flag takes
# a comma-separated list, so it would split a value that contains a comma --
# exactly what ROCR_VISIBLE_DEVICES=0,1 and HIP_ARCH=gfx942,gfx950 look like.
for kv in "${container_env[@]}"; do
  export "APPTAINERENV_${kv%%=*}=${kv#*=}"
done

# Run the variant's setup (venv sync, build, ...) and then the user command. The
# --pwd flag already puts us in WORKDIR, and uv is baked into the image (see
# apptainer/mjp-rocmwarp.def), so no runtime install is needed. Surrounding blank
# lines in CONTAINER_SETUP are trimmed so a variant can use a readable multi-line
# quote without changing the script the container receives.
_setup_body="${CONTAINER_SETUP:-}"
while [[ "$_setup_body" == $'\n'* ]]; do _setup_body="${_setup_body#$'\n'}"; done
while [[ "$_setup_body" == *$'\n' ]]; do _setup_body="${_setup_body%$'\n'}"; done
setup=$'\n  set -e\n'"$_setup_body"$'\n'

if [[ $# -eq 0 ]]; then
  # No command: drop into an interactive shell after the venv is set up.
  container_cmd=(bash -c "$setup"' exec bash')
elif [[ $# -eq 1 ]]; then
  # A single argument is a shell command line, so `cd x && ...`, pipes and
  # redirections work as written. It is appended to the setup script and runs in
  # that same shell (inheriting `set -e`); the script's exit status is the
  # command's. Nothing can be exec'd here because the argument is a script, not
  # a program name -- that is what the multi-argument form below is for.
  container_cmd=(bash -c "$setup""$1")
else
  # Several arguments are an argv vector: forwarded as the shell's positional
  # params and exec'd directly, so no quoting is re-interpreted by a shell.
  container_cmd=(bash -c "$setup"' exec "$@"' bash "$@")
fi

# --no-mount cwd: the directory this was launched from is bound into the
# container at its host path by default, which for a run started in the checkout
# would make the repo visible at a second, unrelated path. The working directory
# is set explicitly below instead.
apptainer_argv=(
  apptainer exec
  --cleanenv
  --no-mount cwd
  --home "$HOST_HOME:$CONTAINER_HOME"
  "${bind_flags[@]}"
  --pwd "$WORKDIR"
  "${EXTRA_APPTAINER_FLAGS[@]}"
  "$IMAGE"
  "${container_cmd[@]}"
)

if [[ -n "${APPTAINERRUN_PRINT:-}" ]]; then
  printf '%s\n' "${apptainer_argv[@]}"
  printf 'env: %s\n' "${container_env[@]}"
  exit 0
fi

exec "${apptainer_argv[@]}"
