#!/bin/bash
#
# Single-run container for the mujoco_playground project: starts an
# mjp-rocmwarp container, syncs the project venv, runs the command passed on the
# CLI, and exits with its status.
#
# Usage:
#   apptainerplaygroundrun                       # interactive bash shell in the container
#   apptainerplaygroundrun uv run train-jax-ppo --env_name XArm6Reach5Joint --impl warp
#   apptainerplaygroundrun "uv run train-jax-ppo --env_name ... && echo done"
#
# The command is taken two ways, by argument count:
#   one argument   -> a shell command line, so `&&`, `|`, `cd x && ...` and
#                     redirections work (it is run by bash, not exec'd)
#   two or more    -> an argv vector, exec'd as-is with no shell in between, so
#                     embedded quotes survive: apptainerplaygroundrun python -c "print('a b')"
# A single-argument command that is a bare program name still works, since a
# lone program name is also a valid shell command line.
#
# This is the apptainer counterpart of docker/dockerplaygroundrun.sh and takes
# the same commands. It has no --root option: the image is read-only, so a
# package it lacks is added by editing apptainer/mjp-rocmwarp.def and rebuilding,
# not by installing into a live container.
#
# Everything not specific to this project (the GPU/CPU allocation this inherits
# from the job, mounts, container HOME) lives in apptainerrun_core.sh; see
# apptainerwarpbuild.sh for the other variant.
#
set -euo pipefail

APPTAINERRUN_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Work in the Playground checkout and sync its venv before running the command.
PROJECT_SUBDIR=mujoco_playground
CONTAINER_SETUP='
  uv sync --extra "tensorboard,rocm"
'

# shellcheck source=apptainerrun_core.sh
source "$APPTAINERRUN_SCRIPT_DIR/apptainerrun_core.sh"
