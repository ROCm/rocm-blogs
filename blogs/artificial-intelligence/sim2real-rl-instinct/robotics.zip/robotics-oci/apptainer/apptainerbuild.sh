#!/bin/bash
#
# Build the mjp-rocmwarp image (ROCm + OSMesa) as a SIF file.
# Run from anywhere; the definition file and its build context are this
# script's own dir. The result is apptainer/mjp-rocmwarp.sif.
#
# Usage:
#   apptainerbuild.sh                # build from mjp-rocmwarp.def
#   apptainerbuild.sh --from-docker  # convert the local docker image instead
#   apptainerbuild.sh --nv-log       # extra args are forwarded to apptainer build
#
# Unlike a docker image, the SIF is a single file on the shared filesystem, so
# it is built once for the whole cluster rather than once per node.
#
# Building from the definition file needs root inside the build only (apt-get),
# which apptainer provides unprivileged via `fakeroot`, or via a root-mapped
# user namespace when /etc/subuid has an entry for you. Where neither is
# available, --from-docker converts the image docker/dockerbuild.sh produces
# (`docker-daemon://mjp-rocmwarp:latest`), which needs a docker daemon but no
# privileges of its own.
#
# Environment:
#   MJP_SIF             Output path (default: <this dir>/mjp-rocmwarp.sif).
#   MJP_BUILD_TMPDIR    Where the build unpacks the image before squashing it
#                       (default: $TMPDIR or /tmp). Needs ~60 GB free; point it
#                       at a large local disk if /tmp is small.
#   APPTAINER_CACHEDIR  Where pulled layers are cached between builds
#                       (apptainer's default is ~/.apptainer/cache).
#
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIF="${MJP_SIF:-$DIR/mjp-rocmwarp.sif}"
DOCKER_IMAGE=mjp-rocmwarp:latest

from_docker=0
if [[ "${1:-}" == "--from-docker" ]]; then
  from_docker=1
  shift
fi

# The build unpacks the whole ROCm image before squashing it into the SIF, which
# needs far more space than the finished file. Both directories are exported
# rather than passed as flags because that is the only way apptainer takes them.
export APPTAINER_TMPDIR="${MJP_BUILD_TMPDIR:-${TMPDIR:-/tmp}}"
mkdir -p "$APPTAINER_TMPDIR"
avail_gb="$(df -BG --output=avail "$APPTAINER_TMPDIR" | tail -1 | tr -dc '0-9')"
if [[ -n "$avail_gb" && "$avail_gb" -lt 60 ]]; then
  echo "WARNING: only ${avail_gb}G free in APPTAINER_TMPDIR=$APPTAINER_TMPDIR;" >&2
  echo "         the ROCm image needs ~60G to unpack. Set MJP_BUILD_TMPDIR to a" >&2
  echo "         larger filesystem if the build runs out of space." >&2
fi

echo "Building $SIF"
echo "  build tmpdir: $APPTAINER_TMPDIR (${avail_gb:-?}G free)"
echo "  layer cache : ${APPTAINER_CACHEDIR:-$HOME/.apptainer/cache}"

if [[ "$from_docker" -eq 1 ]]; then
  if ! docker image inspect "$DOCKER_IMAGE" >/dev/null 2>&1; then
    echo "ERROR: docker image '$DOCKER_IMAGE' not found." >&2
    echo "       Build it first with docker/dockerbuild.sh, or drop --from-docker" >&2
    echo "       to build from apptainer/mjp-rocmwarp.def instead." >&2
    exit 2
  fi
  echo "  source      : docker-daemon://$DOCKER_IMAGE"
  exec apptainer build --force "$@" "$SIF" "docker-daemon://$DOCKER_IMAGE"
fi

# %files in the definition file uses a path relative to the build's working
# directory (../docker/set_apt_source.sh), so run it from here.
cd "$DIR"
echo "  source      : mjp-rocmwarp.def"
exec apptainer build --force "$@" "$SIF" mjp-rocmwarp.def
