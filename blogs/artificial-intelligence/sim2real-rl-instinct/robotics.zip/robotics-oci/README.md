# Clean Release

Simulation training for an xArm6 pick-and-hold policy: grasp a cube and hold it
0.25 m above where it spawned, under the sim2real randomization the deployed
policy is trained with.

This README is the path from this unpacked release to that trained policy, in
order. Each section links to the document that covers it in detail.

## Prerequisites

- **Docker or Apptainer installed** — everything below runs inside the container
  `docker/` (or `apptainer/`) builds; nothing is installed on the host. On a
  SLURM cluster prefer Apptainer, for the reasons in
  [SETUP.md](SETUP.md#docker-or-apptainer).
- **Access to an AMD Instinct GPU** — training and the Warp build both need one
  locally.

This code has only been tested on GPUs with HIP arch gfx942 and gfx950

## 1. What is in the repo

Heavy dependencies (`warp/`, `mujoco/`, `mujoco_playground/`) are pinned to clean
upstream commits, with local changes to them kept as patch files in `patches/`
and applied on top. Their directories do not exist until the first setup step
clones them into place. Everything this release adds of its own — environments,
scenes, assets, the training entry point — is ordinary code in [`training/`](training/).
`docker/` builds and runs the
container everything executes in, with [`apptainer/`](apptainer/) as its
script-for-script equivalent for clusters using that runtime, `scripts/` fetches
the pinned dependencies and manages the patch stack, and `sbatch/` holds SLURM
job templates. [`deployment/`](deployment/) is the separate, dependency-light
robot side that runs an exported policy on real hardware.

See [REPO_LAYOUT.md](REPO_LAYOUT.md) for the full directory map, the
pins, and how to add a patch or move a pin.

## 2. First-time setup

[SETUP.md](SETUP.md) is the end-to-end setup, and needs to be done once per
unpacked release (steps 4 and 5 on the GPU machine you will train on). In short:

1. `scripts/fetch-submodules.sh` — clone `warp/`, `mujoco/` and
   `mujoco_playground/` at their pinned commits — then `scripts/apply-patches.sh`.
2. `scripts/fetch-xarm6-assets.sh` — download the xArm6 visual meshes.
3. `docker/dockerbuild.sh` — build the `mjp-rocmwarp` image (ROCm + OSMesa).
4. `docker/dockerwarpbuild.sh` — compile Warp for the local GPU.
5. A trial `PandaPickCubeCartesian` run, to confirm the stack works end to end.

Every command in this README is written with the `docker/` scripts; the
Apptainer equivalent is the same path with `docker` replaced by `apptainer`
throughout (`apptainer/apptainerbuild.sh` and so on), taking the same arguments.

Prerequisites are a container runtime, an AMD GPU, and git with SSH access to
GitHub — step 1 clones the three pinned dependencies over SSH, and step 2
downloads the meshes over HTTPS. Do not continue past step 5 failing — training
uses exactly the same container and Warp library.

## 3. Train the xArm6 pick-and-hold policy

The environment is `XArm6Pick`, defined in
[`training/manipulation/ufactory_xarm6/pick.py`](training/manipulation/ufactory_xarm6/pick.py).
Train it from the repo root:

```bash
docker/dockertrainingrun.sh uv run python train_jax_ppo.py \
  --env_name XArm6Pick \
  --impl warp \
  --domain_randomization \
  --use_tb \
  --log_training_metrics
```

- `dockertrainingrun.sh` is the container the setup built, with `training/` as
  the working directory. That package is not a uv project of its own — no
  `pyproject.toml`, and nothing installs it — so the script runs it against the
  Playground environment `dockerplaygroundrun.sh` syncs, and the entry point
  imports the `training` package from its own location.
- Paths passed to the trainer are therefore relative to `training/`: a checkpoint
  to resume from is `logs/<run>/checkpoints`.
- PPO hyperparameters come from the recipe registered with the environment, so no
  tuning flags are needed. `--use_tb` writes TensorBoard logs and
  `--log_training_metrics` records the per-update training metrics (loss / KL /
  etc.).
- `--domain_randomization` enables the per-env arm servo gain spread. The rest of
  the sim2real randomization (gripper lag, perception staleness, contact dropout)
  is part of the environment and is always on.
- Runs land in `training/logs/`, next to the environments they train;
  `--logdir DIR` overrides that.

The registered recipe asks for 300M timesteps, so expect a long run. See
[`training/README.md`](training/README.md) for the config overrides and how to
add environments of your own.

### Watching what a run learned

`training/utils/debug_rollout_render.py` replays a checkpoint and writes MP4s of
the rollouts, with the environment's reward terms and diagnostics drawn on each
frame. With no arguments it renders the latest step of the most recent run:

```bash
docker/dockertrainingrun.sh uv run python utils/debug_rollout_render.py \
  --impl warp --num_videos 4
```

The container already has the headless renderer (OSMesa) and ffmpeg this needs.
See [`training/README.md`](training/README.md) for the flags that pick a
checkpoint, tile several rollouts into one video, or change the camera.

### On a SLURM cluster

[`sbatch/xarm6pick_train.sbatch`](sbatch/xarm6pick_train.sbatch) runs the same
training as a batch job, building the image and the Warp library first if they
are missing, and
[`sbatch/xarm6pick_train_apptainer.sbatch`](sbatch/xarm6pick_train_apptainer.sbatch)
does it with Apptainer — the better fit here, since that container is a child
process of the job rather than a daemon's, so it inherits the allocation and
dies with the job instead of having to be confined and cleaned up. Treat either
as a **template**

```bash
mkdir -p training/logs/sbatch_logs        # SLURM opens the -o file before the job runs
sbatch sbatch/xarm6pick_train.sbatch warp-1
sbatch sbatch/xarm6pick_train_apptainer.sbatch warp-1   # the same, under Apptainer
```

## 4. Export the trained policy to ONNX

[`training/export_policy_to_onnx.py`](training/export_policy_to_onnx.py) turns a
checkpoint into the two files the robot needs, and nothing else: `<name>.onnx`,
the deterministic policy with observation normalization baked into the graph, and
`<name>.yaml`, the runtime contract (control rate, action decode, joint
limits, observation layout, home pose). Export the latest step of the most recent
run straight into the deployment bundle:

```bash
docker/dockertrainingrun.sh \
  uv run --with onnx --with onnxruntime python export_policy_to_onnx.py \
  --output_dir ../deployment \
  --name xarm6_pick
```

That writes `deployment/xarm6_pick.onnx` and `deployment/xarm6_pick.yaml`, beside
the code that runs them, which is where
[`deployment/run_pick_hold.sh`](deployment/run_pick_hold.sh) looks by default — so
the bundle is ready to copy to the robot as it stands. Both paths are relative to
`training/`, which is where the container works. Without those two flags the pair
lands in the run's own `export/` directory instead, named after the run — useful
for keeping several candidates side by side. Either way the metadata records which
checkpoint and step it came from, so a policy in the bundle can always be traced
back to its run.

The two extra packages are added for the run rather than to the pinned project:
`onnx` writes the file and `onnxruntime` checks it. The export validates itself
against Brax's own policy on 256 observations and refuses to write a file if they
disagree, so a successful export is one the robot can be trusted to run.

## 5. Deploy to the real robot

Copy `deployment/` to the robot machine and run it there. The ROS 2 controller in
it rebuilds the trained observation from the arm's sensors and an overhead camera,
and decodes the policy's actions into joint and gripper commands at 40 Hz. It
needs neither this repository nor a GPU — the policy it runs is the pair step 4
put there.

[`deployment/README.md`](deployment/README.md) is the bring-up in order — driver,
kinematics check, camera calibration, dry run, live run — along with the safety
notes and what the failure modes look like.
