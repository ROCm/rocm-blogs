#!/usr/bin/env bash
#
# Fetch the xArm6 visual meshes into training/manipulation/ufactory_xarm6/meshes/.
#
# The meshes are the STL files that xmls/xarm6.xml references by `file="..."`
# (the arm links, the xArm gripper and the RealSense D435 mount). They come from
# the `xarm_description` package of xArm-Developer/xarm_ros2, and are copied in
# under the same relative paths the MJCF uses, e.g.
#
#   xarm_description/meshes/xarm6/visual/link1.stl
#     -> training/manipulation/ufactory_xarm6/meshes/xarm6/visual/link1.stl
#
# They are not committed to this repo — the destination is gitignored — so this
# runs once per checkout, as step 2 of the setup in SETUP.md, before any xArm6
# environment can build its model. Every file is checked against the sha256
# manifest below, both before and after fetching, and re-running only fetches
# what is missing or wrong.
#
# Usage:
#   scripts/fetch-xarm6-assets.sh           # fetch only what is missing or wrong
#   scripts/fetch-xarm6-assets.sh --check   # verify only, no network, no writes
#   scripts/fetch-xarm6-assets.sh --force   # re-fetch and overwrite all of them
#   scripts/fetch-xarm6-assets.sh --reverse # undo the fetch: delete the meshes
#   scripts/fetch-xarm6-assets.sh --reverse --force  # ... including modified ones
#
# Env: XARM_ROS2_URL  (default https://github.com/xArm-Developer/xarm_ros2.git)
#      XARM_ROS2_REF  (default jazzy — a branch or tag, not a bare commit SHA)
#
set -euo pipefail

# Resolved from this script's own location rather than with `git rev-parse
# --show-toplevel`: the release zip ships without a .git directory, and the
# meshes have to land in the same place there as in a clone.
repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
dest_root="$repo_root/training/manipulation/ufactory_xarm6/meshes"

url="${XARM_ROS2_URL:-https://github.com/xArm-Developer/xarm_ros2.git}"
ref="${XARM_ROS2_REF:-jazzy}"
# Path of the mesh tree inside that repo; the manifest paths are relative to it.
src_prefix="xarm_description/meshes"

# sha256 of each mesh, as published by xarm_ros2 at the ref above. These are the
# bytes currently committed here; a mismatch means the file is not the one the
# xarm6.xml geoms were authored against.
manifest="\
87724a2ca35d852e2b99a60f6f9567db938c7a4dac3b94bb4d8715ff12ba00d7  camera/realsense/visual/d435_with_cam_stand.stl
cdaa4cff22f7c9cff05c6a8ed32f94fd2b11a69d37dd97a159ccee2d8dd32f13  gripper/xarm/base_link.stl
a44756eb72f9c214cb37e61dc209cd7073fdff3e4271a7423476ef6fd090d2d4  gripper/xarm/left_finger.stl
e8e48692ad26837bb3d6a97582c89784d09948fc09bfe4e5a59017859ff04dac  gripper/xarm/left_inner_knuckle.stl
501665812b08d67e764390db781e839adc6896a9540301d60adf606f57648921  gripper/xarm/left_outer_knuckle.stl
c5dee87c7f37baf554b8456ebfe0b3e8ed0b22b8938bd1add6505c2ad6d32c7d  gripper/xarm/right_finger.stl
b41dd2c2c550281bf78d7cc6fa117b14786700e5c453560a0cb5fd6dfa0ffb3e  gripper/xarm/right_inner_knuckle.stl
75ca1107d0a42a0f03802a9a49cab48419b31851ee8935f8f1ca06be1c1c91e8  gripper/xarm/right_outer_knuckle.stl
103a81f9f00c217247f8b6c8f19b3afcbc9288852082389044d88a4a321cd8cd  xarm6/visual/link1.stl
20ef55e34f8a63bb65108ed3134c4b22d911b55cd496ca5562b3978cba88ac77  xarm6/visual/link2.stl
f1503bc0c1fe8d39f4c509dba7288d9130954a35a1bcbaa0fca95d083fed3ffe  xarm6/visual/link3.stl
2a9952085fef91045380dac9825d9ad5a75867196933bc2cb1c3a635c23b0b7e  xarm6/visual/link4.stl
bfca01aae4255803ba2f5391c93836b91e1761e069275e38a9656ff2d53f45a4  xarm6/visual/link5.stl
b90cb1b373e65c035d7965bde92f4e2aedacdbbd57785a9018cd996b6b0b688e  xarm6/visual/link6.stl
d3d61f2888bc39eecb8583babc7dddccb92f2ccd55aa32cd6f1dce6193feb3b6  xarm6/visual/link_base.stl"

mode="fetch"
force=0
for arg in "$@"; do
  case "$arg" in
    --check) mode="check" ;;
    --reverse) mode="reverse" ;;
    --force) force=1 ;;
    -h|--help)
      sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *)
      echo "error: unknown argument '$arg'" >&2
      exit 2
      ;;
  esac
done

# Echoes ok / missing / mismatch for one manifest entry.
state_of() {
  local want="$1" rel="$2" have
  if [[ ! -f "$dest_root/$rel" ]]; then
    echo missing
    return
  fi
  have="$(sha256sum "$dest_root/$rel" | cut -d' ' -f1)"
  [[ "$have" == "$want" ]] && echo ok || echo mismatch
}

status=0

# --reverse: delete what the fetch put here. Only files matching the manifest are
# removed, so anything edited in place survives (and is reported) unless --force
# says otherwise; re-fetching them costs one clone.
if [[ "$mode" == "reverse" ]]; then
  removed=0
  while read -r sha rel; do
    state="$(state_of "$sha" "$rel")"
    case "$state" in
      missing) printf '%-10s%s\n' "absent" "$rel" ;;
      mismatch)
        if [[ "$force" -eq 1 ]]; then
          rm -f "$dest_root/$rel"
          printf 'removed   %s (did not match the manifest)\n' "$rel"
          removed=$((removed + 1))
        else
          printf '%-10s%s (not the file that was fetched; --force removes it)\n' \
            "mismatch" "$rel" >&2
          status=1
        fi
        ;;
      ok)
        rm -f "$dest_root/$rel"
        printf 'removed   %s\n' "$rel"
        removed=$((removed + 1))
        ;;
    esac
  done <<< "$manifest"

  # Take the directory tree the fetch created with them, innermost first, but
  # only as far as it is empty — anything else under meshes/ is not ours.
  [[ -d "$dest_root" ]] && find "$dest_root" -depth -type d -empty -delete

  echo "removed $removed of $(wc -l <<< "$manifest") meshes"
  exit "$status"
fi

# The meshes that still need fetching, as "sha  relpath" lines.
wanted=""
while read -r sha rel; do
  state="$(state_of "$sha" "$rel")"
  case "$mode:$state" in
    *:ok)        [[ "$force" -eq 1 ]] && wanted+="$sha $rel"$'\n' || printf 'ok        %s\n' "$rel" ;;
    check:*)     printf '%-10s%s\n' "$state" "$rel" >&2; status=1 ;;
    *)           wanted+="$sha $rel"$'\n' ;;
  esac
done <<< "$manifest"

if [[ "$mode" == "check" ]]; then
  [[ "$status" -eq 0 ]] && echo "all $(wc -l <<< "$manifest") meshes present and matching"
  exit "$status"
fi

if [[ -z "$wanted" ]]; then
  echo "nothing to fetch — all meshes present and matching"
  exit 0
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# Blobless + sparse so only the mesh directories are ever transferred; fall back
# to a plain shallow clone on a git too old for --filter/--sparse.
echo "cloning $url @ $ref"
if git clone --quiet --depth 1 --branch "$ref" --filter=blob:none --sparse \
     --no-checkout "$url" "$tmp/xarm_ros2" 2>/dev/null; then
  git -C "$tmp/xarm_ros2" sparse-checkout set --no-cone \
    "$src_prefix/xarm6/visual" \
    "$src_prefix/gripper/xarm" \
    "$src_prefix/camera/realsense/visual"
  git -C "$tmp/xarm_ros2" checkout --quiet
else
  rm -rf "$tmp/xarm_ros2"
  git clone --quiet --depth 1 --branch "$ref" "$url" "$tmp/xarm_ros2"
fi

while read -r sha rel; do
  [[ -n "$rel" ]] || continue
  src="$tmp/xarm_ros2/$src_prefix/$rel"
  if [[ ! -f "$src" ]]; then
    echo "ERROR: $src_prefix/$rel not found in $url @ $ref" >&2
    status=1
    continue
  fi
  mkdir -p "$(dirname "$dest_root/$rel")"
  cp "$src" "$dest_root/$rel"
  if [[ "$(state_of "$sha" "$rel")" != "ok" ]]; then
    echo "ERROR: $rel from $ref does not match the expected sha256" >&2
    status=1
    continue
  fi
  echo "fetched   $rel"
done <<< "$wanted"

exit "$status"
