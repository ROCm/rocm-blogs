#!/usr/bin/env bash
#
# Pack this directory into a release zip in the directory above it.
#
# The archive is written straight from a commit with `git archive`, so what it
# contains is exactly what is tracked at that commit — nothing untracked, nothing
# ignored, no .git directory, and file modes (the executable bit on the scripts)
# carried over as git recorded them. That is the whole trick to keeping the zip
# and the branch in step: there is no exclude list here to drift out of date.
#
# warp/, mujoco/ and mujoco_playground/ are not tracked, so they cannot end up in
# the archive even when they are sitting fetched in the working tree; the person
# who unpacks the zip creates them with scripts/fetch-submodules.sh, from the
# pins in its manifest. The same goes for the meshes, the venvs, the container
# homes, the .sif image and training logs.
#
# The zip unpacks into a directory named after this one, so the release lands as
# <name>/ rather than spilling into the current directory.
#
# Usage:
#   scripts/make-release-zip.sh              # ../<name>.zip from HEAD
#   scripts/make-release-zip.sh -o PATH      # write it somewhere else
#   scripts/make-release-zip.sh --ref REF    # archive a tag or commit, not HEAD
#   scripts/make-release-zip.sh --force      # overwrite, and allow a dirty tree
#
set -euo pipefail

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
name="$(basename "$repo_root")"

ref="HEAD"
output="$(dirname "$repo_root")/$name.zip"
force=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    -o|--output) output="$2"; shift 2 ;;
    --ref)       ref="$2"; shift 2 ;;
    --force)     force=1; shift ;;
    -h|--help)
      sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *)
      echo "error: unknown argument '$1'" >&2
      exit 2
      ;;
  esac
done

if ! git -C "$repo_root" rev-parse --git-dir >/dev/null 2>&1; then
  echo "ERROR: $repo_root is not a git repository — this script builds the" >&2
  echo "       release from a commit, so run it in the clone, not in an" >&2
  echo "       unpacked release." >&2
  exit 1
fi

if ! git -C "$repo_root" rev-parse --quiet --verify "$ref^{commit}" >/dev/null; then
  echo "ERROR: no such commit: $ref" >&2
  exit 1
fi

# A dirty tree means the zip would not match what you are looking at, which is
# the one mistake that is invisible afterwards: the archive comes out valid,
# just stale.
if [[ "$ref" == "HEAD" && -n "$(git -C "$repo_root" status --porcelain)" ]]; then
  if [[ "$force" -ne 1 ]]; then
    echo "ERROR: uncommitted changes — the zip would be built from HEAD and" >&2
    echo "       would not contain them. Commit first, or pass --force to" >&2
    echo "       archive HEAD as it stands:" >&2
    git -C "$repo_root" status --short >&2
    exit 1
  fi
  echo "warning: uncommitted changes are not in this archive" >&2
fi

if [[ -e "$output" && "$force" -ne 1 ]]; then
  echo "ERROR: $output exists — pass --force to overwrite it" >&2
  exit 1
fi

# The setup tells whoever unpacks this to run scripts/*.sh directly, which only
# works if git recorded them executable (mode 100755). Catch that here, where it
# is one `git update-index --chmod=+x` away, rather than in their terminal.
non_exec="$(git -C "$repo_root" ls-tree -r "$ref" -- scripts docker apptainer \
  | awk '$1 == "100644" && $4 ~ /\.sh$/ { print $4 }')"
if [[ -n "$non_exec" ]]; then
  echo "warning: these ship without the executable bit:" >&2
  sed 's/^/         /' <<< "$non_exec" >&2
  echo "         fix with: git update-index --chmod=+x <path> (then commit)" >&2
fi

mkdir -p "$(dirname "$output")"
git -C "$repo_root" archive --format=zip -9 --prefix="$name/" -o "$output" "$ref"

files="$(git -C "$repo_root" ls-tree -r --name-only "$ref" | wc -l)"
size="$(du -h "$output" | cut -f1)"
echo "wrote $output"
echo "  $files files, $size, from $(git -C "$repo_root" rev-parse --short "$ref")"
echo "  unpacks into $name/"
