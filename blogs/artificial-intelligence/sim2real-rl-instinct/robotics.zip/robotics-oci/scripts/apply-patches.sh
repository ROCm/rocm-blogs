#!/usr/bin/env bash
#
# Apply the patch stack in patches/<submodule>/*.patch onto each submodule.
#
# The submodules stay pinned to their clean upstream commits (see .gitmodules);
# local changes live here as patches and are applied on top with `git apply`,
# leaving them as working-tree changes (the gitlink pin never moves).
#
# Layout: patches/<name>/*.patch  ->  applied inside the submodule at ./<name>
# Patches are applied in filename order (0001-, 0002-, ...).
#
# Usage:
#   scripts/apply-patches.sh            # apply all patches (skips already-applied)
#   scripts/apply-patches.sh --check    # dry-run: report what would apply, change nothing
#   scripts/apply-patches.sh --reverse  # remove the patches (un-apply the stack)
#   scripts/apply-patches.sh warp       # restrict to one or more named submodules
#
set -euo pipefail

# Resolved from this script's own location rather than with `git rev-parse
# --show-toplevel`, so that this works in the release zip too: it ships without a
# .git directory, and the submodules are checked out by scripts/fetch-submodules.sh
# instead. `git apply` itself needs no repository, only the submodule work tree.
repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
patches_dir="$repo_root/patches"

mode="apply"
names=()
for arg in "$@"; do
  case "$arg" in
    --check)   mode="check" ;;
    --reverse) mode="reverse" ;;
    -h|--help)
      sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    -*)
      echo "error: unknown flag '$arg'" >&2
      exit 2
      ;;
    *) names+=("$arg") ;;
  esac
done

if [[ ! -d "$patches_dir" ]]; then
  echo "no patches/ directory at $patches_dir; nothing to do"
  exit 0
fi

# Which submodule dirs to process (patches/<name> whose name is in $names, or all).
selected() {
  if [[ ${#names[@]} -eq 0 ]]; then
    return 0
  fi
  local candidate="$1" n
  for n in "${names[@]}"; do
    [[ "$n" == "$candidate" ]] && return 0
  done
  return 1
}

status=0
found_any=0

for sub_patches in "$patches_dir"/*/; do
  [[ -d "$sub_patches" ]] || continue
  name="$(basename "$sub_patches")"
  selected "$name" || continue

  sub_path="$repo_root/$name"
  if [[ ! -d "$sub_path/.git" && ! -f "$sub_path/.git" ]]; then
    echo "warning: submodule '$name' not checked out at $sub_path — run 'scripts/fetch-submodules.sh'; skipping" >&2
    status=1
    continue
  fi

  # Reverse order when un-applying so later patches come off first.
  mapfile -t patch_files < <(find "$sub_patches" -maxdepth 1 -name '*.patch' | sort $([[ "$mode" == "reverse" ]] && echo -r))
  [[ ${#patch_files[@]} -gt 0 ]] || continue
  found_any=1

  for patch in "${patch_files[@]}"; do
    rel="patches/$name/$(basename "$patch")"
    case "$mode" in
      reverse)
        if git -C "$sub_path" apply --reverse --check "$patch" >/dev/null 2>&1; then
          git -C "$sub_path" apply --reverse "$patch"
          echo "reverted  $name <- $rel"
        elif git -C "$sub_path" apply --check "$patch" >/dev/null 2>&1; then
          echo "not-applied  $name -- $rel (nothing to revert)"
        else
          echo "ERROR reverting $rel in $name (does not apply cleanly in either direction)" >&2
          status=1
        fi
        ;;
      check|apply)
        if git -C "$sub_path" apply --reverse --check "$patch" >/dev/null 2>&1; then
          echo "already-applied  $name -- $rel"
        elif git -C "$sub_path" apply --check "$patch" >/dev/null 2>&1; then
          if [[ "$mode" == "apply" ]]; then
            git -C "$sub_path" apply "$patch"
            echo "applied   $name <- $rel"
          else
            echo "would-apply  $name <- $rel"
          fi
        else
          echo "ERROR: $rel does not apply cleanly to $name" >&2
          status=1
        fi
        ;;
    esac
  done
done

if [[ "$found_any" -eq 0 ]]; then
  echo "no patches found${names:+ for: ${names[*]}}"
fi

exit "$status"
