#!/usr/bin/env bash
#
# Check out warp/, mujoco/ and mujoco_playground/ at their pinned commits.
#
# The pins live in the manifest below, which is this release's own record of
# them: the three directories are not tracked here — not as submodules, not as
# anything — and the zip built from this tree has no .git directory at all, so
# there is nothing for git to read either way. The script clones each repository
# and checks the pinned commit out itself, which is all that
# scripts/apply-patches.sh needs to apply the patch stack on top.
#
# On a branch that does register them as git submodules the gitlinks are the
# pins instead. The script defers to `git submodule update --init` there, after
# checking that the two records agree — a mismatch means one was moved without
# the other (see "Updating a pin" in REPO_LAYOUT.md, which moves both).
#
# Usage:
#   scripts/fetch-submodules.sh             # check out whatever is missing
#   scripts/fetch-submodules.sh --check     # report state only, no network, no writes
#   scripts/fetch-submodules.sh --reverse   # undo the checkout: delete the directories
#   scripts/fetch-submodules.sh --reverse --force   # ... even with uncommitted changes
#   scripts/fetch-submodules.sh warp        # restrict to one or more named submodules
#
# Env: SUBMODULE_CLONE_OPTS  extra flags passed to each `git clone`
#
set -euo pipefail

# Resolved from this script's own location rather than with `git rev-parse
# --show-toplevel`: in the release zip there is no repository for git to answer
# from, and that is exactly the case this script exists to handle.
repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

# name  url  commit — the pins themselves. Where these paths are registered as
# submodules the commit column must match the gitlink recorded for them
# (`git ls-files -s <name>`). Cloning the URLs needs SSH access to GitHub.
manifest="\
warp               git@github.com:AMD-Ecosystem/warp.git                 83084f0532b5ff1a29f3880e801a062553072b29
mujoco             git@github.com:google-deepmind/mujoco.git             28009f9105cd92784b7b0b30c0605a5e29107a77
mujoco_playground  git@github.com:google-deepmind/mujoco_playground.git  220abb9d6a41eaa258047dacf9ca70a92e008b78"

mode="fetch"
force=0
names=()
for arg in "$@"; do
  case "$arg" in
    --check) mode="check" ;;
    --reverse) mode="reverse" ;;
    --force) force=1 ;;
    -h|--help)
      sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    -*)
      echo "error: unknown flag '$arg'" >&2
      exit 2
      ;;
    *) names+=("$arg") ;;
  esac
done

selected() {
  if [[ ${#names[@]} -eq 0 ]]; then
    return 0
  fi
  local candidate="$1" n
  for n in "${names[@]}"; do
    [[ "$n" == "$candidate" ]] && return 0
  done
  return 1
}

# Echoes ok / wrong-commit / missing for one manifest entry. A submodule sitting
# at its pin with the patch stack applied is still "ok": the patches are
# working-tree changes and never move HEAD.
state_of() {
  local name="$1" want="$2" have
  if [[ ! -d "$repo_root/$name/.git" && ! -f "$repo_root/$name/.git" ]]; then
    echo missing
    return
  fi
  have="$(git -C "$repo_root/$name" rev-parse HEAD 2>/dev/null || true)"
  [[ "$have" == "$want" ]] && echo ok || echo wrong-commit
}

status=0

# --check reporting, shared by both paths below: state of each selected
# submodule, and a non-zero exit unless every one of them is at its pin.
report_check() {
  local name url want state
  while read -r name url want; do
    [[ -n "$name" ]] || continue
    selected "$name" || continue
    state="$(state_of "$name" "$want")"
    printf '%-14s%s\n' "$state" "$name"
    [[ "$state" == "ok" ]] || status=1
  done <<< "$manifest"
  [[ "$status" -eq 0 ]] && echo "all submodules present at their pinned commits"
  exit "$status"
}

# Echoes the gitlink recorded for <name>, or nothing when the path is not a
# registered submodule here.
gitlink_of() {
  git -C "$repo_root" ls-files -s -- "$1" 2>/dev/null | awk '$1 == "160000" { print $2 }'
}

# Whether git owns the pins, which is true only where those gitlinks exist. A
# .git directory is not enough on its own: this branch is an ordinary repository
# that happens to track the manifest, and git knows nothing of the three paths.
git_managed=0
while read -r name url sha; do
  [[ -n "$name" ]] || continue
  if [[ -n "$(gitlink_of "$name")" ]]; then
    git_managed=1
  fi
done <<< "$manifest"

# Echoes why <name> is unsafe to delete, or nothing if it is safe. What makes it
# unsafe is anything the manifest cannot reproduce: an applied patch stack shows
# up here (un-apply it and this goes quiet), but so does a half-finished edit, so
# the two are not worth trying to tell apart.
unsafe_reason() {
  local name="$1" dir="$repo_root/$1"
  if [[ ! -d "$dir/.git" && ! -f "$dir/.git" ]]; then
    echo "$name is not a git checkout — this script did not put it there"
    return
  fi
  if [[ -n "$(git -C "$dir" status --porcelain 2>/dev/null)" ]]; then
    echo "uncommitted changes (an applied patch stack counts)"
    return
  fi
  # Playground writes training runs to mujoco_playground/logs/, which its own
  # .gitignore hides from `git status` — and which nothing else has a copy of.
  if [[ -d "$dir/logs" && -n "$(ls -A "$dir/logs" 2>/dev/null)" ]]; then
    echo "$name/logs is not empty (training runs and checkpoints land there)"
  fi
}

# --reverse: put the tree back the way it was before a fetch. Everything deleted
# here is reproducible from the manifest, so the only real risk is deleting work
# that was never captured — hence the refusals above, which --force overrides.
do_reverse() {
  local name url sha dir reason size deinit=0
  while read -r name url sha; do
    [[ -n "$name" ]] || continue
    selected "$name" || continue

    dir="$repo_root/$name"
    if [[ ! -e "$dir" || -z "$(ls -A "$dir" 2>/dev/null)" ]]; then
      printf '%-14s%s\n' "absent" "$name"
      continue
    fi

    reason="$(unsafe_reason "$name")"
    if [[ -n "$reason" && "$force" -ne 1 ]]; then
      echo "ERROR: refusing to remove $name — $reason" >&2
      echo "       run 'scripts/apply-patches.sh --reverse $name' first, or pass --force" >&2
      status=1
      continue
    fi

    size="$(du -sh "$dir" 2>/dev/null | cut -f1)"
    if [[ "$git_managed" -eq 1 ]]; then
      # The git-native undo of `submodule update --init`: it empties the work
      # tree and clears the config entry, leaving the pin in the tree untouched.
      if [[ "$force" -eq 1 ]]; then
        git -C "$repo_root" submodule deinit --quiet --force -- "$name"
      else
        git -C "$repo_root" submodule deinit --quiet -- "$name"
      fi
      deinit=1
    else
      rm -rf "$dir"
    fi
    echo "removed   $name (${size:-unknown})"
  done <<< "$manifest"

  if [[ "$deinit" -eq 1 ]]; then
    echo "note: the cloned objects stay cached in .git/modules/ — a later"
    echo "      'scripts/fetch-submodules.sh' reuses them and needs no network."
  fi
  exit "$status"
}

[[ "$mode" == "reverse" ]] && do_reverse

# Where the gitlinks exist, git owns the pins. Delegate to it, but first verify
# the manifest still agrees, so the two records cannot silently drift apart.
if [[ "$git_managed" -eq 1 ]]; then
  while read -r name url sha; do
    [[ -n "$name" ]] || continue
    selected "$name" || continue
    gitlink="$(gitlink_of "$name")"
    if [[ -z "$gitlink" ]]; then
      echo "ERROR: $name is in the manifest but has no gitlink in the tree" >&2
      status=1
    elif [[ "$gitlink" != "$sha" ]]; then
      echo "ERROR: $name pin drift — manifest $sha, gitlink $gitlink" >&2
      echo "       update the manifest in $(basename "$0") to match the gitlink" >&2
      status=1
    fi
  done <<< "$manifest"

  [[ "$mode" == "check" ]] && report_check

  [[ "$status" -eq 0 ]] || exit "$status"
  echo "registered submodules detected — deferring to 'git submodule update --init'"
  git -C "$repo_root" submodule update --init -- ${names[@]+"${names[@]}"}
  exit 0
fi

# Nothing registered: this tree, and the zip built from it. Clone them by hand.
[[ "$mode" == "check" ]] && report_check

while read -r name url sha; do
  [[ -n "$name" ]] || continue
  selected "$name" || continue

  dest="$repo_root/$name"
  state="$(state_of "$name" "$sha")"

  case "$state" in
    ok)
      echo "ok        $name @ ${sha:0:12}"
      continue
      ;;
    wrong-commit)
      # Never move HEAD out from under uncommitted work: at this point the patch
      # stack may be applied, and a checkout would take it with it.
      if [[ -n "$(git -C "$dest" status --porcelain --untracked-files=no)" ]]; then
        echo "ERROR: $name is at the wrong commit and has uncommitted changes" >&2
        echo "       run 'scripts/apply-patches.sh --reverse $name' first, or move it aside" >&2
        status=1
        continue
      fi
      echo "moving    $name to ${sha:0:12}"
      git -C "$dest" fetch --quiet origin "$sha" 2>/dev/null || git -C "$dest" fetch --quiet origin
      git -C "$dest" checkout --quiet "$sha"
      ;;
    missing)
      # A blobless clone carries the full commit graph, so the pin is checkoutable
      # whether or not it is on a branch tip, while file contents transfer only
      # for the one commit checked out. Fall back to a full clone on a git too old
      # for --filter.
      echo "cloning   $name @ ${sha:0:12}"
      rmdir "$dest" 2>/dev/null || true    # an empty mount point may be sitting there
      if ! git clone --quiet --filter=blob:none --no-checkout \
             ${SUBMODULE_CLONE_OPTS:-} "$url" "$dest" 2>/dev/null; then
        rm -rf "$dest"
        git clone --quiet --no-checkout ${SUBMODULE_CLONE_OPTS:-} "$url" "$dest"
      fi
      if ! git -C "$dest" checkout --quiet "$sha"; then
        echo "ERROR: commit $sha not found in $url" >&2
        status=1
        continue
      fi
      ;;
  esac

  if [[ "$(state_of "$name" "$sha")" != "ok" ]]; then
    echo "ERROR: $name did not end up at $sha" >&2
    status=1
    continue
  fi
  echo "checked-out  $name @ ${sha:0:12}"
done <<< "$manifest"

exit "$status"
